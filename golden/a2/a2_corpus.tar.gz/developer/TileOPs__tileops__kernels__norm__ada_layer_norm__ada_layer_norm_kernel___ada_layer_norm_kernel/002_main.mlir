module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xbf16>, %arg7: memref<?xbf16>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 2.44140625E-4 : f32
    %c1024_i32 = arith.constant 1024 : i32
    %c2_i32 = arith.constant 2 : i32
    %c96_i32 = arith.constant 96 : i32
    %c512_i32 = arith.constant 512 : i32
    %c48_i32 = arith.constant 48 : i32
    %c11_i32 = arith.constant 11 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1024x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1024x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1024x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1024x4096xbf16, strided<[4096, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    scf.for %arg14 = %c0_i32 to %c11_i32 step %c1_i32  : i32 {
      %2 = tensor.empty() : tensor<2x4096xbf16>
      %3 = tensor.empty() : tensor<2x4096xf32>
      %4 = tensor.empty() : tensor<2x4096xf32>
      %5 = tensor.empty() : tensor<2x1xf32>
      %6 = tensor.empty() : tensor<2x1xf32>
      %7 = tensor.empty() : tensor<2x1xf32>
      %8 = tensor.empty() : tensor<2x1xf32>
      %9 = tensor.empty() : tensor<2x1xf32>
      %10 = arith.muli %arg14, %c48_i32 : i32
      %11 = arith.addi %10, %1 : i32
      %12 = arith.cmpi slt, %11, %c512_i32 : i32
      scf.if %12 {
        %13 = arith.muli %arg14, %c96_i32 : i32
        %14 = arith.muli %1, %c2_i32 : i32
        %15 = arith.addi %13, %14 : i32
        %16 = arith.index_cast %15 : i32 to index
        %17 = arith.subi %c1024_i32, %14 : i32
        %18 = arith.subi %17, %13 : i32
        %19 = arith.minsi %18, %c2_i32 : i32
        %20 = arith.index_cast %19 : i32 to index
        %subview = memref.subview %reinterpret_cast[%16, 0] [%20, 4096] [1, 1] : memref<1024x4096xbf16, strided<[4096, 1]>> to memref<?x4096xbf16, strided<[4096, 1], offset: ?>>
        %alloc = memref.alloc() : memref<2x4096xbf16>
        %subview_4 = memref.subview %alloc[0, 0] [%20, 4096] [1, 1] : memref<2x4096xbf16> to memref<?x4096xbf16, strided<[4096, 1]>>
        memref.copy %subview, %subview_4 : memref<?x4096xbf16, strided<[4096, 1], offset: ?>> to memref<?x4096xbf16, strided<[4096, 1]>>
        %21 = bufferization.to_tensor %subview_4 restrict : memref<?x4096xbf16, strided<[4096, 1]>>
        %inserted_slice = tensor.insert_slice %21 into %2[0, 0] [%20, 4096] [1, 1] : tensor<?x4096xbf16> into tensor<2x4096xbf16>
        %22 = hivm.hir.vcast ins(%inserted_slice : tensor<2x4096xbf16>) outs(%3 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %23 = hivm.hir.vreduce <sum> ins(%22 : tensor<2x4096xf32>) outs(%5 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
        %24 = hivm.hir.vmul ins(%23, %cst_0 : tensor<2x1xf32>, f32) outs(%6 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %25 = hivm.hir.vsub ins(%22, %24 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%22 : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
        %26 = hivm.hir.vmul ins(%25, %25 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%4 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %27 = hivm.hir.vreduce <sum> ins(%26 : tensor<2x4096xf32>) outs(%7 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
        %28 = hivm.hir.vmul ins(%27, %cst_0 : tensor<2x1xf32>, f32) outs(%8 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %29 = hivm.hir.vadd ins(%28, %cst : tensor<2x1xf32>, f32) outs(%28 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %30 = hivm.hir.vsqrt ins(%29 : tensor<2x1xf32>) outs(%27 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %31 = hivm.hir.vdiv ins(%30, %29 : tensor<2x1xf32>, tensor<2x1xf32>) outs(%9 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %32 = hivm.hir.vmul ins(%25, %31 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%25 : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
        %subview_5 = memref.subview %reinterpret_cast_3[%16, 0] [%20, 4096] [1, 1] : memref<1024x4096xbf16, strided<[4096, 1]>> to memref<?x4096xbf16, strided<[4096, 1], offset: ?>>
        %alloc_6 = memref.alloc() : memref<2x4096xbf16>
        %subview_7 = memref.subview %alloc_6[0, 0] [%20, 4096] [1, 1] : memref<2x4096xbf16> to memref<?x4096xbf16, strided<[4096, 1]>>
        memref.copy %subview_5, %subview_7 : memref<?x4096xbf16, strided<[4096, 1], offset: ?>> to memref<?x4096xbf16, strided<[4096, 1]>>
        %33 = bufferization.to_tensor %subview_7 restrict : memref<?x4096xbf16, strided<[4096, 1]>>
        %inserted_slice_8 = tensor.insert_slice %33 into %2[0, 0] [%20, 4096] [1, 1] : tensor<?x4096xbf16> into tensor<2x4096xbf16>
        %34 = hivm.hir.vcast ins(%inserted_slice_8 : tensor<2x4096xbf16>) outs(%26 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %35 = hivm.hir.vmul ins(%32, %34 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%32 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %subview_9 = memref.subview %reinterpret_cast_1[%16, 0] [%20, 4096] [1, 1] : memref<1024x4096xbf16, strided<[4096, 1]>> to memref<?x4096xbf16, strided<[4096, 1], offset: ?>>
        %alloc_10 = memref.alloc() : memref<2x4096xbf16>
        %subview_11 = memref.subview %alloc_10[0, 0] [%20, 4096] [1, 1] : memref<2x4096xbf16> to memref<?x4096xbf16, strided<[4096, 1]>>
        memref.copy %subview_9, %subview_11 : memref<?x4096xbf16, strided<[4096, 1], offset: ?>> to memref<?x4096xbf16, strided<[4096, 1]>>
        %36 = bufferization.to_tensor %subview_11 restrict : memref<?x4096xbf16, strided<[4096, 1]>>
        %inserted_slice_12 = tensor.insert_slice %36 into %2[0, 0] [%20, 4096] [1, 1] : tensor<?x4096xbf16> into tensor<2x4096xbf16>
        %37 = hivm.hir.vcast ins(%inserted_slice_12 : tensor<2x4096xbf16>) outs(%34 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %38 = hivm.hir.vadd ins(%35, %37 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%35 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %39 = hivm.hir.vcast ins(%38 : tensor<2x4096xf32>) outs(%inserted_slice_12 : tensor<2x4096xbf16>) -> tensor<2x4096xbf16>
        %extracted_slice = tensor.extract_slice %39[0, 0] [%20, 4096] [1, 1] : tensor<2x4096xbf16> to tensor<?x4096xbf16>
        %subview_13 = memref.subview %reinterpret_cast_2[%16, 0] [%20, 4096] [1, 1] : memref<1024x4096xbf16, strided<[4096, 1]>> to memref<?x4096xbf16, strided<[4096, 1], offset: ?>>
        bufferization.materialize_in_destination %extracted_slice in writable %subview_13 : (tensor<?x4096xbf16>, memref<?x4096xbf16, strided<[4096, 1], offset: ?>>) -> ()
      }
    }
    return
  }
}