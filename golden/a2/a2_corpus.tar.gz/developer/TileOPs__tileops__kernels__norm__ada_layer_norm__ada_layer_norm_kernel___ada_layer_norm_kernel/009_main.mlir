module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf16>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1152 = arith.constant 1152 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 8.68055562E-4 : f32
    %c8_i32 = arith.constant 8 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf16> to memref<64x1152xf16, strided<[1152, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf16> to memref<64x1152xf16, strided<[1152, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf16> to memref<64x1152xf16, strided<[1152, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf16> to memref<64x1152xf16, strided<[1152, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<8x1152xf32>
    %3 = tensor.empty() : tensor<8x1152xf32>
    %4 = tensor.empty() : tensor<8x1xf32>
    %5 = tensor.empty() : tensor<8x1xf32>
    %6 = tensor.empty() : tensor<8x1xf32>
    %7 = tensor.empty() : tensor<8x1xf32>
    %8 = tensor.empty() : tensor<8x1xf32>
    %9 = arith.muli %1, %c8_i32 : i32
    %10 = arith.index_cast %9 : i32 to index
    %subview = memref.subview %reinterpret_cast[%10, 0] [8, 1152] [1, 1] : memref<64x1152xf16, strided<[1152, 1]>> to memref<8x1152xf16, strided<[1152, 1], offset: ?>>
    %alloc = memref.alloc() : memref<8x1152xf16>
    memref.copy %subview, %alloc : memref<8x1152xf16, strided<[1152, 1], offset: ?>> to memref<8x1152xf16>
    %11 = bufferization.to_tensor %alloc restrict : memref<8x1152xf16>
    %12 = hivm.hir.vcast ins(%11 : tensor<8x1152xf16>) outs(%2 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %13 = hivm.hir.vreduce <sum> ins(%12 : tensor<8x1152xf32>) outs(%4 : tensor<8x1xf32>) reduce_dims = [1] -> tensor<8x1xf32>
    %14 = hivm.hir.vmul ins(%13, %cst_0 : tensor<8x1xf32>, f32) outs(%5 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %15 = hivm.hir.vsub ins(%12, %14 : tensor<8x1152xf32>, tensor<8x1xf32>) outs(%12 : tensor<8x1152xf32>) broadcast = [1] -> tensor<8x1152xf32>
    %16 = hivm.hir.vmul ins(%15, %15 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%3 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %17 = hivm.hir.vreduce <sum> ins(%16 : tensor<8x1152xf32>) outs(%6 : tensor<8x1xf32>) reduce_dims = [1] -> tensor<8x1xf32>
    %18 = hivm.hir.vmul ins(%17, %cst_0 : tensor<8x1xf32>, f32) outs(%7 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %19 = hivm.hir.vadd ins(%18, %cst : tensor<8x1xf32>, f32) outs(%18 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %20 = hivm.hir.vsqrt ins(%19 : tensor<8x1xf32>) outs(%17 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %21 = hivm.hir.vdiv ins(%20, %19 : tensor<8x1xf32>, tensor<8x1xf32>) outs(%8 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %22 = hivm.hir.vmul ins(%15, %21 : tensor<8x1152xf32>, tensor<8x1xf32>) outs(%15 : tensor<8x1152xf32>) broadcast = [1] -> tensor<8x1152xf32>
    %subview_4 = memref.subview %reinterpret_cast_3[%10, 0] [8, 1152] [1, 1] : memref<64x1152xf16, strided<[1152, 1]>> to memref<8x1152xf16, strided<[1152, 1], offset: ?>>
    %alloc_5 = memref.alloc() : memref<8x1152xf16>
    memref.copy %subview_4, %alloc_5 : memref<8x1152xf16, strided<[1152, 1], offset: ?>> to memref<8x1152xf16>
    %23 = bufferization.to_tensor %alloc_5 restrict : memref<8x1152xf16>
    %24 = hivm.hir.vcast ins(%23 : tensor<8x1152xf16>) outs(%16 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %25 = hivm.hir.vmul ins(%22, %24 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%22 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %subview_6 = memref.subview %reinterpret_cast_1[%10, 0] [8, 1152] [1, 1] : memref<64x1152xf16, strided<[1152, 1]>> to memref<8x1152xf16, strided<[1152, 1], offset: ?>>
    %alloc_7 = memref.alloc() : memref<8x1152xf16>
    memref.copy %subview_6, %alloc_7 : memref<8x1152xf16, strided<[1152, 1], offset: ?>> to memref<8x1152xf16>
    %26 = bufferization.to_tensor %alloc_7 restrict : memref<8x1152xf16>
    %27 = hivm.hir.vcast ins(%26 : tensor<8x1152xf16>) outs(%24 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %28 = hivm.hir.vadd ins(%25, %27 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%25 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %29 = hivm.hir.vcast ins(%28 : tensor<8x1152xf32>) outs(%26 : tensor<8x1152xf16>) -> tensor<8x1152xf16>
    %subview_8 = memref.subview %reinterpret_cast_2[%10, 0] [8, 1152] [1, 1] : memref<64x1152xf16, strided<[1152, 1]>> to memref<8x1152xf16, strided<[1152, 1], offset: ?>>
    bufferization.materialize_in_destination %29 in writable %subview_8 : (tensor<8x1152xf16>, memref<8x1152xf16, strided<[1152, 1], offset: ?>>) -> ()
    return
  }
}