module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf16>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c13 = arith.constant 13 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 0.0769230798 : f32
    %c5_i32 = arith.constant 5 : i32
    %c4_i32 = arith.constant 4 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [5, 13], strides: [%c13, %c1] : memref<?xf16> to memref<5x13xf16, strided<[13, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [5, 13], strides: [%c13, %c1] : memref<?xf16> to memref<5x13xf16, strided<[13, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [5, 13], strides: [%c13, %c1] : memref<?xf16> to memref<5x13xf16, strided<[13, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [5, 13], strides: [%c13, %c1] : memref<?xf16> to memref<5x13xf16, strided<[13, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<4x13xf16>
    %3 = tensor.empty() : tensor<4x13xf32>
    %4 = tensor.empty() : tensor<4x13xf32>
    %5 = tensor.empty() : tensor<4x1xf32>
    %6 = tensor.empty() : tensor<4x1xf32>
    %7 = tensor.empty() : tensor<4x1xf32>
    %8 = tensor.empty() : tensor<4x1xf32>
    %9 = tensor.empty() : tensor<4x1xf32>
    %10 = arith.muli %1, %c4_i32 : i32
    %11 = arith.index_cast %10 : i32 to index
    %12 = arith.subi %c5_i32, %10 : i32
    %13 = arith.minsi %12, %c4_i32 : i32
    %14 = arith.index_cast %13 : i32 to index
    %subview = memref.subview %reinterpret_cast[%11, 0] [%14, 13] [1, 1] : memref<5x13xf16, strided<[13, 1]>> to memref<?x13xf16, strided<[13, 1], offset: ?>>
    %alloc = memref.alloc() : memref<4x13xf16>
    %subview_4 = memref.subview %alloc[0, 0] [%14, 13] [1, 1] : memref<4x13xf16> to memref<?x13xf16, strided<[13, 1]>>
    memref.copy %subview, %subview_4 : memref<?x13xf16, strided<[13, 1], offset: ?>> to memref<?x13xf16, strided<[13, 1]>>
    %15 = bufferization.to_tensor %subview_4 restrict : memref<?x13xf16, strided<[13, 1]>>
    %inserted_slice = tensor.insert_slice %15 into %2[0, 0] [%14, 13] [1, 1] : tensor<?x13xf16> into tensor<4x13xf16>
    %16 = hivm.hir.vcast ins(%inserted_slice : tensor<4x13xf16>) outs(%3 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %17 = hivm.hir.vreduce <sum> ins(%16 : tensor<4x13xf32>) outs(%5 : tensor<4x1xf32>) reduce_dims = [1] -> tensor<4x1xf32>
    %18 = hivm.hir.vmul ins(%17, %cst_0 : tensor<4x1xf32>, f32) outs(%6 : tensor<4x1xf32>) -> tensor<4x1xf32>
    %19 = hivm.hir.vsub ins(%16, %18 : tensor<4x13xf32>, tensor<4x1xf32>) outs(%16 : tensor<4x13xf32>) broadcast = [1] -> tensor<4x13xf32>
    %20 = hivm.hir.vmul ins(%19, %19 : tensor<4x13xf32>, tensor<4x13xf32>) outs(%4 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %21 = hivm.hir.vreduce <sum> ins(%20 : tensor<4x13xf32>) outs(%7 : tensor<4x1xf32>) reduce_dims = [1] -> tensor<4x1xf32>
    %22 = hivm.hir.vmul ins(%21, %cst_0 : tensor<4x1xf32>, f32) outs(%8 : tensor<4x1xf32>) -> tensor<4x1xf32>
    %23 = hivm.hir.vadd ins(%22, %cst : tensor<4x1xf32>, f32) outs(%22 : tensor<4x1xf32>) -> tensor<4x1xf32>
    %24 = hivm.hir.vsqrt ins(%23 : tensor<4x1xf32>) outs(%21 : tensor<4x1xf32>) -> tensor<4x1xf32>
    %25 = hivm.hir.vdiv ins(%24, %23 : tensor<4x1xf32>, tensor<4x1xf32>) outs(%9 : tensor<4x1xf32>) -> tensor<4x1xf32>
    %26 = hivm.hir.vmul ins(%19, %25 : tensor<4x13xf32>, tensor<4x1xf32>) outs(%19 : tensor<4x13xf32>) broadcast = [1] -> tensor<4x13xf32>
    %subview_5 = memref.subview %reinterpret_cast_3[%11, 0] [%14, 13] [1, 1] : memref<5x13xf16, strided<[13, 1]>> to memref<?x13xf16, strided<[13, 1], offset: ?>>
    %alloc_6 = memref.alloc() : memref<4x13xf16>
    %subview_7 = memref.subview %alloc_6[0, 0] [%14, 13] [1, 1] : memref<4x13xf16> to memref<?x13xf16, strided<[13, 1]>>
    memref.copy %subview_5, %subview_7 : memref<?x13xf16, strided<[13, 1], offset: ?>> to memref<?x13xf16, strided<[13, 1]>>
    %27 = bufferization.to_tensor %subview_7 restrict : memref<?x13xf16, strided<[13, 1]>>
    %inserted_slice_8 = tensor.insert_slice %27 into %2[0, 0] [%14, 13] [1, 1] : tensor<?x13xf16> into tensor<4x13xf16>
    %28 = hivm.hir.vcast ins(%inserted_slice_8 : tensor<4x13xf16>) outs(%20 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %29 = hivm.hir.vmul ins(%26, %28 : tensor<4x13xf32>, tensor<4x13xf32>) outs(%26 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %subview_9 = memref.subview %reinterpret_cast_1[%11, 0] [%14, 13] [1, 1] : memref<5x13xf16, strided<[13, 1]>> to memref<?x13xf16, strided<[13, 1], offset: ?>>
    %alloc_10 = memref.alloc() : memref<4x13xf16>
    %subview_11 = memref.subview %alloc_10[0, 0] [%14, 13] [1, 1] : memref<4x13xf16> to memref<?x13xf16, strided<[13, 1]>>
    memref.copy %subview_9, %subview_11 : memref<?x13xf16, strided<[13, 1], offset: ?>> to memref<?x13xf16, strided<[13, 1]>>
    %30 = bufferization.to_tensor %subview_11 restrict : memref<?x13xf16, strided<[13, 1]>>
    %inserted_slice_12 = tensor.insert_slice %30 into %2[0, 0] [%14, 13] [1, 1] : tensor<?x13xf16> into tensor<4x13xf16>
    %31 = hivm.hir.vcast ins(%inserted_slice_12 : tensor<4x13xf16>) outs(%28 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %32 = hivm.hir.vadd ins(%29, %31 : tensor<4x13xf32>, tensor<4x13xf32>) outs(%29 : tensor<4x13xf32>) -> tensor<4x13xf32>
    %33 = hivm.hir.vcast ins(%32 : tensor<4x13xf32>) outs(%inserted_slice_12 : tensor<4x13xf16>) -> tensor<4x13xf16>
    %extracted_slice = tensor.extract_slice %33[0, 0] [%14, 13] [1, 1] : tensor<4x13xf16> to tensor<?x13xf16>
    %subview_13 = memref.subview %reinterpret_cast_2[%11, 0] [%14, 13] [1, 1] : memref<5x13xf16, strided<[13, 1]>> to memref<?x13xf16, strided<[13, 1], offset: ?>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_13 : (tensor<?x13xf16>, memref<?x13xf16, strided<[13, 1], offset: ?>>) -> ()
    return
  }
}