module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xbf16>, %arg7: memref<?xbf16>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 2.44140625E-4 : f32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<1x4096xbf16, strided<[4096, 1]>>
    %0 = tensor.empty() : tensor<2x4096xbf16>
    %1 = tensor.empty() : tensor<2x4096xf32>
    %2 = tensor.empty() : tensor<2x4096xf32>
    %3 = tensor.empty() : tensor<2x1xf32>
    %4 = tensor.empty() : tensor<2x1xf32>
    %5 = tensor.empty() : tensor<2x1xf32>
    %6 = tensor.empty() : tensor<2x1xf32>
    %7 = tensor.empty() : tensor<2x1xf32>
    %subview = memref.subview %reinterpret_cast[0, 0] [1, 4096] [1, 1] : memref<1x4096xbf16, strided<[4096, 1]>> to memref<4096xbf16, strided<[1]>>
    %alloc = memref.alloc() : memref<4096xbf16>
    memref.copy %subview, %alloc : memref<4096xbf16, strided<[1]>> to memref<4096xbf16>
    %8 = bufferization.to_tensor %alloc restrict : memref<4096xbf16>
    %inserted_slice = tensor.insert_slice %8 into %0[0, 0] [1, 4096] [1, 1] : tensor<4096xbf16> into tensor<2x4096xbf16>
    %9 = hivm.hir.vcast ins(%inserted_slice : tensor<2x4096xbf16>) outs(%1 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %10 = hivm.hir.vreduce <sum> ins(%9 : tensor<2x4096xf32>) outs(%3 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
    %11 = hivm.hir.vmul ins(%10, %cst_0 : tensor<2x1xf32>, f32) outs(%4 : tensor<2x1xf32>) -> tensor<2x1xf32>
    %12 = hivm.hir.vsub ins(%9, %11 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%9 : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
    %13 = hivm.hir.vmul ins(%12, %12 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%2 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %14 = hivm.hir.vreduce <sum> ins(%13 : tensor<2x4096xf32>) outs(%5 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
    %15 = hivm.hir.vmul ins(%14, %cst_0 : tensor<2x1xf32>, f32) outs(%6 : tensor<2x1xf32>) -> tensor<2x1xf32>
    %16 = hivm.hir.vadd ins(%15, %cst : tensor<2x1xf32>, f32) outs(%15 : tensor<2x1xf32>) -> tensor<2x1xf32>
    %17 = hivm.hir.vsqrt ins(%16 : tensor<2x1xf32>) outs(%14 : tensor<2x1xf32>) -> tensor<2x1xf32>
    %18 = hivm.hir.vdiv ins(%17, %16 : tensor<2x1xf32>, tensor<2x1xf32>) outs(%7 : tensor<2x1xf32>) -> tensor<2x1xf32>
    %19 = hivm.hir.vmul ins(%12, %18 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%12 : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
    %subview_4 = memref.subview %reinterpret_cast_3[0, 0] [1, 4096] [1, 1] : memref<1x4096xbf16, strided<[4096, 1]>> to memref<4096xbf16, strided<[1]>>
    %alloc_5 = memref.alloc() : memref<4096xbf16>
    memref.copy %subview_4, %alloc_5 : memref<4096xbf16, strided<[1]>> to memref<4096xbf16>
    %20 = bufferization.to_tensor %alloc_5 restrict : memref<4096xbf16>
    %inserted_slice_6 = tensor.insert_slice %20 into %0[0, 0] [1, 4096] [1, 1] : tensor<4096xbf16> into tensor<2x4096xbf16>
    %21 = hivm.hir.vcast ins(%inserted_slice_6 : tensor<2x4096xbf16>) outs(%13 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %22 = hivm.hir.vmul ins(%19, %21 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%19 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %subview_7 = memref.subview %reinterpret_cast_1[0, 0] [1, 4096] [1, 1] : memref<1x4096xbf16, strided<[4096, 1]>> to memref<4096xbf16, strided<[1]>>
    %alloc_8 = memref.alloc() : memref<4096xbf16>
    memref.copy %subview_7, %alloc_8 : memref<4096xbf16, strided<[1]>> to memref<4096xbf16>
    %23 = bufferization.to_tensor %alloc_8 restrict : memref<4096xbf16>
    %inserted_slice_9 = tensor.insert_slice %23 into %0[0, 0] [1, 4096] [1, 1] : tensor<4096xbf16> into tensor<2x4096xbf16>
    %24 = hivm.hir.vcast ins(%inserted_slice_9 : tensor<2x4096xbf16>) outs(%21 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %25 = hivm.hir.vadd ins(%22, %24 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%22 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
    %26 = hivm.hir.vcast ins(%25 : tensor<2x4096xf32>) outs(%inserted_slice_9 : tensor<2x4096xbf16>) -> tensor<2x4096xbf16>
    %extracted_slice = tensor.extract_slice %26[0, 0] [1, 4096] [1, 1] : tensor<2x4096xbf16> to tensor<1x4096xbf16>
    bufferization.materialize_in_destination %extracted_slice in writable %reinterpret_cast_2 : (tensor<1x4096xbf16>, memref<1x4096xbf16, strided<[4096, 1]>>) -> ()
    return
  }
}