module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: memref<?xf32>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1152 = arith.constant 1152 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 8.68055562E-4 : f32
    %c8_i32 = arith.constant 8 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf32> to memref<64x1152xf32, strided<[1152, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf32> to memref<64x1152xf32, strided<[1152, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf32> to memref<64x1152xf32, strided<[1152, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [64, 1152], strides: [%c1152, %c1] : memref<?xf32> to memref<64x1152xf32, strided<[1152, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<8x1152xf32>
    %3 = tensor.empty() : tensor<8x1xf32>
    %4 = tensor.empty() : tensor<8x1xf32>
    %5 = tensor.empty() : tensor<8x1xf32>
    %6 = tensor.empty() : tensor<8x1xf32>
    %7 = tensor.empty() : tensor<8x1xf32>
    %8 = arith.muli %1, %c8_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %subview = memref.subview %reinterpret_cast[%9, 0] [8, 1152] [1, 1] : memref<64x1152xf32, strided<[1152, 1]>> to memref<8x1152xf32, strided<[1152, 1], offset: ?>>
    %alloc = memref.alloc() : memref<8x1152xf32>
    memref.copy %subview, %alloc : memref<8x1152xf32, strided<[1152, 1], offset: ?>> to memref<8x1152xf32>
    %10 = bufferization.to_tensor %alloc restrict : memref<8x1152xf32>
    %11 = hivm.hir.vreduce <sum> ins(%10 : tensor<8x1152xf32>) outs(%3 : tensor<8x1xf32>) reduce_dims = [1] -> tensor<8x1xf32>
    %12 = hivm.hir.vmul ins(%11, %cst_0 : tensor<8x1xf32>, f32) outs(%4 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %13 = hivm.hir.vsub ins(%10, %12 : tensor<8x1152xf32>, tensor<8x1xf32>) outs(%10 : tensor<8x1152xf32>) broadcast = [1] -> tensor<8x1152xf32>
    %14 = hivm.hir.vmul ins(%13, %13 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%2 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %15 = hivm.hir.vreduce <sum> ins(%14 : tensor<8x1152xf32>) outs(%5 : tensor<8x1xf32>) reduce_dims = [1] -> tensor<8x1xf32>
    %16 = hivm.hir.vmul ins(%15, %cst_0 : tensor<8x1xf32>, f32) outs(%6 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %17 = hivm.hir.vadd ins(%16, %cst : tensor<8x1xf32>, f32) outs(%16 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %18 = hivm.hir.vsqrt ins(%17 : tensor<8x1xf32>) outs(%15 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %19 = hivm.hir.vdiv ins(%18, %17 : tensor<8x1xf32>, tensor<8x1xf32>) outs(%7 : tensor<8x1xf32>) -> tensor<8x1xf32>
    %20 = hivm.hir.vmul ins(%13, %19 : tensor<8x1152xf32>, tensor<8x1xf32>) outs(%13 : tensor<8x1152xf32>) broadcast = [1] -> tensor<8x1152xf32>
    %subview_4 = memref.subview %reinterpret_cast_3[%9, 0] [8, 1152] [1, 1] : memref<64x1152xf32, strided<[1152, 1]>> to memref<8x1152xf32, strided<[1152, 1], offset: ?>>
    %alloc_5 = memref.alloc() : memref<8x1152xf32>
    memref.copy %subview_4, %alloc_5 : memref<8x1152xf32, strided<[1152, 1], offset: ?>> to memref<8x1152xf32>
    %21 = bufferization.to_tensor %alloc_5 restrict : memref<8x1152xf32>
    %22 = hivm.hir.vmul ins(%20, %21 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%20 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %subview_6 = memref.subview %reinterpret_cast_1[%9, 0] [8, 1152] [1, 1] : memref<64x1152xf32, strided<[1152, 1]>> to memref<8x1152xf32, strided<[1152, 1], offset: ?>>
    %alloc_7 = memref.alloc() : memref<8x1152xf32>
    memref.copy %subview_6, %alloc_7 : memref<8x1152xf32, strided<[1152, 1], offset: ?>> to memref<8x1152xf32>
    %23 = bufferization.to_tensor %alloc_7 restrict : memref<8x1152xf32>
    %24 = hivm.hir.vadd ins(%22, %23 : tensor<8x1152xf32>, tensor<8x1152xf32>) outs(%22 : tensor<8x1152xf32>) -> tensor<8x1152xf32>
    %subview_8 = memref.subview %reinterpret_cast_2[%9, 0] [8, 1152] [1, 1] : memref<64x1152xf32, strided<[1152, 1]>> to memref<8x1152xf32, strided<[1152, 1], offset: ?>>
    bufferization.materialize_in_destination %24 in writable %subview_8 : (tensor<8x1152xf32>, memref<8x1152xf32, strided<[1152, 1], offset: ?>>) -> ()
    return
  }
}