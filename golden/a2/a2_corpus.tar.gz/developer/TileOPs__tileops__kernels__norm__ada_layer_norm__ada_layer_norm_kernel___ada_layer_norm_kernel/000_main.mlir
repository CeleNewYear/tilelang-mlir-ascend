module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: memref<?xf32>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 9.99999974E-6 : f32
    %cst_0 = arith.constant 2.44140625E-4 : f32
    %c1024_i32 = arith.constant 1024 : i32
    %c2_i32 = arith.constant 2 : i32
    %c96_i32 = arith.constant 96 : i32
    %c512_i32 = arith.constant 512 : i32
    %c48_i32 = arith.constant 48 : i32
    %c11_i32 = arith.constant 11 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xf32> to memref<1024x4096xf32, strided<[4096, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xf32> to memref<1024x4096xf32, strided<[4096, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xf32> to memref<1024x4096xf32, strided<[4096, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1024, 4096], strides: [%c4096, %c1] : memref<?xf32> to memref<1024x4096xf32, strided<[4096, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    scf.for %arg14 = %c0_i32 to %c11_i32 step %c1_i32  : i32 {
      %2 = tensor.empty() : tensor<2x4096xf32>
      %3 = tensor.empty() : tensor<2x4096xf32>
      %4 = tensor.empty() : tensor<2x1xf32>
      %5 = tensor.empty() : tensor<2x1xf32>
      %6 = tensor.empty() : tensor<2x1xf32>
      %7 = tensor.empty() : tensor<2x1xf32>
      %8 = tensor.empty() : tensor<2x1xf32>
      %9 = arith.muli %arg14, %c48_i32 : i32
      %10 = arith.addi %9, %1 : i32
      %11 = arith.cmpi slt, %10, %c512_i32 : i32
      scf.if %11 {
        %12 = arith.muli %arg14, %c96_i32 : i32
        %13 = arith.muli %1, %c2_i32 : i32
        %14 = arith.addi %12, %13 : i32
        %15 = arith.index_cast %14 : i32 to index
        %16 = arith.subi %c1024_i32, %13 : i32
        %17 = arith.subi %16, %12 : i32
        %18 = arith.minsi %17, %c2_i32 : i32
        %19 = arith.index_cast %18 : i32 to index
        %subview = memref.subview %reinterpret_cast[%15, 0] [%19, 4096] [1, 1] : memref<1024x4096xf32, strided<[4096, 1]>> to memref<?x4096xf32, strided<[4096, 1], offset: ?>>
        %alloc = memref.alloc() : memref<2x4096xf32>
        %subview_4 = memref.subview %alloc[0, 0] [%19, 4096] [1, 1] : memref<2x4096xf32> to memref<?x4096xf32, strided<[4096, 1]>>
        memref.copy %subview, %subview_4 : memref<?x4096xf32, strided<[4096, 1], offset: ?>> to memref<?x4096xf32, strided<[4096, 1]>>
        %20 = bufferization.to_tensor %subview_4 restrict : memref<?x4096xf32, strided<[4096, 1]>>
        %inserted_slice = tensor.insert_slice %20 into %2[0, 0] [%19, 4096] [1, 1] : tensor<?x4096xf32> into tensor<2x4096xf32>
        %21 = hivm.hir.vreduce <sum> ins(%inserted_slice : tensor<2x4096xf32>) outs(%4 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
        %22 = hivm.hir.vmul ins(%21, %cst_0 : tensor<2x1xf32>, f32) outs(%5 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %23 = hivm.hir.vsub ins(%inserted_slice, %22 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%inserted_slice : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
        %24 = hivm.hir.vmul ins(%23, %23 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%3 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %25 = hivm.hir.vreduce <sum> ins(%24 : tensor<2x4096xf32>) outs(%6 : tensor<2x1xf32>) reduce_dims = [1] -> tensor<2x1xf32>
        %26 = hivm.hir.vmul ins(%25, %cst_0 : tensor<2x1xf32>, f32) outs(%7 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %27 = hivm.hir.vadd ins(%26, %cst : tensor<2x1xf32>, f32) outs(%26 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %28 = hivm.hir.vsqrt ins(%27 : tensor<2x1xf32>) outs(%25 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %29 = hivm.hir.vdiv ins(%28, %27 : tensor<2x1xf32>, tensor<2x1xf32>) outs(%8 : tensor<2x1xf32>) -> tensor<2x1xf32>
        %30 = hivm.hir.vmul ins(%23, %29 : tensor<2x4096xf32>, tensor<2x1xf32>) outs(%23 : tensor<2x4096xf32>) broadcast = [1] -> tensor<2x4096xf32>
        %subview_5 = memref.subview %reinterpret_cast_3[%15, 0] [%19, 4096] [1, 1] : memref<1024x4096xf32, strided<[4096, 1]>> to memref<?x4096xf32, strided<[4096, 1], offset: ?>>
        %alloc_6 = memref.alloc() : memref<2x4096xf32>
        %subview_7 = memref.subview %alloc_6[0, 0] [%19, 4096] [1, 1] : memref<2x4096xf32> to memref<?x4096xf32, strided<[4096, 1]>>
        memref.copy %subview_5, %subview_7 : memref<?x4096xf32, strided<[4096, 1], offset: ?>> to memref<?x4096xf32, strided<[4096, 1]>>
        %31 = bufferization.to_tensor %subview_7 restrict : memref<?x4096xf32, strided<[4096, 1]>>
        %inserted_slice_8 = tensor.insert_slice %31 into %24[0, 0] [%19, 4096] [1, 1] : tensor<?x4096xf32> into tensor<2x4096xf32>
        %32 = hivm.hir.vmul ins(%30, %inserted_slice_8 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%30 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %subview_9 = memref.subview %reinterpret_cast_1[%15, 0] [%19, 4096] [1, 1] : memref<1024x4096xf32, strided<[4096, 1]>> to memref<?x4096xf32, strided<[4096, 1], offset: ?>>
        %alloc_10 = memref.alloc() : memref<2x4096xf32>
        %subview_11 = memref.subview %alloc_10[0, 0] [%19, 4096] [1, 1] : memref<2x4096xf32> to memref<?x4096xf32, strided<[4096, 1]>>
        memref.copy %subview_9, %subview_11 : memref<?x4096xf32, strided<[4096, 1], offset: ?>> to memref<?x4096xf32, strided<[4096, 1]>>
        %33 = bufferization.to_tensor %subview_11 restrict : memref<?x4096xf32, strided<[4096, 1]>>
        %inserted_slice_12 = tensor.insert_slice %33 into %24[0, 0] [%19, 4096] [1, 1] : tensor<?x4096xf32> into tensor<2x4096xf32>
        %34 = hivm.hir.vadd ins(%32, %inserted_slice_12 : tensor<2x4096xf32>, tensor<2x4096xf32>) outs(%32 : tensor<2x4096xf32>) -> tensor<2x4096xf32>
        %extracted_slice = tensor.extract_slice %34[0, 0] [%19, 4096] [1, 1] : tensor<2x4096xf32> to tensor<?x4096xf32>
        %subview_13 = memref.subview %reinterpret_cast_2[%15, 0] [%19, 4096] [1, 1] : memref<1024x4096xf32, strided<[4096, 1]>> to memref<?x4096xf32, strided<[4096, 1], offset: ?>>
        bufferization.materialize_in_destination %extracted_slice in writable %subview_13 : (tensor<?x4096xf32>, memref<?x4096xf32, strided<[4096, 1], offset: ?>>) -> ()
      }
    }
    return
  }
}