module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @high_perf(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f32
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant 9.99999974E-6 : f32
    %c64_i32 = arith.constant 64 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2048, 1], strides: [%c1, %c1] : memref<?xf16> to memref<2048x1xf16, strided<[1, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [2048, 1], strides: [%c1, %c1] : memref<?xf16> to memref<2048x1xf16, strided<[1, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<64x1xf32>
    %3 = tensor.empty() : tensor<64x1xf32>
    %4 = tensor.empty() : tensor<64x1xf32>
    %5 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %6 = arith.muli %1, %c64_i32 : i32
    %7 = arith.index_cast %6 : i32 to index
    %subview = memref.subview %reinterpret_cast[%7, 0] [64, 1] [1, 1] : memref<2048x1xf16, strided<[1, 1]>> to memref<64xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<64xf16>
    memref.copy %subview, %alloc : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
    %8 = bufferization.to_tensor %alloc restrict : memref<64xf16>
    %9 = tensor.empty() : tensor<64x1xf16>
    %inserted_slice = tensor.insert_slice %8 into %9[0, 0] [64, 1] [1, 1] : tensor<64xf16> into tensor<64x1xf16>
    %10 = tensor.empty() : tensor<64x1xf32>
    %11 = hivm.hir.vcast ins(%inserted_slice : tensor<64x1xf16>) outs(%10 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %12 = hivm.hir.vadd ins(%5, %11 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%5 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %13 = hivm.hir.vbrc ins(%cst : f32) outs(%12 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %14 = tensor.empty() : tensor<64x1xf32>
    %15 = tensor.empty() : tensor<64x1xf32>
    %subview_4 = memref.subview %reinterpret_cast[%7, 0] [64, 1] [1, 1] : memref<2048x1xf16, strided<[1, 1]>> to memref<64xf16, strided<[1], offset: ?>>
    %alloc_5 = memref.alloc() : memref<64xf16>
    memref.copy %subview_4, %alloc_5 : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
    %16 = bufferization.to_tensor %alloc_5 restrict : memref<64xf16>
    %17 = tensor.empty() : tensor<64x1xf16>
    %inserted_slice_6 = tensor.insert_slice %16 into %17[0, 0] [64, 1] [1, 1] : tensor<64xf16> into tensor<64x1xf16>
    %18 = tensor.empty() : tensor<64x1xf32>
    %19 = hivm.hir.vcast ins(%inserted_slice_6 : tensor<64x1xf16>) outs(%18 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %20 = hivm.hir.vsub ins(%19, %12 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%14 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %21 = hivm.hir.vsub ins(%19, %12 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%15 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %22 = hivm.hir.vmul ins(%20, %21 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%2 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %23 = hivm.hir.vadd ins(%13, %22 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%13 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %24 = hivm.hir.vadd ins(%23, %cst_0 : tensor<64x1xf32>, f32) outs(%22 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %25 = hivm.hir.vrsqrt ins(%24 : tensor<64x1xf32>) outs(%4 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %26 = tensor.empty() : tensor<64x1xf32>
    %27 = tensor.empty() : tensor<64x1xf32>
    %28 = tensor.empty() : tensor<64x1xf32>
    %29 = tensor.empty() : tensor<64x1xf32>
    %30 = tensor.empty() : tensor<64x1xf32>
    %subview_7 = memref.subview %reinterpret_cast[%7, 0] [64, 1] [1, 1] : memref<2048x1xf16, strided<[1, 1]>> to memref<64xf16, strided<[1], offset: ?>>
    %alloc_8 = memref.alloc() : memref<64xf16>
    memref.copy %subview_7, %alloc_8 : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
    %31 = bufferization.to_tensor %alloc_8 restrict : memref<64xf16>
    %32 = tensor.empty() : tensor<64x1xf16>
    %inserted_slice_9 = tensor.insert_slice %31 into %32[0, 0] [64, 1] [1, 1] : tensor<64xf16> into tensor<64x1xf16>
    %33 = tensor.empty() : tensor<64x1xf32>
    %34 = hivm.hir.vcast ins(%inserted_slice_9 : tensor<64x1xf16>) outs(%33 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %alloc_10 = memref.alloc() : memref<1xf16>
    memref.copy %reinterpret_cast_2, %alloc_10 : memref<1xf16, strided<[1]>> to memref<1xf16>
    %35 = bufferization.to_tensor %alloc_10 restrict : memref<1xf16>
    %36 = tensor.empty() : tensor<1xf32>
    %37 = hivm.hir.vcast ins(%35 : tensor<1xf16>) outs(%36 : tensor<1xf32>) -> tensor<1xf32>
    %alloc_11 = memref.alloc() : memref<1xf16>
    memref.copy %reinterpret_cast_1, %alloc_11 : memref<1xf16, strided<[1]>> to memref<1xf16>
    %38 = bufferization.to_tensor %alloc_11 restrict : memref<1xf16>
    %39 = tensor.empty() : tensor<1xf32>
    %40 = hivm.hir.vcast ins(%38 : tensor<1xf16>) outs(%39 : tensor<1xf32>) -> tensor<1xf32>
    %41 = hivm.hir.vsub ins(%34, %12 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%26 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %42 = hivm.hir.vmul ins(%41, %25 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%27 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %extracted = tensor.extract %37[%c0] : tensor<1xf32>
    %43 = hivm.hir.vbrc ins(%extracted : f32) outs(%28 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %44 = hivm.hir.vmul ins(%42, %43 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%29 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %extracted_12 = tensor.extract %40[%c0] : tensor<1xf32>
    %45 = hivm.hir.vbrc ins(%extracted_12 : f32) outs(%30 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %46 = hivm.hir.vadd ins(%44, %45 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%22 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %47 = tensor.empty() : tensor<64x1xf16>
    %48 = hivm.hir.vcast ins(%46 : tensor<64x1xf32>) outs(%47 : tensor<64x1xf16>) -> tensor<64x1xf16>
    %subview_13 = memref.subview %reinterpret_cast_3[%7, 0] [64, 1] [1, 1] : memref<2048x1xf16, strided<[1, 1]>> to memref<64x1xf16, strided<[1, 1], offset: ?>>
    bufferization.materialize_in_destination %48 in writable %subview_13 : (tensor<64x1xf16>, memref<64x1xf16, strided<[1, 1], offset: ?>>) -> ()
    return
  }
}