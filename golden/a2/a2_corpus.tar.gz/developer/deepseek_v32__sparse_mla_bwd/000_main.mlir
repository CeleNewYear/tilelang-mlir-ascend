module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xi32>, %arg6: memref<?xf16>, %arg7: memref<?xf32>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant -1.07374182E+9 : f32
    %c4096 = arith.constant 4096 : index
    %c512 = arith.constant 512 : index
    %c32 = arith.constant 32 : index
    %c288 = arith.constant 288 : index
    %c128 = arith.constant 128 : index
    %c16 = arith.constant 16 : index
    %c4608 = arith.constant 4608 : index
    %c576 = arith.constant 576 : index
    %c36 = arith.constant 36 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant 1.44269502 : f32
    %cst_1 = arith.constant 0.240449175 : f32
    %cst_2 = arith.constant 0.693147182 : f32
    %false = arith.constant false
    %cst_3 = arith.constant 0xFF800000 : f32
    %cst_4 = arith.constant 0.000000e+00 : f32
    %c0_i32 = arith.constant 0 : i32
    %c16_i32 = arith.constant 16 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 16, 36], strides: [%c4608, %c576, %c36, %c1] : memref<?xf16> to memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 8, 1, 16], strides: [%c128, %c16, %c16, %c1] : memref<?xi32> to memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 8, 16], strides: [%c128, %c16, %c1] : memref<?xf32> to memref<1x8x16xf32, strided<[128, 16, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 8, 1, 36], strides: [%c288, %c36, %c36, %c1] : memref<?xf16> to memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1, 8, 16, 32], strides: [%c4096, %c512, %c32, %c1] : memref<?xf16> to memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16x32xf32>
    %3 = tensor.empty() : tensor<16x1xf32>
    %4 = tensor.empty() : tensor<16x1xf32>
    %5 = tensor.empty() : tensor<16x1xf32>
    %6 = tensor.empty() : tensor<16x32xf32>
    %7 = tensor.empty() : tensor<16x1xf32>
    %8 = tensor.empty() : tensor<16x16xf32>
    %9 = hivm.hir.vbrc ins(%cst_4 : f32) outs(%2 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %10 = hivm.hir.vbrc ins(%cst_4 : f32) outs(%3 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %11 = hivm.hir.vbrc ins(%cst : f32) outs(%5 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %12 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %12, 0, 0] [1, 1, 16, 32] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x32xf16, strided<[36, 1], offset: ?>>
    %alloc = memref.alloc() : memref<16x32xf16>
    memref.copy %subview, %alloc : memref<16x32xf16, strided<[36, 1], offset: ?>> to memref<16x32xf16>
    %13 = bufferization.to_tensor %alloc restrict : memref<16x32xf16>
    %subview_9 = memref.subview %reinterpret_cast[0, %12, 0, 32] [1, 1, 16, 4] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x4xf16, strided<[36, 1], offset: ?>>
    %alloc_10 = memref.alloc() : memref<16x4xf16>
    memref.copy %subview_9, %alloc_10 : memref<16x4xf16, strided<[36, 1], offset: ?>> to memref<16x4xf16>
    %14 = bufferization.to_tensor %alloc_10 restrict : memref<16x4xf16>
    %15 = tensor.empty() : tensor<16x32xf16>
    %16 = tensor.empty() : tensor<16x4xf16>
    %17 = tensor.empty() : tensor<16x16xf32>
    %18 = tensor.empty() : tensor<16x1xf32>
    %19 = tensor.empty() : tensor<16x1xf32>
    %20 = tensor.empty() : tensor<16x1xf32>
    %21 = tensor.empty() : tensor<16x1xf32>
    %22 = tensor.empty() : tensor<16x16xf32>
    %23 = tensor.empty() : tensor<16x16xf32>
    %24 = tensor.empty() : tensor<16x16xf32>
    %25 = tensor.empty() : tensor<16x1xf32>
    %26 = tensor.empty() : tensor<16x32xf32>
    %27 = scf.for %arg14 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg15 = %15) -> (tensor<16x32xf16>)  : i32 {
      %60 = arith.index_cast %1 : i32 to index
      %61 = arith.index_cast %arg14 : i32 to index
      %62 = memref.load %reinterpret_cast_5[%c0, %60, %c0, %61] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
      %63 = arith.index_cast %62 : i32 to index
      %subview_13 = memref.subview %reinterpret_cast_7[0, %63, 0, 0] [1, 1, 1, 32] [1, 1, 1, 1] : memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>> to memref<32xf16, strided<[1], offset: ?>>
      %alloc_14 = memref.alloc() : memref<32xf16>
      memref.copy %subview_13, %alloc_14 : memref<32xf16, strided<[1], offset: ?>> to memref<32xf16>
      %64 = bufferization.to_tensor %alloc_14 restrict : memref<32xf16>
      %inserted_slice = tensor.insert_slice %64 into %arg15[%61, 0] [1, 32] [1, 1] : tensor<32xf16> into tensor<16x32xf16>
      scf.yield %inserted_slice : tensor<16x32xf16>
    }
    %28 = scf.for %arg14 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg15 = %16) -> (tensor<16x4xf16>)  : i32 {
      %60 = arith.index_cast %1 : i32 to index
      %61 = arith.index_cast %arg14 : i32 to index
      %62 = memref.load %reinterpret_cast_5[%c0, %60, %c0, %61] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
      %63 = arith.index_cast %62 : i32 to index
      %subview_13 = memref.subview %reinterpret_cast_7[0, %63, 0, 32] [1, 1, 1, 4] [1, 1, 1, 1] : memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>> to memref<4xf16, strided<[1], offset: ?>>
      %alloc_14 = memref.alloc() : memref<4xf16>
      memref.copy %subview_13, %alloc_14 : memref<4xf16, strided<[1], offset: ?>> to memref<4xf16>
      %64 = bufferization.to_tensor %alloc_14 restrict : memref<4xf16>
      %inserted_slice = tensor.insert_slice %64 into %arg15[%61, 0] [1, 4] [1, 1] : tensor<4xf16> into tensor<16x4xf16>
      scf.yield %inserted_slice : tensor<16x4xf16>
    }
    %29 = scf.for %arg14 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg15 = %8) -> (tensor<16x16xf32>)  : i32 {
      %60 = scf.for %arg16 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg17 = %arg15) -> (tensor<16x16xf32>)  : i32 {
        %61 = arith.index_cast %1 : i32 to index
        %62 = arith.index_cast %arg16 : i32 to index
        %63 = memref.load %reinterpret_cast_5[%c0, %61, %c0, %62] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
        %64 = arith.cmpi sle, %63, %1 : i32
        %65 = scf.if %64 -> (tensor<16x16xf32>) {
          %66 = arith.index_cast %arg14 : i32 to index
          %67 = arith.index_cast %arg16 : i32 to index
          %inserted = tensor.insert %cst_4 into %arg17[%66, %67] : tensor<16x16xf32>
          scf.yield %inserted : tensor<16x16xf32>
        } else {
          %66 = arith.index_cast %arg14 : i32 to index
          %67 = arith.index_cast %arg16 : i32 to index
          %inserted = tensor.insert %cst_3 into %arg17[%66, %67] : tensor<16x16xf32>
          scf.yield %inserted : tensor<16x16xf32>
        }
        scf.yield %65 : tensor<16x16xf32>
      }
      scf.yield %60 : tensor<16x16xf32>
    }
    %30 = hivm.hir.mmadL1 {b_transpose} ins(%13, %27, %false, %c16, %c16, %c32 : tensor<16x32xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%29 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %31 = hivm.hir.mmadL1 {b_transpose} ins(%14, %28, %false, %c16, %c16, %c4 : tensor<16x4xf16>, tensor<16x4xf16>, i1, index, index, index) outs(%30 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %32 = hivm.hir.vreduce <max> ins(%31 : tensor<16x16xf32>) outs(%21 : tensor<16x1xf32>) reduce_dims = [1] -> tensor<16x1xf32>
    %33 = hivm.hir.vmax ins(%11, %32 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%11 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %34 = hivm.hir.vmax ins(%33, %11 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%33 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %35 = hivm.hir.vsub ins(%11, %34 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%19 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %36 = hivm.hir.vmul ins(%35, %cst_2 : tensor<16x1xf32>, f32) outs(%20 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %37 = hivm.hir.vexp ins(%36 : tensor<16x1xf32>) outs(%35 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %38 = hivm.hir.vbrc ins(%34 : tensor<16x1xf32>) outs(%23 : tensor<16x16xf32>) broadcast_dims = [1] -> tensor<16x16xf32>
    %39 = hivm.hir.vmul ins(%31, %cst_1 : tensor<16x16xf32>, f32) outs(%22 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %40 = hivm.hir.vmul ins(%38, %cst_1 : tensor<16x16xf32>, f32) outs(%24 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %41 = hivm.hir.vsub ins(%39, %40 : tensor<16x16xf32>, tensor<16x16xf32>) outs(%31 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %42 = hivm.hir.vmul ins(%41, %cst_2 : tensor<16x16xf32>, f32) outs(%17 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %43 = hivm.hir.vexp ins(%42 : tensor<16x16xf32>) outs(%41 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %44 = hivm.hir.vreduce <sum> ins(%43 : tensor<16x16xf32>) outs(%18 : tensor<16x1xf32>) reduce_dims = [1] -> tensor<16x1xf32>
    %45 = hivm.hir.vmul ins(%10, %37 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%25 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %46 = hivm.hir.vadd ins(%45, %44 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%10 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %47 = hivm.hir.vbrc ins(%37 : tensor<16x1xf32>) outs(%26 : tensor<16x32xf32>) broadcast_dims = [1] -> tensor<16x32xf32>
    %48 = hivm.hir.vmul ins(%9, %47 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%9 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %49 = tensor.empty() : tensor<16x16xf16>
    %50 = hivm.hir.vcast ins(%43 : tensor<16x16xf32>) outs(%49 : tensor<16x16xf16>) -> tensor<16x16xf16>
    %51 = hivm.hir.mmadL1 ins(%50, %27, %false, %c16, %c16, %c32 : tensor<16x16xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%48 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %52 = hivm.hir.vbrc ins(%46 : tensor<16x1xf32>) outs(%6 : tensor<16x32xf32>) broadcast_dims = [1] -> tensor<16x32xf32>
    %53 = hivm.hir.vdiv ins(%51, %52 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%51 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %54 = hivm.hir.vln ins(%46 : tensor<16x1xf32>) outs(%4 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %55 = hivm.hir.vmul ins(%54, %cst_0 : tensor<16x1xf32>, f32) outs(%46 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %56 = hivm.hir.vmul ins(%34, %cst_1 : tensor<16x1xf32>, f32) outs(%7 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %57 = hivm.hir.vadd ins(%55, %56 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%55 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %58 = tensor.empty() : tensor<16x32xf16>
    %59 = hivm.hir.vcast ins(%53 : tensor<16x32xf32>) outs(%58 : tensor<16x32xf16>) -> tensor<16x32xf16>
    %subview_11 = memref.subview %reinterpret_cast_8[0, %12, 0, 0] [1, 1, 16, 32] [1, 1, 1, 1] : memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>> to memref<16x32xf16, strided<[32, 1], offset: ?>>
    bufferization.materialize_in_destination %59 in writable %subview_11 : (tensor<16x32xf16>, memref<16x32xf16, strided<[32, 1], offset: ?>>) -> ()
    %extracted_slice = tensor.extract_slice %57[0, 0] [1, 16] [1, 1] : tensor<16x1xf32> to tensor<1x16xf32>
    %subview_12 = memref.subview %reinterpret_cast_6[0, %12, 0] [1, 1, 16] [1, 1, 1] : memref<1x8x16xf32, strided<[128, 16, 1]>> to memref<1x16xf32, strided<[128, 1], offset: ?>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_12 : (tensor<1x16xf32>, memref<1x16xf32, strided<[128, 1], offset: ?>>) -> ()
    return
  }
}