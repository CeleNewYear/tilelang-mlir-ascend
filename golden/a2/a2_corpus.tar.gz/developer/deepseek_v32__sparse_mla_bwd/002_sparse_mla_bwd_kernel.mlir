module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @sparse_mla_bwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xi32>, %arg7: memref<?xf32>, %arg8: memref<?xf32>, %arg9: memref<?xf16>, %arg10: memref<?xf32>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %c288 = arith.constant 288 : index
    %c128 = arith.constant 128 : index
    %c16 = arith.constant 16 : index
    %c4096 = arith.constant 4096 : index
    %c512 = arith.constant 512 : index
    %c32 = arith.constant 32 : index
    %c4608 = arith.constant 4608 : index
    %c576 = arith.constant 576 : index
    %c36 = arith.constant 36 : index
    %c1 = arith.constant 1 : index
    %c2_i32 = arith.constant 2 : i32
    %cst = arith.constant 0.166666672 : f32
    %true = arith.constant true
    %cst_0 = arith.constant 0.693147182 : f32
    %cst_1 = arith.constant 0.240449175 : f32
    %c4_i32 = arith.constant 4 : i32
    %false = arith.constant false
    %cst_2 = arith.constant 0xFF800000 : f32
    %cst_3 = arith.constant 0.000000e+00 : f32
    %c0_i32 = arith.constant 0 : i32
    %c8_i32 = arith.constant 8 : i32
    %c16_i32 = arith.constant 16 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 16, 36], strides: [%c4608, %c576, %c36, %c1] : memref<?xf16> to memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 8, 16, 32], strides: [%c4096, %c512, %c32, %c1] : memref<?xf16> to memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [1, 8, 16, 36], strides: [%c4608, %c576, %c36, %c1] : memref<?xf16> to memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 8, 16], strides: [%c128, %c16, %c1] : memref<?xf32> to memref<1x8x16xf32, strided<[128, 16, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [1, 8, 16], strides: [%c128, %c16, %c1] : memref<?xf32> to memref<1x8x16xf32, strided<[128, 16, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 8, 1, 36], strides: [%c288, %c36, %c36, %c1] : memref<?xf16> to memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1, 8, 1, 16], strides: [%c128, %c16, %c16, %c1] : memref<?xi32> to memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [1, 8, 1, 36], strides: [%c288, %c36, %c36, %c1] : memref<?xf32> to memref<1x8x1x36xf32, strided<[288, 36, 36, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16x32xf32>
    %3 = tensor.empty() : tensor<16x4xf32>
    %4 = tensor.empty() : tensor<1x8x16xf32>
    %5 = tensor.empty() : tensor<1x8x16xf32>
    %6 = tensor.empty() : tensor<16x16xf32>
    %7 = tensor.empty() : tensor<16x32xf32>
    %8 = tensor.empty() : tensor<16x4xf32>
    %9 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %9, 0, 0] [1, 1, 16, 32] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x32xf16, strided<[36, 1], offset: ?>>
    %alloc = memref.alloc() : memref<16x32xf16>
    memref.copy %subview, %alloc : memref<16x32xf16, strided<[36, 1], offset: ?>> to memref<16x32xf16>
    %10 = bufferization.to_tensor %alloc restrict : memref<16x32xf16>
    %subview_11 = memref.subview %reinterpret_cast[0, %9, 0, 32] [1, 1, 16, 4] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x4xf16, strided<[36, 1], offset: ?>>
    %alloc_12 = memref.alloc() : memref<16x4xf16>
    memref.copy %subview_11, %alloc_12 : memref<16x4xf16, strided<[36, 1], offset: ?>> to memref<16x4xf16>
    %11 = bufferization.to_tensor %alloc_12 restrict : memref<16x4xf16>
    %subview_13 = memref.subview %reinterpret_cast_4[0, %9, 0, 0] [1, 1, 16, 32] [1, 1, 1, 1] : memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>> to memref<16x32xf16, strided<[32, 1], offset: ?>>
    %alloc_14 = memref.alloc() : memref<16x32xf16>
    memref.copy %subview_13, %alloc_14 : memref<16x32xf16, strided<[32, 1], offset: ?>> to memref<16x32xf16>
    %12 = bufferization.to_tensor %alloc_14 restrict : memref<16x32xf16>
    %13 = hivm.hir.vbrc ins(%cst_3 : f32) outs(%2 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %14 = hivm.hir.vbrc ins(%cst_3 : f32) outs(%3 : tensor<16x4xf32>) -> tensor<16x4xf32>
    %subview_15 = memref.subview %reinterpret_cast_6[0, 0, 0] [1, 8, 16] [1, 1, 1] : memref<1x8x16xf32, strided<[128, 16, 1]>> to memref<8x16xf32, strided<[16, 1]>>
    %alloc_16 = memref.alloc() : memref<8x16xf32>
    memref.copy %subview_15, %alloc_16 : memref<8x16xf32, strided<[16, 1]>> to memref<8x16xf32>
    %15 = bufferization.to_tensor %alloc_16 restrict : memref<8x16xf32>
    %inserted_slice = tensor.insert_slice %15 into %4[0, 0, 0] [1, 8, 16] [1, 1, 1] : tensor<8x16xf32> into tensor<1x8x16xf32>
    %expanded = tensor.expand_shape %inserted_slice [[0], [1], [2, 3]] output_shape [1, 8, 16, 1] : tensor<1x8x16xf32> into tensor<1x8x16x1xf32>
    %subview_17 = memref.subview %reinterpret_cast_7[0, 0, 0] [1, 8, 16] [1, 1, 1] : memref<1x8x16xf32, strided<[128, 16, 1]>> to memref<8x16xf32, strided<[16, 1]>>
    %alloc_18 = memref.alloc() : memref<8x16xf32>
    memref.copy %subview_17, %alloc_18 : memref<8x16xf32, strided<[16, 1]>> to memref<8x16xf32>
    %16 = bufferization.to_tensor %alloc_18 restrict : memref<8x16xf32>
    %inserted_slice_19 = tensor.insert_slice %16 into %5[0, 0, 0] [1, 8, 16] [1, 1, 1] : tensor<8x16xf32> into tensor<1x8x16xf32>
    %expanded_20 = tensor.expand_shape %inserted_slice_19 [[0], [1], [2, 3]] output_shape [1, 8, 16, 1] : tensor<1x8x16xf32> into tensor<1x8x16x1xf32>
    %17 = tensor.empty() : tensor<16x32xf16>
    %18 = tensor.empty() : tensor<16x4xf16>
    %19 = tensor.empty() : tensor<16x16xf32>
    %20 = tensor.empty() : tensor<16x16xf32>
    %21 = tensor.empty() : tensor<1x1x16x16xf32>
    %22 = tensor.empty() : tensor<1x1x16x16xf32>
    %23 = tensor.empty() : tensor<1x1x16x16xf32>
    %24 = tensor.empty() : tensor<1x1x16x16xf32>
    %25 = tensor.empty() : tensor<1x1x16x16xf32>
    %26 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %6) -> (tensor<16x16xf32>)  : i32 {
      %55 = scf.for %arg19 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg20 = %arg18) -> (tensor<16x16xf32>)  : i32 {
        %56 = arith.index_cast %1 : i32 to index
        %57 = arith.index_cast %arg19 : i32 to index
        %58 = memref.load %reinterpret_cast_9[%c0, %56, %c0, %57] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
        %59 = arith.cmpi sle, %58, %1 : i32
        %60 = scf.if %59 -> (tensor<16x16xf32>) {
          %61 = arith.index_cast %arg17 : i32 to index
          %62 = arith.index_cast %arg19 : i32 to index
          %inserted = tensor.insert %cst_3 into %arg20[%61, %62] : tensor<16x16xf32>
          scf.yield %inserted : tensor<16x16xf32>
        } else {
          %61 = arith.index_cast %arg17 : i32 to index
          %62 = arith.index_cast %arg19 : i32 to index
          %inserted = tensor.insert %cst_2 into %arg20[%61, %62] : tensor<16x16xf32>
          scf.yield %inserted : tensor<16x16xf32>
        }
        scf.yield %60 : tensor<16x16xf32>
      }
      scf.yield %55 : tensor<16x16xf32>
    }
    %27 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %17) -> (tensor<16x32xf16>)  : i32 {
      %55 = arith.index_cast %1 : i32 to index
      %56 = arith.index_cast %arg17 : i32 to index
      %57 = memref.load %reinterpret_cast_9[%c0, %55, %c0, %56] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
      %58 = arith.index_cast %57 : i32 to index
      %subview_28 = memref.subview %reinterpret_cast_8[0, %58, 0, 0] [1, 1, 1, 32] [1, 1, 1, 1] : memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>> to memref<32xf16, strided<[1], offset: ?>>
      %alloc_29 = memref.alloc() : memref<32xf16>
      memref.copy %subview_28, %alloc_29 : memref<32xf16, strided<[1], offset: ?>> to memref<32xf16>
      %59 = bufferization.to_tensor %alloc_29 restrict : memref<32xf16>
      %inserted_slice_30 = tensor.insert_slice %59 into %arg18[%56, 0] [1, 32] [1, 1] : tensor<32xf16> into tensor<16x32xf16>
      scf.yield %inserted_slice_30 : tensor<16x32xf16>
    }
    %28 = hivm.hir.mmadL1 {b_transpose} ins(%10, %27, %false, %c16, %c16, %c32 : tensor<16x32xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%26 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %29 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %18) -> (tensor<16x4xf16>)  : i32 {
      %55 = arith.index_cast %1 : i32 to index
      %56 = arith.index_cast %arg17 : i32 to index
      %57 = memref.load %reinterpret_cast_9[%c0, %55, %c0, %56] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
      %58 = arith.index_cast %57 : i32 to index
      %subview_28 = memref.subview %reinterpret_cast_8[0, %58, 0, 32] [1, 1, 1, 4] [1, 1, 1, 1] : memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>> to memref<4xf16, strided<[1], offset: ?>>
      %alloc_29 = memref.alloc() : memref<4xf16>
      memref.copy %subview_28, %alloc_29 : memref<4xf16, strided<[1], offset: ?>> to memref<4xf16>
      %59 = bufferization.to_tensor %alloc_29 restrict : memref<4xf16>
      %inserted_slice_30 = tensor.insert_slice %59 into %arg18[%56, 0] [1, 4] [1, 1] : tensor<4xf16> into tensor<16x4xf16>
      scf.yield %inserted_slice_30 : tensor<16x4xf16>
    }
    %30 = hivm.hir.mmadL1 {b_transpose} ins(%11, %29, %false, %c16, %c16, %c4 : tensor<16x4xf16>, tensor<16x4xf16>, i1, index, index, index) outs(%28 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %expanded_21 = tensor.expand_shape %30 [[0, 1, 2], [3]] output_shape [1, 1, 16, 16] : tensor<16x16xf32> into tensor<1x1x16x16xf32>
    %extracted_slice = tensor.extract_slice %expanded[0, %9, 0, 0] [1, 1, 16, 1] [1, 1, 1, 1] : tensor<1x8x16x1xf32> to tensor<1x1x16x1xf32>
    %31 = hivm.hir.vbrc ins(%extracted_slice : tensor<1x1x16x1xf32>) outs(%22 : tensor<1x1x16x16xf32>) broadcast_dims = [3] -> tensor<1x1x16x16xf32>
    %32 = hivm.hir.vmul ins(%expanded_21, %cst_1 : tensor<1x1x16x16xf32>, f32) outs(%21 : tensor<1x1x16x16xf32>) -> tensor<1x1x16x16xf32>
    %33 = hivm.hir.vsub ins(%32, %31 : tensor<1x1x16x16xf32>, tensor<1x1x16x16xf32>) outs(%expanded_21 : tensor<1x1x16x16xf32>) -> tensor<1x1x16x16xf32>
    %collapsed = tensor.collapse_shape %33 [[0, 1, 2], [3]] : tensor<1x1x16x16xf32> into tensor<16x16xf32>
    %34 = hivm.hir.vmul ins(%collapsed, %cst_0 : tensor<16x16xf32>, f32) outs(%19 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %35 = hivm.hir.vexp ins(%34 : tensor<16x16xf32>) outs(%collapsed : tensor<16x16xf32>) -> tensor<16x16xf32>
    %expanded_22 = tensor.expand_shape %35 [[0, 1, 2], [3]] output_shape [1, 1, 16, 16] : tensor<16x16xf32> into tensor<1x1x16x16xf32>
    %36 = tensor.empty() : tensor<16x16xf16>
    %37 = hivm.hir.vcast ins(%35 : tensor<16x16xf32>) outs(%36 : tensor<16x16xf16>) -> tensor<16x16xf16>
    %38 = hivm.hir.mmadL1 {b_transpose} ins(%12, %27, %true, %c16, %c16, %c32 : tensor<16x32xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%20 : tensor<16x16xf32>) -> tensor<16x16xf32>
    %expanded_23 = tensor.expand_shape %38 [[0, 1, 2], [3]] output_shape [1, 1, 16, 16] : tensor<16x16xf32> into tensor<1x1x16x16xf32>
    %extracted_slice_24 = tensor.extract_slice %expanded_20[0, %9, 0, 0] [1, 1, 16, 1] [1, 1, 1, 1] : tensor<1x8x16x1xf32> to tensor<1x1x16x1xf32>
    %39 = hivm.hir.vbrc ins(%extracted_slice_24 : tensor<1x1x16x1xf32>) outs(%23 : tensor<1x1x16x16xf32>) broadcast_dims = [3] -> tensor<1x1x16x16xf32>
    %40 = hivm.hir.vsub ins(%expanded_23, %39 : tensor<1x1x16x16xf32>, tensor<1x1x16x16xf32>) outs(%24 : tensor<1x1x16x16xf32>) -> tensor<1x1x16x16xf32>
    %41 = hivm.hir.vmul ins(%expanded_22, %40 : tensor<1x1x16x16xf32>, tensor<1x1x16x16xf32>) outs(%25 : tensor<1x1x16x16xf32>) -> tensor<1x1x16x16xf32>
    %42 = hivm.hir.vmul ins(%41, %cst : tensor<1x1x16x16xf32>, f32) outs(%expanded_23 : tensor<1x1x16x16xf32>) -> tensor<1x1x16x16xf32>
    %collapsed_25 = tensor.collapse_shape %42 [[0, 1, 2], [3]] : tensor<1x1x16x16xf32> into tensor<16x16xf32>
    %43 = tensor.empty() : tensor<16x16xf16>
    %44 = hivm.hir.vcast ins(%collapsed_25 : tensor<16x16xf32>) outs(%43 : tensor<16x16xf16>) -> tensor<16x16xf16>
    %45 = hivm.hir.mmadL1 ins(%44, %27, %false, %c16, %c16, %c32 : tensor<16x16xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%13 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %46 = hivm.hir.mmadL1 ins(%44, %29, %false, %c16, %c16, %c4 : tensor<16x16xf16>, tensor<16x4xf16>, i1, index, index, index) outs(%14 : tensor<16x4xf32>) -> tensor<16x4xf32>
    %47 = hivm.hir.mmadL1 {a_transpose} ins(%44, %10, %true, %c16, %c16, %c32 : tensor<16x16xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%7 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %48 = hivm.hir.mmadL1 {a_transpose} ins(%37, %12, %false, %c16, %c16, %c32 : tensor<16x16xf16>, tensor<16x32xf16>, i1, index, index, index) outs(%47 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %49 = hivm.hir.vbrc ins(%cst_3 : f32) outs(%8 : tensor<16x4xf32>) -> tensor<16x4xf32>
    %50 = hivm.hir.mmadL1 {a_transpose} ins(%44, %11, %false, %c16, %c16, %c4 : tensor<16x16xf16>, tensor<16x4xf16>, i1, index, index, index) outs(%49 : tensor<16x4xf32>) -> tensor<16x4xf32>
    scf.for %arg17 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
      %55 = arith.muli %arg17, %c8_i32 : i32
      %56 = arith.index_cast %55 : i32 to index
      %extracted_slice_28 = tensor.extract_slice %48[%56, 0] [8, 32] [1, 1] : tensor<16x32xf32> to tensor<8x32xf32>
      %extracted_slice_29 = tensor.extract_slice %50[%56, 0] [8, 4] [1, 1] : tensor<16x4xf32> to tensor<8x4xf32>
      scf.for %arg18 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
        scf.for %arg19 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
          %57 = arith.index_cast %1 : i32 to index
          %58 = arith.muli %arg17, %c8_i32 : i32
          %59 = arith.addi %58, %arg18 : i32
          %60 = arith.index_cast %59 : i32 to index
          %61 = memref.load %reinterpret_cast_9[%c0, %57, %c0, %60] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
          %62 = arith.cmpi sle, %61, %1 : i32
          scf.if %62 {
            %63 = arith.index_cast %arg18 : i32 to index
            %64 = arith.muli %arg19, %c4_i32 : i32
            %65 = arith.index_cast %64 : i32 to index
            %extracted_slice_30 = tensor.extract_slice %extracted_slice_28[%63, %65] [1, 4] [1, 1] : tensor<8x32xf32> to tensor<1x4xf32>
            %66 = arith.index_cast %1 : i32 to index
            %67 = arith.muli %arg17, %c8_i32 : i32
            %68 = arith.addi %67, %arg18 : i32
            %69 = arith.index_cast %68 : i32 to index
            %70 = memref.load %reinterpret_cast_9[%c0, %66, %c0, %69] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
            %71 = arith.index_cast %70 : i32 to index
            %subview_31 = memref.subview %reinterpret_cast_10[0, %71, 0, %65] [1, 1, 1, 4] [1, 1, 1, 1] : memref<1x8x1x36xf32, strided<[288, 36, 36, 1]>> to memref<1x1x1x4xf32, strided<[288, 36, 36, 1], offset: ?>>
            %expanded_32 = tensor.expand_shape %extracted_slice_30 [[0, 1, 2], [3]] output_shape [1, 1, 1, 4] : tensor<1x4xf32> into tensor<1x1x1x4xf32>
            hivm.hir.store ins(%expanded_32 : tensor<1x1x1x4xf32>) outs(%subview_31 : memref<1x1x1x4xf32, strided<[288, 36, 36, 1], offset: ?>>) atomic = <add>
          }
        }
      }
      scf.for %arg18 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
        %57 = arith.index_cast %1 : i32 to index
        %58 = arith.muli %arg17, %c8_i32 : i32
        %59 = arith.addi %58, %arg18 : i32
        %60 = arith.index_cast %59 : i32 to index
        %61 = memref.load %reinterpret_cast_9[%c0, %57, %c0, %60] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
        %62 = arith.cmpi sle, %61, %1 : i32
        scf.if %62 {
          %63 = arith.index_cast %arg18 : i32 to index
          %extracted_slice_30 = tensor.extract_slice %extracted_slice_29[%63, 0] [1, 4] [1, 1] : tensor<8x4xf32> to tensor<1x4xf32>
          %64 = arith.index_cast %1 : i32 to index
          %65 = arith.muli %arg17, %c8_i32 : i32
          %66 = arith.addi %65, %arg18 : i32
          %67 = arith.index_cast %66 : i32 to index
          %68 = memref.load %reinterpret_cast_9[%c0, %64, %c0, %67] : memref<1x8x1x16xi32, strided<[128, 16, 16, 1]>>
          %69 = arith.index_cast %68 : i32 to index
          %subview_31 = memref.subview %reinterpret_cast_10[0, %69, 0, 32] [1, 1, 1, 4] [1, 1, 1, 1] : memref<1x8x1x36xf32, strided<[288, 36, 36, 1]>> to memref<1x1x1x4xf32, strided<[288, 36, 36, 1], offset: ?>>
          %expanded_32 = tensor.expand_shape %extracted_slice_30 [[0, 1, 2], [3]] output_shape [1, 1, 1, 4] : tensor<1x4xf32> into tensor<1x1x1x4xf32>
          hivm.hir.store ins(%expanded_32 : tensor<1x1x1x4xf32>) outs(%subview_31 : memref<1x1x1x4xf32, strided<[288, 36, 36, 1], offset: ?>>) atomic = <add>
        }
      }
    }
    %51 = tensor.empty() : tensor<16x32xf16>
    %52 = hivm.hir.vcast ins(%45 : tensor<16x32xf32>) outs(%51 : tensor<16x32xf16>) -> tensor<16x32xf16>
    %53 = tensor.empty() : tensor<16x4xf16>
    %54 = hivm.hir.vcast ins(%46 : tensor<16x4xf32>) outs(%53 : tensor<16x4xf16>) -> tensor<16x4xf16>
    %subview_26 = memref.subview %reinterpret_cast_5[0, %9, 0, 0] [1, 1, 16, 32] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x32xf16, strided<[36, 1], offset: ?>>
    bufferization.materialize_in_destination %52 in writable %subview_26 : (tensor<16x32xf16>, memref<16x32xf16, strided<[36, 1], offset: ?>>) -> ()
    %subview_27 = memref.subview %reinterpret_cast_5[0, %9, 0, 32] [1, 1, 16, 4] [1, 1, 1, 1] : memref<1x8x16x36xf16, strided<[4608, 576, 36, 1]>> to memref<16x4xf16, strided<[36, 1], offset: ?>>
    bufferization.materialize_in_destination %54 in writable %subview_27 : (tensor<16x4xf16>, memref<16x4xf16, strided<[36, 1], offset: ?>>) -> ()
    return
  }
}