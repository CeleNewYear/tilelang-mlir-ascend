module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @preprocess_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf32>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c128 = arith.constant 128 : index
    %c16 = arith.constant 16 : index
    %c4096 = arith.constant 4096 : index
    %c512 = arith.constant 512 : index
    %c32 = arith.constant 32 : index
    %c1 = arith.constant 1 : index
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 16, 32], strides: [%c4096, %c512, %c32, %c1] : memref<?xf16> to memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 8, 16], strides: [%c128, %c16, %c1] : memref<?xf32> to memref<1x8x16xf32, strided<[128, 16, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 8, 16, 32], strides: [%c4096, %c512, %c32, %c1] : memref<?xf16> to memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<32x1xf32>
    %3 = tensor.empty() : tensor<32x32xf32>
    %4 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %5 = tensor.empty() : tensor<32x32xf32>
    %6 = tensor.empty() : tensor<32x32xf32>
    %7 = tensor.empty() : tensor<32x32xf32>
    %8 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, 0, %8, 0] [1, 32, 1, 32] [1, 1, 1, 1] : memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>> to memref<32x32xf16, strided<[512, 1], offset: ?>>
    %alloc = memref.alloc() : memref<32x32xf16>
    memref.copy %subview, %alloc : memref<32x32xf16, strided<[512, 1], offset: ?>> to memref<32x32xf16>
    %9 = bufferization.to_tensor %alloc restrict : memref<32x32xf16>
    %10 = hivm.hir.vcast ins(%9 : tensor<32x32xf16>) outs(%5 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %subview_2 = memref.subview %reinterpret_cast_1[0, 0, %8, 0] [1, 32, 1, 32] [1, 1, 1, 1] : memref<1x8x16x32xf16, strided<[4096, 512, 32, 1]>> to memref<32x32xf16, strided<[512, 1], offset: ?>>
    %alloc_3 = memref.alloc() : memref<32x32xf16>
    memref.copy %subview_2, %alloc_3 : memref<32x32xf16, strided<[512, 1], offset: ?>> to memref<32x32xf16>
    %11 = bufferization.to_tensor %alloc_3 restrict : memref<32x32xf16>
    %12 = hivm.hir.vcast ins(%11 : tensor<32x32xf16>) outs(%6 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %13 = hivm.hir.vmul ins(%10, %12 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%7 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %14 = hivm.hir.vadd ins(%4, %13 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%4 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %15 = hivm.hir.vreduce <sum> ins(%14 : tensor<32x32xf32>) outs(%2 : tensor<32x1xf32>) reduce_dims = [1] -> tensor<32x1xf32>
    %16 = arith.index_cast %1 : i32 to index
    %subview_4 = memref.subview %reinterpret_cast_0[0, 0, %16] [1, 32, 1] [1, 1, 1] : memref<1x8x16xf32, strided<[128, 16, 1]>> to memref<32x1xf32, strided<[16, 1], offset: ?>>
    bufferization.materialize_in_destination %15 in writable %subview_4 : (tensor<32x1xf32>, memref<32x1xf32, strided<[16, 1], offset: ?>>) -> ()
    return
  }
}