module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @postprocess_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf16>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c288 = arith.constant 288 : index
    %c36 = arith.constant 36 : index
    %c1 = arith.constant 1 : index
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 1, 36], strides: [%c288, %c36, %c36, %c1] : memref<?xf32> to memref<1x8x1x36xf32, strided<[288, 36, 36, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 8, 1, 36], strides: [%c288, %c36, %c36, %c1] : memref<?xf16> to memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>>
    %subview = memref.subview %reinterpret_cast[0, 0, 0, 0] [1, 64, 1, 36] [1, 1, 1, 1] : memref<1x8x1x36xf32, strided<[288, 36, 36, 1]>> to memref<64x36xf32, strided<[36, 1]>>
    %alloc = memref.alloc() : memref<64x36xf32>
    memref.copy %subview, %alloc : memref<64x36xf32, strided<[36, 1]>> to memref<64x36xf32>
    %0 = bufferization.to_tensor %alloc restrict : memref<64x36xf32>
    %1 = tensor.empty() : tensor<64x36xf16>
    %2 = hivm.hir.vcast ins(%0 : tensor<64x36xf32>) outs(%1 : tensor<64x36xf16>) -> tensor<64x36xf16>
    %subview_1 = memref.subview %reinterpret_cast_0[0, 0, 0, 0] [1, 64, 1, 36] [1, 1, 1, 1] : memref<1x8x1x36xf16, strided<[288, 36, 36, 1]>> to memref<64x36xf16, strided<[36, 1]>>
    bufferization.materialize_in_destination %2 in writable %subview_1 : (tensor<64x36xf16>, memref<64x36xf16, strided<[36, 1]>>) -> ()
    return
  }
}