module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf16>, %arg8: memref<?xf16>, %arg9: memref<?xf16>, %arg10: memref<?xf16>, %arg11: memref<?xf16>, %arg12: memref<?xf16>, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %c2304 = arith.constant 2304 : index
    %c256 = arith.constant 256 : index
    %c32 = arith.constant 32 : index
    %c1 = arith.constant 1 : index
    %c8_i32 = arith.constant 8 : i32
    %c2_i32 = arith.constant 2 : i32
    %c3_i32 = arith.constant 3 : i32
    %cst = arith.constant 1.000000e+00 : f32
    %cst_0 = arith.constant 0.000000e+00 : f32
    %cst_1 = arith.constant 6.400000e+01 : f32
    %cst_2 = arith.constant 9.99999997E-7 : f32
    %cst_3 = arith.constant 1.562500e-02 : f32
    %c0_i32 = arith.constant 0 : i32
    %c256_i32 = arith.constant 256 : i32
    %c32_i32 = arith.constant 32 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 32], strides: [%c32, %c1] : memref<?xf16> to memref<2x32xf16, strided<[32, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [2, 9, 256], strides: [%c2304, %c256, %c1] : memref<?xf16> to memref<2x9x256xf16, strided<[2304, 256, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf16> to memref<256xf16, strided<[1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [32, 256], strides: [%c256, %c1] : memref<?xf16> to memref<32x256xf16, strided<[256, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [2, 256], strides: [%c256, %c1] : memref<?xf16> to memref<2x256xf16, strided<[256, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf16> to memref<256xf16, strided<[1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [2, 256], strides: [%c256, %c1] : memref<?xf16> to memref<2x256xf16, strided<[256, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [32, 256], strides: [%c256, %c1] : memref<?xf16> to memref<32x256xf16, strided<[256, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [2, 9, 256], strides: [%c2304, %c256, %c1] : memref<?xf16> to memref<2x9x256xf16, strided<[2304, 256, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [4, 256], strides: [%c256, %c1] : memref<?xf16> to memref<4x256xf16, strided<[256, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<256xf32>
    %3 = tensor.empty() : tensor<256xf32>
    %4 = tensor.empty() : tensor<1x256xf32>
    %5 = tensor.empty() : tensor<1x1xf32>
    %6 = tensor.empty() : tensor<1x256xf32>
    %7 = tensor.empty() : tensor<1x1xf32>
    %8 = tensor.empty() : tensor<1x256xf32>
    %9 = tensor.empty() : tensor<1x1xf32>
    %10 = tensor.empty() : tensor<1x1xf32>
    %11 = tensor.empty() : tensor<1x1xf32>
    %12 = tensor.empty() : tensor<256xf32>
    %13 = tensor.empty() : tensor<1x256xf32>
    %14 = tensor.empty() : tensor<1x1xf32>
    %15 = tensor.empty() : tensor<256xf32>
    %16 = tensor.empty() : tensor<256xf32>
    %17 = tensor.empty() : tensor<256xf32>
    %18 = tensor.empty() : tensor<256xf32>
    %19 = tensor.empty() : tensor<256xf32>
    %20 = tensor.empty() : tensor<256xf32>
    %21 = tensor.empty() : tensor<256xf32>
    %22 = tensor.empty() : tensor<256xf32>
    %23 = tensor.empty() : tensor<256xf32>
    %24 = tensor.empty() : tensor<256xf32>
    %25 = tensor.empty() : tensor<256xf32>
    %26 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[%26, 0] [1, 32] [1, 1] : memref<2x32xf16, strided<[32, 1]>> to memref<32xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<32xf16>
    memref.copy %subview, %alloc : memref<32xf16, strided<[1], offset: ?>> to memref<32xf16>
    %27 = bufferization.to_tensor %alloc restrict : memref<32xf16>
    %28 = tensor.empty() : tensor<32xf32>
    %29 = hivm.hir.vcast ins(%27 : tensor<32xf16>) outs(%28 : tensor<32xf32>) -> tensor<32xf32>
    %30 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%2 : tensor<256xf32>) -> tensor<256xf32>
    %31 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %32:2 = scf.for %arg19 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg20 = %30, %arg21 = %31) -> (tensor<256xf32>, tensor<256xf32>)  : i32 {
      %93 = arith.index_cast %arg19 : i32 to index
      %subview_37 = memref.subview %reinterpret_cast_10[%93, 0] [1, 256] [1, 1] : memref<32x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_38 = memref.alloc() : memref<256xf16>
      memref.copy %subview_37, %alloc_38 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %94 = bufferization.to_tensor %alloc_38 restrict : memref<256xf16>
      %95 = tensor.empty() : tensor<256xf32>
      %96 = hivm.hir.vcast ins(%94 : tensor<256xf16>) outs(%95 : tensor<256xf32>) -> tensor<256xf32>
      %subview_39 = memref.subview %reinterpret_cast_6[%93, 0] [1, 256] [1, 1] : memref<32x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_40 = memref.alloc() : memref<256xf16>
      memref.copy %subview_39, %alloc_40 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %97 = bufferization.to_tensor %alloc_40 restrict : memref<256xf16>
      %98 = tensor.empty() : tensor<256xf32>
      %99 = hivm.hir.vcast ins(%97 : tensor<256xf16>) outs(%98 : tensor<256xf32>) -> tensor<256xf32>
      %100 = scf.for %arg22 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg23 = %arg20) -> (tensor<256xf32>)  : i32 {
        %102 = arith.index_cast %arg22 : i32 to index
        %extracted_41 = tensor.extract %arg23[%102] : tensor<256xf32>
        %103 = arith.index_cast %arg19 : i32 to index
        %extracted_42 = tensor.extract %29[%103] : tensor<32xf32>
        %extracted_43 = tensor.extract %96[%102] : tensor<256xf32>
        %104 = arith.mulf %extracted_42, %extracted_43 : f32
        %105 = arith.addf %extracted_41, %104 : f32
        %inserted_44 = tensor.insert %105 into %arg23[%102] : tensor<256xf32>
        scf.yield %inserted_44 : tensor<256xf32>
      }
      %101 = scf.for %arg22 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg23 = %arg21) -> (tensor<256xf32>)  : i32 {
        %102 = arith.index_cast %arg22 : i32 to index
        %extracted_41 = tensor.extract %arg23[%102] : tensor<256xf32>
        %103 = arith.index_cast %arg19 : i32 to index
        %extracted_42 = tensor.extract %29[%103] : tensor<32xf32>
        %extracted_43 = tensor.extract %99[%102] : tensor<256xf32>
        %104 = arith.mulf %extracted_42, %extracted_43 : f32
        %105 = arith.addf %extracted_41, %104 : f32
        %inserted_44 = tensor.insert %105 into %arg23[%102] : tensor<256xf32>
        scf.yield %inserted_44 : tensor<256xf32>
      }
      scf.yield %100, %101 : tensor<256xf32>, tensor<256xf32>
    }
    %subview_13 = memref.subview %reinterpret_cast_9[%26, 0] [1, 256] [1, 1] : memref<2x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc_14 = memref.alloc() : memref<256xf16>
    memref.copy %subview_13, %alloc_14 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %33 = bufferization.to_tensor %alloc_14 restrict : memref<256xf16>
    %34 = tensor.empty() : tensor<256xf32>
    %35 = hivm.hir.vcast ins(%33 : tensor<256xf16>) outs(%34 : tensor<256xf32>) -> tensor<256xf32>
    %expanded = tensor.expand_shape %35 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_15 = tensor.expand_shape %35 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %36 = hivm.hir.vmul ins(%expanded, %expanded_15 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%4 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %37 = hivm.hir.vreduce <sum> ins(%36 : tensor<1x256xf32>) outs(%5 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %extracted = tensor.extract %37[%c0, %c0] : tensor<1x1xf32>
    %38 = arith.mulf %extracted, %cst_3 : f32
    %39 = arith.addf %38, %cst_2 : f32
    %inserted = tensor.insert %39 into %37[%c0, %c0] : tensor<1x1xf32>
    %40 = hivm.hir.vrsqrt ins(%inserted : tensor<1x1xf32>) outs(%inserted : tensor<1x1xf32>) -> tensor<1x1xf32>
    %alloc_16 = memref.alloc() : memref<256xf16>
    memref.copy %reinterpret_cast_8, %alloc_16 : memref<256xf16, strided<[1]>> to memref<256xf16>
    %41 = bufferization.to_tensor %alloc_16 restrict : memref<256xf16>
    %42 = tensor.empty() : tensor<256xf32>
    %43 = hivm.hir.vcast ins(%41 : tensor<256xf16>) outs(%42 : tensor<256xf32>) -> tensor<256xf32>
    %extracted_17 = tensor.extract %40[%c0, %c0] : tensor<1x1xf32>
    %44 = hivm.hir.vbrc ins(%extracted_17 : f32) outs(%17 : tensor<256xf32>) -> tensor<256xf32>
    %45 = hivm.hir.vmul ins(%35, %44 : tensor<256xf32>, tensor<256xf32>) outs(%18 : tensor<256xf32>) -> tensor<256xf32>
    %46 = hivm.hir.vmul ins(%45, %43 : tensor<256xf32>, tensor<256xf32>) outs(%35 : tensor<256xf32>) -> tensor<256xf32>
    %expanded_18 = tensor.expand_shape %32#0 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_19 = tensor.expand_shape %32#0 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %47 = hivm.hir.vmul ins(%expanded_18, %expanded_19 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%6 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %48 = hivm.hir.vreduce <sum> ins(%47 : tensor<1x256xf32>) outs(%7 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %49 = hivm.hir.vdiv ins(%48, %cst_1 : tensor<1x1xf32>, f32) outs(%48 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %50 = hivm.hir.vadd ins(%49, %cst_2 : tensor<1x1xf32>, f32) outs(%49 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %51 = hivm.hir.vrsqrt ins(%50 : tensor<1x1xf32>) outs(%50 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %extracted_20 = tensor.extract %51[%c0, %c0] : tensor<1x1xf32>
    %52 = hivm.hir.vbrc ins(%extracted_20 : f32) outs(%19 : tensor<256xf32>) -> tensor<256xf32>
    %53 = hivm.hir.vmul ins(%32#0, %52 : tensor<256xf32>, tensor<256xf32>) outs(%20 : tensor<256xf32>) -> tensor<256xf32>
    %54 = hivm.hir.vmul ins(%53, %43 : tensor<256xf32>, tensor<256xf32>) outs(%32#0 : tensor<256xf32>) -> tensor<256xf32>
    %expanded_21 = tensor.expand_shape %46 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_22 = tensor.expand_shape %54 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %55 = hivm.hir.vmul ins(%expanded_21, %expanded_22 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%8 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %56 = hivm.hir.vreduce <sum> ins(%55 : tensor<1x256xf32>) outs(%9 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %inserted_23 = tensor.insert %cst_1 into %10[%c0, %c0] : tensor<1x1xf32>
    %57 = hivm.hir.vsqrt ins(%inserted_23 : tensor<1x1xf32>) outs(%inserted_23 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %extracted_24 = tensor.extract %56[%c0, %c0] : tensor<1x1xf32>
    %extracted_25 = tensor.extract %57[%c0, %c0] : tensor<1x1xf32>
    %58 = arith.divf %extracted_24, %extracted_25 : f32
    %inserted_26 = tensor.insert %58 into %11[%c0, %c0] : tensor<1x1xf32>
    %59 = hivm.hir.vsub ins(%cst_0, %inserted_26 : f32, tensor<1x1xf32>) outs(%inserted_26 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %60 = hivm.hir.vexp ins(%59 : tensor<1x1xf32>) outs(%inserted_26 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %61 = hivm.hir.vadd ins(%60, %cst : tensor<1x1xf32>, f32) outs(%inserted_26 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %62 = hivm.hir.vdiv ins(%cst, %61 : f32, tensor<1x1xf32>) outs(%inserted_26 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %extracted_27 = tensor.extract %62[%c0, %c0] : tensor<1x1xf32>
    %63 = hivm.hir.vmul ins(%32#1, %extracted_27 : tensor<256xf32>, f32) outs(%12 : tensor<256xf32>) -> tensor<256xf32>
    %expanded_28 = tensor.expand_shape %63 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_29 = tensor.expand_shape %63 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %64 = hivm.hir.vmul ins(%expanded_28, %expanded_29 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%13 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %65 = hivm.hir.vreduce <sum> ins(%64 : tensor<1x256xf32>) outs(%14 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %66 = hivm.hir.vdiv ins(%65, %cst_1 : tensor<1x1xf32>, f32) outs(%65 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %67 = hivm.hir.vadd ins(%66, %cst_2 : tensor<1x1xf32>, f32) outs(%66 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %68 = hivm.hir.vrsqrt ins(%67 : tensor<1x1xf32>) outs(%67 : tensor<1x1xf32>) -> tensor<1x1xf32>
    %alloc_30 = memref.alloc() : memref<256xf16>
    memref.copy %reinterpret_cast_5, %alloc_30 : memref<256xf16, strided<[1]>> to memref<256xf16>
    %69 = bufferization.to_tensor %alloc_30 restrict : memref<256xf16>
    %70 = tensor.empty() : tensor<256xf32>
    %71 = hivm.hir.vcast ins(%69 : tensor<256xf16>) outs(%70 : tensor<256xf32>) -> tensor<256xf32>
    %extracted_31 = tensor.extract %68[%c0, %c0] : tensor<1x1xf32>
    %72 = hivm.hir.vbrc ins(%extracted_31 : f32) outs(%21 : tensor<256xf32>) -> tensor<256xf32>
    %73 = hivm.hir.vmul ins(%63, %72 : tensor<256xf32>, tensor<256xf32>) outs(%22 : tensor<256xf32>) -> tensor<256xf32>
    %74 = hivm.hir.vmul ins(%73, %71 : tensor<256xf32>, tensor<256xf32>) outs(%63 : tensor<256xf32>) -> tensor<256xf32>
    %75 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%15 : tensor<256xf32>) -> tensor<256xf32>
    %76 = scf.for %arg19 = %c0_i32 to %c3_i32 step %c1_i32 iter_args(%arg20 = %75) -> (tensor<256xf32>)  : i32 {
      %93 = tensor.empty() : tensor<256xf32>
      %94 = arith.index_cast %arg19 : i32 to index
      %subview_37 = memref.subview %reinterpret_cast_12[%94, 0] [1, 256] [1, 1] : memref<4x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_38 = memref.alloc() : memref<256xf16>
      memref.copy %subview_37, %alloc_38 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %95 = bufferization.to_tensor %alloc_38 restrict : memref<256xf16>
      %96 = tensor.empty() : tensor<256xf32>
      %97 = hivm.hir.vcast ins(%95 : tensor<256xf16>) outs(%96 : tensor<256xf32>) -> tensor<256xf32>
      %98 = arith.index_cast %1 : i32 to index
      %99 = arith.muli %arg19, %c2_i32 : i32
      %100 = arith.addi %99, %c3_i32 : i32
      %101 = arith.index_cast %100 : i32 to index
      %subview_39 = memref.subview %reinterpret_cast_4[%98, %101, 0] [1, 1, 256] [1, 1, 1] : memref<2x9x256xf16, strided<[2304, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_40 = memref.alloc() : memref<256xf16>
      memref.copy %subview_39, %alloc_40 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %102 = bufferization.to_tensor %alloc_40 restrict : memref<256xf16>
      %103 = tensor.empty() : tensor<256xf32>
      %104 = hivm.hir.vcast ins(%102 : tensor<256xf16>) outs(%103 : tensor<256xf32>) -> tensor<256xf32>
      %105 = hivm.hir.vmul ins(%97, %104 : tensor<256xf32>, tensor<256xf32>) outs(%93 : tensor<256xf32>) -> tensor<256xf32>
      %106 = hivm.hir.vadd ins(%arg20, %105 : tensor<256xf32>, tensor<256xf32>) outs(%arg20 : tensor<256xf32>) -> tensor<256xf32>
      scf.yield %106 : tensor<256xf32>
    }
    %subview_32 = memref.subview %reinterpret_cast_12[3, 0] [1, 256] [1, 1] : memref<4x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: 768>>
    %alloc_33 = memref.alloc() : memref<256xf16>
    memref.copy %subview_32, %alloc_33 : memref<256xf16, strided<[1], offset: 768>> to memref<256xf16>
    %77 = bufferization.to_tensor %alloc_33 restrict : memref<256xf16>
    %78 = tensor.empty() : tensor<256xf32>
    %79 = hivm.hir.vcast ins(%77 : tensor<256xf16>) outs(%78 : tensor<256xf32>) -> tensor<256xf32>
    %80 = hivm.hir.vmul ins(%79, %74 : tensor<256xf32>, tensor<256xf32>) outs(%23 : tensor<256xf32>) -> tensor<256xf32>
    %81 = hivm.hir.vadd ins(%76, %80 : tensor<256xf32>, tensor<256xf32>) outs(%76 : tensor<256xf32>) -> tensor<256xf32>
    scf.for %arg19 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
      %93 = arith.index_cast %1 : i32 to index
      %94 = arith.addi %arg19, %c1_i32 : i32
      %95 = arith.index_cast %94 : i32 to index
      %subview_37 = memref.subview %reinterpret_cast_4[%93, %95, 0] [1, 1, 256] [1, 1, 1] : memref<2x9x256xf16, strided<[2304, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_38 = memref.alloc() : memref<256xf16>
      memref.copy %subview_37, %alloc_38 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %96 = bufferization.to_tensor %alloc_38 restrict : memref<256xf16>
      %97 = arith.index_cast %arg19 : i32 to index
      %subview_39 = memref.subview %reinterpret_cast_11[%93, %97, 0] [1, 1, 256] [1, 1, 1] : memref<2x9x256xf16, strided<[2304, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      bufferization.materialize_in_destination %96 in writable %subview_39 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    }
    %82 = tensor.empty() : tensor<256xf16>
    %83 = hivm.hir.vcast ins(%74 : tensor<256xf32>) outs(%82 : tensor<256xf16>) -> tensor<256xf16>
    %subview_34 = memref.subview %reinterpret_cast_11[%26, 8, 0] [1, 1, 256] [1, 1, 1] : memref<2x9x256xf16, strided<[2304, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %83 in writable %subview_34 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    %84 = hivm.hir.vsub ins(%cst_0, %81 : f32, tensor<256xf32>) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    %85 = hivm.hir.vexp ins(%84 : tensor<256xf32>) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    %86 = hivm.hir.vadd ins(%85, %cst : tensor<256xf32>, f32) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    %87 = hivm.hir.vdiv ins(%cst, %86 : f32, tensor<256xf32>) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    %extracted_35 = tensor.extract %62[%c0, %c0] : tensor<1x1xf32>
    %88 = hivm.hir.vmul ins(%81, %87 : tensor<256xf32>, tensor<256xf32>) outs(%24 : tensor<256xf32>) -> tensor<256xf32>
    %89 = hivm.hir.vmul ins(%32#1, %extracted_35 : tensor<256xf32>, f32) outs(%25 : tensor<256xf32>) -> tensor<256xf32>
    %90 = hivm.hir.vadd ins(%88, %89 : tensor<256xf32>, tensor<256xf32>) outs(%81 : tensor<256xf32>) -> tensor<256xf32>
    %91 = tensor.empty() : tensor<256xf16>
    %92 = hivm.hir.vcast ins(%90 : tensor<256xf32>) outs(%91 : tensor<256xf16>) -> tensor<256xf16>
    %subview_36 = memref.subview %reinterpret_cast_7[%26, 0] [1, 256] [1, 1] : memref<2x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %92 in writable %subview_36 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    return
  }
}