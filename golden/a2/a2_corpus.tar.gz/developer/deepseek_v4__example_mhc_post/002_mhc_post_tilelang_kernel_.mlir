module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @mhc_post_tilelang_kernel_(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf16>, %arg5: memref<?xf32>, %arg6: memref<?xf16>, %arg7: memref<?xf16>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c28672 = arith.constant 28672 : index
    %c7168 = arith.constant 7168 : index
    %c16 = arith.constant 16 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c1024_i32 = arith.constant 1024 : i32
    %c7_i32 = arith.constant 7 : i32
    %c0_i32 = arith.constant 0 : i32
    %c4_i32 = arith.constant 4 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %0 = arith.index_cast %arg8 : i32 to index
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [%0, 4, 4], strides: [%c16, %c4, %c1] : memref<?xf32> to memref<?x4x4xf32, strided<[?, ?, ?]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [%0, 4], strides: [%c4, %c1] : memref<?xf32> to memref<?x4xf32, strided<[?, ?]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [%0, 4, 7168], strides: [%c28672, %c7168, %c1] : memref<?xf16> to memref<?x4x7168xf16, strided<[?, ?, ?]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [%0, 4, 7168], strides: [%c28672, %c7168, %c1] : memref<?xf16> to memref<?x4x7168xf16, strided<[?, ?, ?]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [%0, 7168], strides: [%c7168, %c1] : memref<?xf16> to memref<?x7168xf16, strided<[?, ?]>>
    %1 = hivm.hir.get_block_idx -> i64
    %2 = arith.trunci %1 : i64 to i32
    %3 = arith.index_cast %2 : i32 to index
    %subview = memref.subview %reinterpret_cast[%3, 0, 0] [1, 4, 4] [1, 1, 1] : memref<?x4x4xf32, strided<[?, ?, ?]>> to memref<4x4xf32, strided<[?, ?], offset: ?>>
    %alloc = memref.alloc() : memref<4x4xf32>
    memref.copy %subview, %alloc : memref<4x4xf32, strided<[?, ?], offset: ?>> to memref<4x4xf32>
    %4 = bufferization.to_tensor %alloc restrict : memref<4x4xf32>
    %subview_4 = memref.subview %reinterpret_cast_0[%3, 0] [1, 4] [1, 1] : memref<?x4xf32, strided<[?, ?]>> to memref<4xf32, strided<[?], offset: ?>>
    %alloc_5 = memref.alloc() : memref<4xf32>
    memref.copy %subview_4, %alloc_5 : memref<4xf32, strided<[?], offset: ?>> to memref<4xf32>
    %5 = bufferization.to_tensor %alloc_5 restrict : memref<4xf32>
    scf.for %arg15 = %c0_i32 to %c7_i32 step %c1_i32  : i32 {
      %6 = tensor.empty() : tensor<4x1024xf32>
      %7 = arith.index_cast %2 : i32 to index
      %8 = arith.muli %arg15, %c1024_i32 : i32
      %9 = arith.index_cast %8 : i32 to index
      %subview_6 = memref.subview %reinterpret_cast_2[%7, 0, %9] [1, 4, 1024] [1, 1, 1] : memref<?x4x7168xf16, strided<[?, ?, ?]>> to memref<4x1024xf16, strided<[?, ?], offset: ?>>
      %alloc_7 = memref.alloc() : memref<4x1024xf16>
      memref.copy %subview_6, %alloc_7 : memref<4x1024xf16, strided<[?, ?], offset: ?>> to memref<4x1024xf16>
      %10 = bufferization.to_tensor %alloc_7 restrict : memref<4x1024xf16>
      %subview_8 = memref.subview %reinterpret_cast_3[%7, %9] [1, 1024] [1, 1] : memref<?x7168xf16, strided<[?, ?]>> to memref<1024xf16, strided<[?], offset: ?>>
      %alloc_9 = memref.alloc() : memref<1024xf16>
      memref.copy %subview_8, %alloc_9 : memref<1024xf16, strided<[?], offset: ?>> to memref<1024xf16>
      %11 = bufferization.to_tensor %alloc_9 restrict : memref<1024xf16>
      %12 = tensor.empty() : tensor<4x1024xf32>
      %13 = hivm.hir.vcast ins(%10 : tensor<4x1024xf16>) outs(%12 : tensor<4x1024xf32>) -> tensor<4x1024xf32>
      %14 = tensor.empty() : tensor<1024xf32>
      %15 = hivm.hir.vcast ins(%11 : tensor<1024xf16>) outs(%14 : tensor<1024xf32>) -> tensor<1024xf32>
      %16 = scf.for %arg16 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg17 = %6) -> (tensor<4x1024xf32>)  : i32 {
        %20 = scf.for %arg18 = %c0_i32 to %c1024_i32 step %c1_i32 iter_args(%arg19 = %arg17) -> (tensor<4x1024xf32>)  : i32 {
          %21 = arith.index_cast %arg16 : i32 to index
          %extracted = tensor.extract %5[%21] : tensor<4xf32>
          %22 = arith.index_cast %arg18 : i32 to index
          %extracted_11 = tensor.extract %15[%22] : tensor<1024xf32>
          %23 = arith.mulf %extracted, %extracted_11 : f32
          %inserted = tensor.insert %23 into %arg19[%21, %22] : tensor<4x1024xf32>
          scf.yield %inserted : tensor<4x1024xf32>
        }
        scf.yield %20 : tensor<4x1024xf32>
      }
      %17 = scf.for %arg16 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg17 = %16) -> (tensor<4x1024xf32>)  : i32 {
        %20 = scf.for %arg18 = %c0_i32 to %c1024_i32 step %c1_i32 iter_args(%arg19 = %arg17) -> (tensor<4x1024xf32>)  : i32 {
          %21 = scf.for %arg20 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg21 = %arg19) -> (tensor<4x1024xf32>)  : i32 {
            %22 = arith.index_cast %arg16 : i32 to index
            %23 = arith.index_cast %arg18 : i32 to index
            %extracted = tensor.extract %arg21[%22, %23] : tensor<4x1024xf32>
            %24 = arith.index_cast %arg20 : i32 to index
            %extracted_11 = tensor.extract %4[%24, %22] : tensor<4x4xf32>
            %extracted_12 = tensor.extract %13[%24, %23] : tensor<4x1024xf32>
            %25 = arith.mulf %extracted_11, %extracted_12 : f32
            %26 = arith.addf %extracted, %25 : f32
            %inserted = tensor.insert %26 into %arg21[%22, %23] : tensor<4x1024xf32>
            scf.yield %inserted : tensor<4x1024xf32>
          }
          scf.yield %21 : tensor<4x1024xf32>
        }
        scf.yield %20 : tensor<4x1024xf32>
      }
      %18 = tensor.empty() : tensor<4x1024xf16>
      %19 = hivm.hir.vcast ins(%17 : tensor<4x1024xf32>) outs(%18 : tensor<4x1024xf16>) -> tensor<4x1024xf16>
      %subview_10 = memref.subview %reinterpret_cast_1[%7, 0, %9] [1, 4, 1024] [1, 1, 1] : memref<?x4x7168xf16, strided<[?, ?, ?]>> to memref<4x1024xf16, strided<[?, ?], offset: ?>>
      bufferization.materialize_in_destination %19 in writable %subview_10 : (tensor<4x1024xf16>, memref<4x1024xf16, strided<[?, ?], offset: ?>>) -> ()
    }
    return
  }
}