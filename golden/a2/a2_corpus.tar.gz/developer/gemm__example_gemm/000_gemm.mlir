module attributes {hivm.module_core_type = #hivm.module_core_type<AIC>, memref.memref_as_ptr} {
  func.func @gemm(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, mix_mode = "aic"} {
    %c32 = arith.constant 32 : index
    %c128 = arith.constant 128 : index
    %c1024 = arith.constant 1024 : index
    %c1 = arith.constant 1 : index
    %c128_i32 = arith.constant 128 : i32
    %c8_i32 = arith.constant 8 : i32
    %c32_i32 = arith.constant 32 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xf16> to memref<1024x1024xf16, strided<[1024, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xf16> to memref<1024x1024xf16, strided<[1024, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xf16> to memref<1024x1024xf16, strided<[1024, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<128x128xf32>
    %3 = scf.for %arg12 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg13 = %2) -> (tensor<128x128xf32>)  : i32 {
      %12 = arith.divsi %1, %c8_i32 : i32
      %13 = arith.muli %12, %c128_i32 : i32
      %14 = arith.index_cast %13 : i32 to index
      %15 = arith.muli %arg12, %c32_i32 : i32
      %16 = arith.index_cast %15 : i32 to index
      %subview_2 = memref.subview %reinterpret_cast[%14, %16] [128, 32] [1, 1] : memref<1024x1024xf16, strided<[1024, 1]>> to memref<128x32xf16, strided<[1024, 1], offset: ?>>
      %alloc = memref.alloc() : memref<128x32xf16>
      memref.copy %subview_2, %alloc : memref<128x32xf16, strided<[1024, 1], offset: ?>> to memref<128x32xf16>
      %17 = bufferization.to_tensor %alloc restrict : memref<128x32xf16>
      %18 = arith.remsi %1, %c8_i32 : i32
      %19 = arith.muli %18, %c128_i32 : i32
      %20 = arith.index_cast %19 : i32 to index
      %subview_3 = memref.subview %reinterpret_cast_1[%16, %20] [32, 128] [1, 1] : memref<1024x1024xf16, strided<[1024, 1]>> to memref<32x128xf16, strided<[1024, 1], offset: ?>>
      %alloc_4 = memref.alloc() : memref<32x128xf16>
      memref.copy %subview_3, %alloc_4 : memref<32x128xf16, strided<[1024, 1], offset: ?>> to memref<32x128xf16>
      %21 = bufferization.to_tensor %alloc_4 restrict : memref<32x128xf16>
      %22 = arith.cmpi eq, %arg12, %c0_i32 : i32
      %23 = hivm.hir.mmadL1 ins(%17, %21, %22, %c128, %c32, %c128 : tensor<128x32xf16>, tensor<32x128xf16>, i1, index, index, index) outs(%arg13 : tensor<128x128xf32>) -> tensor<128x128xf32>
      scf.yield %23 : tensor<128x128xf32>
    }
    %4 = arith.divsi %1, %c8_i32 : i32
    %5 = arith.muli %4, %c128_i32 : i32
    %6 = arith.index_cast %5 : i32 to index
    %7 = arith.remsi %1, %c8_i32 : i32
    %8 = arith.muli %7, %c128_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %10 = tensor.empty() : tensor<128x128xf16>
    %11 = hivm.hir.vcast ins(%3 : tensor<128x128xf32>) outs(%10 : tensor<128x128xf16>) -> tensor<128x128xf16>
    %subview = memref.subview %reinterpret_cast_0[%6, %9] [128, 128] [1, 1] : memref<1024x1024xf16, strided<[1024, 1]>> to memref<128x128xf16, strided<[1024, 1], offset: ?>>
    bufferization.materialize_in_destination %11 in writable %subview : (tensor<128x128xf16>, memref<128x128xf16, strided<[1024, 1], offset: ?>>) -> ()
    return
  }
}