module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @ternarySimple(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %cst = arith.constant 3.140000e+00 : f32
    %cst_0 = arith.constant -2.780000e+00 : f32
    %cst_1 = arith.constant 1.000000e+00 : f32
    %c4096_i32 = arith.constant 4096 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %0 = tensor.empty() : tensor<4096xf32>
    %1 = tensor.empty() : tensor<4096xf32>
    %2 = tensor.empty() : tensor<4096xf32>
    %3 = tensor.empty() : tensor<4096xf32>
    %4 = tensor.empty() : tensor<4096xi1>
    %5 = tensor.empty() : tensor<4096xf32>
    %6 = tensor.empty() : tensor<4096xf32>
    %7 = tensor.empty() : tensor<4096xf32>
    %8 = arith.minsi %arg6, %c4096_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %subview = memref.subview %reinterpret_cast[0] [%9] [1] : memref<4096xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %alloc = memref.alloc() : memref<4096xf32>
    %subview_4 = memref.subview %alloc[0] [%9] [1] : memref<4096xf32> to memref<?xf32, strided<[1]>>
    memref.copy %subview, %subview_4 : memref<?xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %10 = bufferization.to_tensor %subview_4 restrict : memref<?xf32, strided<[1]>>
    %inserted_slice = tensor.insert_slice %10 into %0[0] [%9] [1] : tensor<?xf32> into tensor<4096xf32>
    %subview_5 = memref.subview %reinterpret_cast_3[0] [%9] [1] : memref<4096xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %alloc_6 = memref.alloc() : memref<4096xf32>
    %subview_7 = memref.subview %alloc_6[0] [%9] [1] : memref<4096xf32> to memref<?xf32, strided<[1]>>
    memref.copy %subview_5, %subview_7 : memref<?xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %11 = bufferization.to_tensor %subview_7 restrict : memref<?xf32, strided<[1]>>
    %inserted_slice_8 = tensor.insert_slice %11 into %1[0] [%9] [1] : tensor<?xf32> into tensor<4096xf32>
    %subview_9 = memref.subview %reinterpret_cast_2[0] [%9] [1] : memref<4096xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %alloc_10 = memref.alloc() : memref<4096xf32>
    %subview_11 = memref.subview %alloc_10[0] [%9] [1] : memref<4096xf32> to memref<?xf32, strided<[1]>>
    memref.copy %subview_9, %subview_11 : memref<?xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    %12 = bufferization.to_tensor %subview_11 restrict : memref<?xf32, strided<[1]>>
    %inserted_slice_12 = tensor.insert_slice %12 into %2[0] [%9] [1] : tensor<?xf32> into tensor<4096xf32>
    %13 = hivm.hir.vadd ins(%inserted_slice, %inserted_slice_8 : tensor<4096xf32>, tensor<4096xf32>) outs(%3 : tensor<4096xf32>) -> tensor<4096xf32>
    %14 = hivm.hir.vcmp ins(%13, %cst_1 : tensor<4096xf32>, f32) outs(%4 : tensor<4096xi1>) compare_mode = <gt> -> tensor<4096xi1>
    %15 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%5 : tensor<4096xf32>) -> tensor<4096xf32>
    %16 = hivm.hir.vmul ins(%inserted_slice, %cst : tensor<4096xf32>, f32) outs(%6 : tensor<4096xf32>) -> tensor<4096xf32>
    %17 = hivm.hir.vadd ins(%inserted_slice_8, %16 : tensor<4096xf32>, tensor<4096xf32>) outs(%7 : tensor<4096xf32>) -> tensor<4096xf32>
    %18 = hivm.hir.vsel ins(%14, %15, %17 : tensor<4096xi1>, tensor<4096xf32>, tensor<4096xf32>) outs(%inserted_slice_12 : tensor<4096xf32>) -> tensor<4096xf32>
    %extracted_slice = tensor.extract_slice %18[0] [%9] [1] : tensor<4096xf32> to tensor<?xf32>
    %subview_13 = memref.subview %reinterpret_cast_2[0] [%9] [1] : memref<4096xf32, strided<[1]>> to memref<?xf32, strided<[1]>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_13 : (tensor<?xf32>, memref<?xf32, strided<[1]>>) -> ()
    return
  }
}