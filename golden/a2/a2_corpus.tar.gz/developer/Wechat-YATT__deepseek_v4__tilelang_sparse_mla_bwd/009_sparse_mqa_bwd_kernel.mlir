module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @sparse_mqa_bwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xf32>, %arg7: memref<?xi32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xbf16>, %arg11: memref<?xf32>, %arg12: memref<?xf32>, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c16 = arith.constant 16 : index
    %cst = arith.constant 0.000000e+00 : bf16
    %c81920 = arith.constant 81920 : index
    %c8192 = arith.constant 8192 : index
    %c64 = arith.constant 64 : index
    %c1024 = arith.constant 1024 : index
    %c8 = arith.constant 8 : index
    %c524288 = arith.constant 524288 : index
    %c4096 = arith.constant 4096 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant -1.000000e+00 : f32
    %cst_1 = arith.constant 1.44269502 : f32
    %c2_i32 = arith.constant 2 : i32
    %cst_2 = arith.constant 0.0441941731 : f32
    %true = arith.constant true
    %cst_3 = arith.constant 0.693147182 : f32
    %cst_4 = arith.constant 0.063758716 : f32
    %false = arith.constant false
    %cst_5 = arith.constant 0xFF800000 : f32
    %cst_6 = arith.constant 0.000000e+00 : f32
    %c16_i32 = arith.constant 16 : i32
    %c4_i32 = arith.constant 4 : i32
    %c-1_i32 = arith.constant -1 : i32
    %c0_i32 = arith.constant 0 : i32
    %c128_i32 = arith.constant 128 : i32
    %c8_i32 = arith.constant 8 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 128, 8, 512], strides: [%c524288, %c4096, %c512, %c1] : memref<?xbf16> to memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [2, 128, 8, 512], strides: [%c524288, %c4096, %c512, %c1] : memref<?xbf16> to memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [2, 128, 8], strides: [%c1024, %c8, %c1] : memref<?xf32> to memref<2x128x8xf32, strided<[1024, 8, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [2, 128, 64], strides: [%c8192, %c64, %c1] : memref<?xi32> to memref<2x128x64xi32, strided<[8192, 64, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [2, 160, 512], strides: [%c81920, %c512, %c1] : memref<?xf32> to memref<2x160x512xf32, strided<[81920, 512, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [2, 128, 8], strides: [%c1024, %c8, %c1] : memref<?xf32> to memref<2x128x8xf32, strided<[1024, 8, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [2, 160, 512], strides: [%c81920, %c512, %c1] : memref<?xbf16> to memref<2x160x512xbf16, strided<[81920, 512, 1]>>
    %reinterpret_cast_13 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [8], strides: [%c1] : memref<?xf32> to memref<8xf32, strided<[1]>>
    %reinterpret_cast_14 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [8], strides: [%c1] : memref<?xf32> to memref<8xf32, strided<[1]>>
    %reinterpret_cast_15 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [2, 128, 8, 512], strides: [%c524288, %c4096, %c512, %c1] : memref<?xbf16> to memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16xi32>
    %3 = tensor.empty() : tensor<8x512xf32>
    %4 = tensor.empty() : tensor<8xf32>
    %5 = tensor.empty() : tensor<8x16xf32>
    %6 = arith.divsi %1, %c128_i32 : i32
    %7 = arith.index_cast %6 : i32 to index
    %8 = arith.remsi %1, %c128_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %subview = memref.subview %reinterpret_cast[%7, %9, 0, 0] [1, 1, 8, 512] [1, 1, 1, 1] : memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>> to memref<8x512xbf16, strided<[512, 1], offset: ?>>
    %alloc = memref.alloc() : memref<8x512xbf16>
    memref.copy %subview, %alloc : memref<8x512xbf16, strided<[512, 1], offset: ?>> to memref<8x512xbf16>
    %10 = bufferization.to_tensor %alloc restrict : memref<8x512xbf16>
    %subview_16 = memref.subview %reinterpret_cast_7[%7, %9, 0, 0] [1, 1, 8, 512] [1, 1, 1, 1] : memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>> to memref<8x512xbf16, strided<[512, 1], offset: ?>>
    %alloc_17 = memref.alloc() : memref<8x512xbf16>
    memref.copy %subview_16, %alloc_17 : memref<8x512xbf16, strided<[512, 1], offset: ?>> to memref<8x512xbf16>
    %11 = bufferization.to_tensor %alloc_17 restrict : memref<8x512xbf16>
    %subview_18 = memref.subview %reinterpret_cast_8[%7, %9, 0] [1, 1, 8] [1, 1, 1] : memref<2x128x8xf32, strided<[1024, 8, 1]>> to memref<8xf32, strided<[1], offset: ?>>
    %alloc_19 = memref.alloc() : memref<8xf32>
    memref.copy %subview_18, %alloc_19 : memref<8xf32, strided<[1], offset: ?>> to memref<8xf32>
    %12 = bufferization.to_tensor %alloc_19 restrict : memref<8xf32>
    %subview_20 = memref.subview %reinterpret_cast_11[%7, %9, 0] [1, 1, 8] [1, 1, 1] : memref<2x128x8xf32, strided<[1024, 8, 1]>> to memref<8xf32, strided<[1], offset: ?>>
    %alloc_21 = memref.alloc() : memref<8xf32>
    memref.copy %subview_20, %alloc_21 : memref<8xf32, strided<[1], offset: ?>> to memref<8xf32>
    %13 = bufferization.to_tensor %alloc_21 restrict : memref<8xf32>
    %14 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%3 : tensor<8x512xf32>) -> tensor<8x512xf32>
    %15 = hivm.hir.vbrc ins(%c-1_i32 : i32) outs(%2 : tensor<16xi32>) -> tensor<16xi32>
    %16:2 = scf.for %arg19 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg20 = %5, %arg21 = %14) -> (tensor<8x16xf32>, tensor<8x512xf32>)  : i32 {
      %26 = tensor.empty() : tensor<16x512xbf16>
      %27 = tensor.empty() : tensor<16xi1>
      %28 = tensor.empty() : tensor<8x16xf32>
      %29 = tensor.empty() : tensor<8x16xf32>
      %30 = tensor.empty() : tensor<16x512xf32>
      %31 = tensor.empty() : tensor<16x512xf32>
      %32 = tensor.empty() : tensor<8x16xi1>
      %33 = tensor.empty() : tensor<8x16xf32>
      %34 = tensor.empty() : tensor<8x16xf32>
      %35 = tensor.empty() : tensor<8x16xf32>
      %36 = tensor.empty() : tensor<8x16xf32>
      %37 = tensor.empty() : tensor<8x16xf32>
      %38 = tensor.empty() : tensor<8x16xf32>
      %39 = tensor.empty() : tensor<8x16xf32>
      %40 = arith.divsi %1, %c128_i32 : i32
      %41 = arith.index_cast %40 : i32 to index
      %42 = arith.remsi %1, %c128_i32 : i32
      %43 = arith.index_cast %42 : i32 to index
      %44 = arith.muli %arg19, %c16_i32 : i32
      %45 = arith.index_cast %44 : i32 to index
      %subview_24 = memref.subview %reinterpret_cast_9[%41, %43, %45] [1, 1, 16] [1, 1, 1] : memref<2x128x64xi32, strided<[8192, 64, 1]>> to memref<16xi32, strided<[1], offset: ?>>
      %alloc_25 = memref.alloc() : memref<16xi32>
      memref.copy %subview_24, %alloc_25 : memref<16xi32, strided<[1], offset: ?>> to memref<16xi32>
      %46 = bufferization.to_tensor %alloc_25 restrict : memref<16xi32>
      %47 = hivm.hir.vcmp ins(%46, %15 : tensor<16xi32>, tensor<16xi32>) outs(%27 : tensor<16xi1>) compare_mode = <ne> -> tensor<16xi1>
      %48 = hivm.hir.vbrc ins(%cst : bf16) outs(%26 : tensor<16x512xbf16>) -> tensor<16x512xbf16>
      %expanded = tensor.expand_shape %47 [[0, 1]] output_shape [1, 16] : tensor<16xi1> into tensor<1x16xi1>
      %49 = hivm.hir.vbrc ins(%expanded : tensor<1x16xi1>) outs(%32 : tensor<8x16xi1>) broadcast_dims = [0] -> tensor<8x16xi1>
      %50 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%33 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %51 = hivm.hir.vbrc ins(%cst_5 : f32) outs(%34 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %52 = hivm.hir.vsel ins(%49, %50, %51 : tensor<8x16xi1>, tensor<8x16xf32>, tensor<8x16xf32>) outs(%arg20 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %53 = scf.for %arg22 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg23 = %48) -> (tensor<16x512xbf16>)  : i32 {
        %73 = arith.index_cast %arg22 : i32 to index
        %extracted = tensor.extract %46[%73] : tensor<16xi32>
        %74 = arith.cmpi ne, %extracted, %c-1_i32 : i32
        %75 = scf.if %74 -> (tensor<16x512xbf16>) {
          %76 = arith.divsi %1, %c128_i32 : i32
          %77 = arith.index_cast %76 : i32 to index
          %78 = arith.index_cast %extracted : i32 to index
          %79 = arith.index_cast %arg22 : i32 to index
          %subview_28 = memref.subview %reinterpret_cast_12[%77, %78, 0] [1, 1, 512] [1, 1, 1] : memref<2x160x512xbf16, strided<[81920, 512, 1]>> to memref<512xbf16, strided<[1], offset: ?>>
          %alloc_29 = memref.alloc() : memref<512xbf16>
          memref.copy %subview_28, %alloc_29 : memref<512xbf16, strided<[1], offset: ?>> to memref<512xbf16>
          %80 = bufferization.to_tensor %alloc_29 restrict : memref<512xbf16>
          %inserted_slice = tensor.insert_slice %80 into %arg23[%79, 0] [1, 512] [1, 1] : tensor<512xbf16> into tensor<16x512xbf16>
          scf.yield %inserted_slice : tensor<16x512xbf16>
        } else {
          scf.yield %arg23 : tensor<16x512xbf16>
        }
        scf.yield %75 : tensor<16x512xbf16>
      }
      %54 = hivm.hir.mmadL1 {b_transpose} ins(%10, %53, %false, %c8, %c16, %c512 : tensor<8x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%52 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %expanded_26 = tensor.expand_shape %13 [[0, 1]] output_shape [8, 1] : tensor<8xf32> into tensor<8x1xf32>
      %55 = hivm.hir.vbrc ins(%expanded_26 : tensor<8x1xf32>) outs(%36 : tensor<8x16xf32>) broadcast_dims = [1] -> tensor<8x16xf32>
      %56 = hivm.hir.vmul ins(%54, %cst_4 : tensor<8x16xf32>, f32) outs(%35 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %57 = hivm.hir.vsub ins(%56, %55 : tensor<8x16xf32>, tensor<8x16xf32>) outs(%54 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %58 = hivm.hir.vmul ins(%57, %cst_3 : tensor<8x16xf32>, f32) outs(%28 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %59 = hivm.hir.vexp ins(%58 : tensor<8x16xf32>) outs(%57 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %60 = tensor.empty() : tensor<8x16xbf16>
      %61 = hivm.hir.vcast ins(%59 : tensor<8x16xf32>) outs(%60 : tensor<8x16xbf16>) -> tensor<8x16xbf16>
      %62 = hivm.hir.mmadL1 {b_transpose} ins(%11, %53, %true, %c8, %c16, %c512 : tensor<8x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%29 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %expanded_27 = tensor.expand_shape %12 [[0, 1]] output_shape [8, 1] : tensor<8xf32> into tensor<8x1xf32>
      %63 = hivm.hir.vbrc ins(%expanded_27 : tensor<8x1xf32>) outs(%37 : tensor<8x16xf32>) broadcast_dims = [1] -> tensor<8x16xf32>
      %64 = hivm.hir.vsub ins(%62, %63 : tensor<8x16xf32>, tensor<8x16xf32>) outs(%38 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %65 = hivm.hir.vmul ins(%59, %64 : tensor<8x16xf32>, tensor<8x16xf32>) outs(%39 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %66 = hivm.hir.vmul ins(%65, %cst_2 : tensor<8x16xf32>, f32) outs(%62 : tensor<8x16xf32>) -> tensor<8x16xf32>
      %67 = tensor.empty() : tensor<8x16xbf16>
      %68 = hivm.hir.vcast ins(%66 : tensor<8x16xf32>) outs(%67 : tensor<8x16xbf16>) -> tensor<8x16xbf16>
      %69 = hivm.hir.mmadL1 ins(%68, %53, %false, %c8, %c16, %c512 : tensor<8x16xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%arg21 : tensor<8x512xf32>) -> tensor<8x512xf32>
      %70 = hivm.hir.mmadL1 {a_transpose} ins(%68, %10, %true, %c8, %c8, %c512 : tensor<8x16xbf16>, tensor<8x512xbf16>, i1, index, index, index) outs(%30 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %71 = hivm.hir.mmadL1 {a_transpose} ins(%61, %11, %true, %c8, %c8, %c512 : tensor<8x16xbf16>, tensor<8x512xbf16>, i1, index, index, index) outs(%31 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %72 = hivm.hir.vadd ins(%70, %71 : tensor<16x512xf32>, tensor<16x512xf32>) outs(%70 : tensor<16x512xf32>) -> tensor<16x512xf32>
      scf.for %arg22 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
        scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
          %73 = arith.muli %arg22, %c8_i32 : i32
          %74 = arith.addi %73, %arg23 : i32
          %75 = arith.index_cast %74 : i32 to index
          %extracted = tensor.extract %46[%75] : tensor<16xi32>
          %76 = arith.cmpi ne, %extracted, %c-1_i32 : i32
          scf.if %76 {
            %77 = arith.muli %arg22, %c8_i32 : i32
            %78 = arith.addi %77, %arg23 : i32
            %79 = arith.index_cast %78 : i32 to index
            %extracted_slice = tensor.extract_slice %72[%79, 0] [1, 512] [1, 1] : tensor<16x512xf32> to tensor<1x512xf32>
            %80 = arith.divsi %1, %c128_i32 : i32
            %81 = arith.index_cast %80 : i32 to index
            %82 = arith.index_cast %extracted : i32 to index
            %subview_28 = memref.subview %reinterpret_cast_10[%81, %82, 0] [1, 1, 512] [1, 1, 1] : memref<2x160x512xf32, strided<[81920, 512, 1]>> to memref<1x1x512xf32, strided<[81920, 512, 1], offset: ?>>
            %expanded_29 = tensor.expand_shape %extracted_slice [[0, 1], [2]] output_shape [1, 1, 512] : tensor<1x512xf32> into tensor<1x1x512xf32>
            hivm.hir.store ins(%expanded_29 : tensor<1x1x512xf32>) outs(%subview_28 : memref<1x1x512xf32, strided<[81920, 512, 1], offset: ?>>) atomic = <add>
          }
        }
      }
      scf.yield %59, %69 : tensor<8x16xf32>, tensor<8x512xf32>
    }
    %17 = tensor.empty() : tensor<8x512xbf16>
    %18 = hivm.hir.vcast ins(%16#1 : tensor<8x512xf32>) outs(%17 : tensor<8x512xbf16>) -> tensor<8x512xbf16>
    %subview_22 = memref.subview %reinterpret_cast_15[%7, %9, 0, 0] [1, 1, 8, 512] [1, 1, 1, 1] : memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>> to memref<8x512xbf16, strided<[512, 1], offset: ?>>
    bufferization.materialize_in_destination %18 in writable %subview_22 : (tensor<8x512xbf16>, memref<8x512xbf16, strided<[512, 1], offset: ?>>) -> ()
    %alloc_23 = memref.alloc() : memref<8xf32>
    memref.copy %reinterpret_cast_13, %alloc_23 : memref<8xf32, strided<[1]>> to memref<8xf32>
    %19 = bufferization.to_tensor %alloc_23 restrict : memref<8xf32>
    %20 = hivm.hir.vmul ins(%19, %cst_1 : tensor<8xf32>, f32) outs(%19 : tensor<8xf32>) -> tensor<8xf32>
    %21 = hivm.hir.vsub ins(%20, %13 : tensor<8xf32>, tensor<8xf32>) outs(%20 : tensor<8xf32>) -> tensor<8xf32>
    %22 = hivm.hir.vmul ins(%21, %cst_3 : tensor<8xf32>, f32) outs(%4 : tensor<8xf32>) -> tensor<8xf32>
    %23 = hivm.hir.vexp ins(%22 : tensor<8xf32>) outs(%21 : tensor<8xf32>) -> tensor<8xf32>
    %24 = hivm.hir.vmul ins(%23, %12 : tensor<8xf32>, tensor<8xf32>) outs(%23 : tensor<8xf32>) -> tensor<8xf32>
    %25 = hivm.hir.vmul ins(%24, %cst_0 : tensor<8xf32>, f32) outs(%24 : tensor<8xf32>) -> tensor<8xf32>
    hivm.hir.store ins(%25 : tensor<8xf32>) outs(%reinterpret_cast_14 : memref<8xf32, strided<[1]>>) atomic = <add>
    return
  }
}