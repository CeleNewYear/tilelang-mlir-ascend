module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @postprocess_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xbf16>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c327680 = arith.constant 327680 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %c16_i32 = arith.constant 16 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 640, 512], strides: [%c327680, %c512, %c1] : memref<?xf32> to memref<1x640x512xf32, strided<[327680, 512, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 640, 512], strides: [%c327680, %c512, %c1] : memref<?xbf16> to memref<1x640x512xbf16, strided<[327680, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = arith.muli %1, %c16_i32 : i32
    %3 = arith.index_cast %2 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %3, 0] [1, 16, 512] [1, 1, 1] : memref<1x640x512xf32, strided<[327680, 512, 1]>> to memref<16x512xf32, strided<[512, 1], offset: ?>>
    %alloc = memref.alloc() : memref<16x512xf32>
    memref.copy %subview, %alloc : memref<16x512xf32, strided<[512, 1], offset: ?>> to memref<16x512xf32>
    %4 = bufferization.to_tensor %alloc restrict : memref<16x512xf32>
    %5 = tensor.empty() : tensor<16x512xbf16>
    %6 = hivm.hir.vcast ins(%4 : tensor<16x512xf32>) outs(%5 : tensor<16x512xbf16>) -> tensor<16x512xbf16>
    %subview_1 = memref.subview %reinterpret_cast_0[0, %3, 0] [1, 16, 512] [1, 1, 1] : memref<1x640x512xbf16, strided<[327680, 512, 1]>> to memref<16x512xbf16, strided<[512, 1], offset: ?>>
    bufferization.materialize_in_destination %6 in writable %subview_1 : (tensor<16x512xbf16>, memref<16x512xbf16, strided<[512, 1], offset: ?>>) -> ()
    return
  }
}