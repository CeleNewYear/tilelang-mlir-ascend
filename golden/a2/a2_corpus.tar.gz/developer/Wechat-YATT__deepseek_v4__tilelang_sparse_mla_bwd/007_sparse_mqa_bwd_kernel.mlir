module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @sparse_mqa_bwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xf32>, %arg7: memref<?xi32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xbf16>, %arg11: memref<?xf32>, %arg12: memref<?xf32>, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c16 = arith.constant 16 : index
    %c32 = arith.constant 32 : index
    %cst = arith.constant 0.000000e+00 : bf16
    %c163840 = arith.constant 163840 : index
    %c128 = arith.constant 128 : index
    %c16384 = arith.constant 16384 : index
    %c64 = arith.constant 64 : index
    %c8388608 = arith.constant 8388608 : index
    %c32768 = arith.constant 32768 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant -1.000000e+00 : f32
    %cst_1 = arith.constant 1.44269502 : f32
    %c2_i32 = arith.constant 2 : i32
    %cst_2 = arith.constant 0.0441941731 : f32
    %true = arith.constant true
    %cst_3 = arith.constant 0.693147182 : f32
    %cst_4 = arith.constant 0.063758716 : f32
    %false = arith.constant false
    %cst_5 = arith.constant 0xFF800000 : f32
    %cst_6 = arith.constant 0.000000e+00 : f32
    %c16_i32 = arith.constant 16 : i32
    %c8_i32 = arith.constant 8 : i32
    %c-1_i32 = arith.constant -1 : i32
    %c0_i32 = arith.constant 0 : i32
    %c32_i32 = arith.constant 32 : i32
    %c256_i32 = arith.constant 256 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 256, 64, 512], strides: [%c8388608, %c32768, %c512, %c1] : memref<?xbf16> to memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 256, 64, 512], strides: [%c8388608, %c32768, %c512, %c1] : memref<?xbf16> to memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [1, 256, 64], strides: [%c16384, %c64, %c1] : memref<?xf32> to memref<1x256x64xf32, strided<[16384, 64, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 256, 128], strides: [%c32768, %c128, %c1] : memref<?xi32> to memref<1x256x128xi32, strided<[32768, 128, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [1, 320, 512], strides: [%c163840, %c512, %c1] : memref<?xf32> to memref<1x320x512xf32, strided<[163840, 512, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [1, 256, 64], strides: [%c16384, %c64, %c1] : memref<?xf32> to memref<1x256x64xf32, strided<[16384, 64, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 320, 512], strides: [%c163840, %c512, %c1] : memref<?xbf16> to memref<1x320x512xbf16, strided<[163840, 512, 1]>>
    %reinterpret_cast_13 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [64], strides: [%c1] : memref<?xf32> to memref<64xf32, strided<[1]>>
    %reinterpret_cast_14 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [64], strides: [%c1] : memref<?xf32> to memref<64xf32, strided<[1]>>
    %reinterpret_cast_15 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [1, 256, 64, 512], strides: [%c8388608, %c32768, %c512, %c1] : memref<?xbf16> to memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16xi32>
    %3 = tensor.empty() : tensor<32x512xf32>
    %4 = tensor.empty() : tensor<32xf32>
    %5 = tensor.empty() : tensor<32x16xf32>
    %6 = arith.remsi %1, %c256_i32 : i32
    %7 = arith.index_cast %6 : i32 to index
    %8 = arith.divsi %1, %c256_i32 : i32
    %9 = arith.muli %8, %c32_i32 : i32
    %10 = arith.index_cast %9 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %7, %10, 0] [1, 1, 32, 512] [1, 1, 1, 1] : memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>> to memref<32x512xbf16, strided<[512, 1], offset: ?>>
    %alloc = memref.alloc() : memref<32x512xbf16>
    memref.copy %subview, %alloc : memref<32x512xbf16, strided<[512, 1], offset: ?>> to memref<32x512xbf16>
    %11 = bufferization.to_tensor %alloc restrict : memref<32x512xbf16>
    %subview_16 = memref.subview %reinterpret_cast_7[0, %7, %10, 0] [1, 1, 32, 512] [1, 1, 1, 1] : memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>> to memref<32x512xbf16, strided<[512, 1], offset: ?>>
    %alloc_17 = memref.alloc() : memref<32x512xbf16>
    memref.copy %subview_16, %alloc_17 : memref<32x512xbf16, strided<[512, 1], offset: ?>> to memref<32x512xbf16>
    %12 = bufferization.to_tensor %alloc_17 restrict : memref<32x512xbf16>
    %subview_18 = memref.subview %reinterpret_cast_8[0, %7, %10] [1, 1, 32] [1, 1, 1] : memref<1x256x64xf32, strided<[16384, 64, 1]>> to memref<32xf32, strided<[1], offset: ?>>
    %alloc_19 = memref.alloc() : memref<32xf32>
    memref.copy %subview_18, %alloc_19 : memref<32xf32, strided<[1], offset: ?>> to memref<32xf32>
    %13 = bufferization.to_tensor %alloc_19 restrict : memref<32xf32>
    %subview_20 = memref.subview %reinterpret_cast_11[0, %7, %10] [1, 1, 32] [1, 1, 1] : memref<1x256x64xf32, strided<[16384, 64, 1]>> to memref<32xf32, strided<[1], offset: ?>>
    %alloc_21 = memref.alloc() : memref<32xf32>
    memref.copy %subview_20, %alloc_21 : memref<32xf32, strided<[1], offset: ?>> to memref<32xf32>
    %14 = bufferization.to_tensor %alloc_21 restrict : memref<32xf32>
    %15 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%3 : tensor<32x512xf32>) -> tensor<32x512xf32>
    %16 = hivm.hir.vbrc ins(%c-1_i32 : i32) outs(%2 : tensor<16xi32>) -> tensor<16xi32>
    %17:2 = scf.for %arg19 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg20 = %5, %arg21 = %15) -> (tensor<32x16xf32>, tensor<32x512xf32>)  : i32 {
      %27 = tensor.empty() : tensor<16x512xbf16>
      %28 = tensor.empty() : tensor<16xi1>
      %29 = tensor.empty() : tensor<32x16xf32>
      %30 = tensor.empty() : tensor<32x16xf32>
      %31 = tensor.empty() : tensor<16x512xf32>
      %32 = tensor.empty() : tensor<16x512xf32>
      %33 = tensor.empty() : tensor<32x16xi1>
      %34 = tensor.empty() : tensor<32x16xf32>
      %35 = tensor.empty() : tensor<32x16xf32>
      %36 = tensor.empty() : tensor<32x16xf32>
      %37 = tensor.empty() : tensor<32x16xf32>
      %38 = tensor.empty() : tensor<32x16xf32>
      %39 = tensor.empty() : tensor<32x16xf32>
      %40 = tensor.empty() : tensor<32x16xf32>
      %41 = arith.remsi %1, %c256_i32 : i32
      %42 = arith.index_cast %41 : i32 to index
      %43 = arith.muli %arg19, %c16_i32 : i32
      %44 = arith.index_cast %43 : i32 to index
      %subview_26 = memref.subview %reinterpret_cast_9[0, %42, %44] [1, 1, 16] [1, 1, 1] : memref<1x256x128xi32, strided<[32768, 128, 1]>> to memref<16xi32, strided<[1], offset: ?>>
      %alloc_27 = memref.alloc() : memref<16xi32>
      memref.copy %subview_26, %alloc_27 : memref<16xi32, strided<[1], offset: ?>> to memref<16xi32>
      %45 = bufferization.to_tensor %alloc_27 restrict : memref<16xi32>
      %46 = hivm.hir.vcmp ins(%45, %16 : tensor<16xi32>, tensor<16xi32>) outs(%28 : tensor<16xi1>) compare_mode = <ne> -> tensor<16xi1>
      %47 = hivm.hir.vbrc ins(%cst : bf16) outs(%27 : tensor<16x512xbf16>) -> tensor<16x512xbf16>
      %expanded = tensor.expand_shape %46 [[0, 1]] output_shape [1, 16] : tensor<16xi1> into tensor<1x16xi1>
      %48 = hivm.hir.vbrc ins(%expanded : tensor<1x16xi1>) outs(%33 : tensor<32x16xi1>) broadcast_dims = [0] -> tensor<32x16xi1>
      %49 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%34 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %50 = hivm.hir.vbrc ins(%cst_5 : f32) outs(%35 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %51 = hivm.hir.vsel ins(%48, %49, %50 : tensor<32x16xi1>, tensor<32x16xf32>, tensor<32x16xf32>) outs(%arg20 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %52 = scf.for %arg22 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg23 = %47) -> (tensor<16x512xbf16>)  : i32 {
        %72 = arith.index_cast %arg22 : i32 to index
        %extracted = tensor.extract %45[%72] : tensor<16xi32>
        %73 = arith.cmpi ne, %extracted, %c-1_i32 : i32
        %74 = scf.if %73 -> (tensor<16x512xbf16>) {
          %75 = arith.index_cast %extracted : i32 to index
          %76 = arith.index_cast %arg22 : i32 to index
          %subview_30 = memref.subview %reinterpret_cast_12[0, %75, 0] [1, 1, 512] [1, 1, 1] : memref<1x320x512xbf16, strided<[163840, 512, 1]>> to memref<512xbf16, strided<[1], offset: ?>>
          %alloc_31 = memref.alloc() : memref<512xbf16>
          memref.copy %subview_30, %alloc_31 : memref<512xbf16, strided<[1], offset: ?>> to memref<512xbf16>
          %77 = bufferization.to_tensor %alloc_31 restrict : memref<512xbf16>
          %inserted_slice = tensor.insert_slice %77 into %arg23[%76, 0] [1, 512] [1, 1] : tensor<512xbf16> into tensor<16x512xbf16>
          scf.yield %inserted_slice : tensor<16x512xbf16>
        } else {
          scf.yield %arg23 : tensor<16x512xbf16>
        }
        scf.yield %74 : tensor<16x512xbf16>
      }
      %53 = hivm.hir.mmadL1 {b_transpose} ins(%11, %52, %false, %c32, %c16, %c512 : tensor<32x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%51 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %expanded_28 = tensor.expand_shape %14 [[0, 1]] output_shape [32, 1] : tensor<32xf32> into tensor<32x1xf32>
      %54 = hivm.hir.vbrc ins(%expanded_28 : tensor<32x1xf32>) outs(%37 : tensor<32x16xf32>) broadcast_dims = [1] -> tensor<32x16xf32>
      %55 = hivm.hir.vmul ins(%53, %cst_4 : tensor<32x16xf32>, f32) outs(%36 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %56 = hivm.hir.vsub ins(%55, %54 : tensor<32x16xf32>, tensor<32x16xf32>) outs(%53 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %57 = hivm.hir.vmul ins(%56, %cst_3 : tensor<32x16xf32>, f32) outs(%29 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %58 = hivm.hir.vexp ins(%57 : tensor<32x16xf32>) outs(%56 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %59 = tensor.empty() : tensor<32x16xbf16>
      %60 = hivm.hir.vcast ins(%58 : tensor<32x16xf32>) outs(%59 : tensor<32x16xbf16>) -> tensor<32x16xbf16>
      %61 = hivm.hir.mmadL1 {b_transpose} ins(%12, %52, %true, %c32, %c16, %c512 : tensor<32x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%30 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %expanded_29 = tensor.expand_shape %13 [[0, 1]] output_shape [32, 1] : tensor<32xf32> into tensor<32x1xf32>
      %62 = hivm.hir.vbrc ins(%expanded_29 : tensor<32x1xf32>) outs(%38 : tensor<32x16xf32>) broadcast_dims = [1] -> tensor<32x16xf32>
      %63 = hivm.hir.vsub ins(%61, %62 : tensor<32x16xf32>, tensor<32x16xf32>) outs(%39 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %64 = hivm.hir.vmul ins(%58, %63 : tensor<32x16xf32>, tensor<32x16xf32>) outs(%40 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %65 = hivm.hir.vmul ins(%64, %cst_2 : tensor<32x16xf32>, f32) outs(%61 : tensor<32x16xf32>) -> tensor<32x16xf32>
      %66 = tensor.empty() : tensor<32x16xbf16>
      %67 = hivm.hir.vcast ins(%65 : tensor<32x16xf32>) outs(%66 : tensor<32x16xbf16>) -> tensor<32x16xbf16>
      %68 = hivm.hir.mmadL1 ins(%67, %52, %false, %c32, %c16, %c512 : tensor<32x16xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%arg21 : tensor<32x512xf32>) -> tensor<32x512xf32>
      %69 = hivm.hir.mmadL1 {a_transpose} ins(%67, %11, %true, %c32, %c32, %c512 : tensor<32x16xbf16>, tensor<32x512xbf16>, i1, index, index, index) outs(%31 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %70 = hivm.hir.mmadL1 {a_transpose} ins(%60, %12, %true, %c32, %c32, %c512 : tensor<32x16xbf16>, tensor<32x512xbf16>, i1, index, index, index) outs(%32 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %71 = hivm.hir.vadd ins(%69, %70 : tensor<16x512xf32>, tensor<16x512xf32>) outs(%69 : tensor<16x512xf32>) -> tensor<16x512xf32>
      scf.for %arg22 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
        scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
          %72 = arith.muli %arg22, %c8_i32 : i32
          %73 = arith.addi %72, %arg23 : i32
          %74 = arith.index_cast %73 : i32 to index
          %extracted = tensor.extract %45[%74] : tensor<16xi32>
          %75 = arith.cmpi ne, %extracted, %c-1_i32 : i32
          scf.if %75 {
            %76 = arith.muli %arg22, %c8_i32 : i32
            %77 = arith.addi %76, %arg23 : i32
            %78 = arith.index_cast %77 : i32 to index
            %extracted_slice = tensor.extract_slice %71[%78, 0] [1, 512] [1, 1] : tensor<16x512xf32> to tensor<1x512xf32>
            %79 = arith.index_cast %extracted : i32 to index
            %subview_30 = memref.subview %reinterpret_cast_10[0, %79, 0] [1, 1, 512] [1, 1, 1] : memref<1x320x512xf32, strided<[163840, 512, 1]>> to memref<1x1x512xf32, strided<[163840, 512, 1], offset: ?>>
            %expanded_31 = tensor.expand_shape %extracted_slice [[0, 1], [2]] output_shape [1, 1, 512] : tensor<1x512xf32> into tensor<1x1x512xf32>
            hivm.hir.store ins(%expanded_31 : tensor<1x1x512xf32>) outs(%subview_30 : memref<1x1x512xf32, strided<[163840, 512, 1], offset: ?>>) atomic = <add>
          }
        }
      }
      scf.yield %58, %68 : tensor<32x16xf32>, tensor<32x512xf32>
    }
    %18 = tensor.empty() : tensor<32x512xbf16>
    %19 = hivm.hir.vcast ins(%17#1 : tensor<32x512xf32>) outs(%18 : tensor<32x512xbf16>) -> tensor<32x512xbf16>
    %subview_22 = memref.subview %reinterpret_cast_15[0, %7, %10, 0] [1, 1, 32, 512] [1, 1, 1, 1] : memref<1x256x64x512xbf16, strided<[8388608, 32768, 512, 1]>> to memref<32x512xbf16, strided<[512, 1], offset: ?>>
    bufferization.materialize_in_destination %19 in writable %subview_22 : (tensor<32x512xbf16>, memref<32x512xbf16, strided<[512, 1], offset: ?>>) -> ()
    %subview_23 = memref.subview %reinterpret_cast_13[%10] [32] [1] : memref<64xf32, strided<[1]>> to memref<32xf32, strided<[1], offset: ?>>
    %alloc_24 = memref.alloc() : memref<32xf32>
    memref.copy %subview_23, %alloc_24 : memref<32xf32, strided<[1], offset: ?>> to memref<32xf32>
    %20 = bufferization.to_tensor %alloc_24 restrict : memref<32xf32>
    %21 = hivm.hir.vmul ins(%20, %cst_1 : tensor<32xf32>, f32) outs(%20 : tensor<32xf32>) -> tensor<32xf32>
    %22 = hivm.hir.vsub ins(%21, %14 : tensor<32xf32>, tensor<32xf32>) outs(%21 : tensor<32xf32>) -> tensor<32xf32>
    %23 = hivm.hir.vmul ins(%22, %cst_3 : tensor<32xf32>, f32) outs(%4 : tensor<32xf32>) -> tensor<32xf32>
    %24 = hivm.hir.vexp ins(%23 : tensor<32xf32>) outs(%22 : tensor<32xf32>) -> tensor<32xf32>
    %25 = hivm.hir.vmul ins(%24, %13 : tensor<32xf32>, tensor<32xf32>) outs(%24 : tensor<32xf32>) -> tensor<32xf32>
    %26 = hivm.hir.vmul ins(%25, %cst_0 : tensor<32xf32>, f32) outs(%25 : tensor<32xf32>) -> tensor<32xf32>
    %subview_25 = memref.subview %reinterpret_cast_14[%10] [32] [1] : memref<64xf32, strided<[1]>> to memref<32xf32, strided<[1], offset: ?>>
    hivm.hir.store ins(%26 : tensor<32xf32>) outs(%subview_25 : memref<32xf32, strided<[1], offset: ?>>) atomic = <add>
    return
  }
}