module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @preprocess_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xf32>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c1024 = arith.constant 1024 : index
    %c8 = arith.constant 8 : index
    %c524288 = arith.constant 524288 : index
    %c4096 = arith.constant 4096 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %c32_i32 = arith.constant 32 : i32
    %c16_i32 = arith.constant 16 : i32
    %c0_i32 = arith.constant 0 : i32
    %c8_i32 = arith.constant 8 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 128, 8, 512], strides: [%c524288, %c4096, %c512, %c1] : memref<?xbf16> to memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [2, 128, 8], strides: [%c1024, %c8, %c1] : memref<?xf32> to memref<2x128x8xf32, strided<[1024, 8, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [2, 128, 8, 512], strides: [%c524288, %c4096, %c512, %c1] : memref<?xbf16> to memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<32x1xf32>
    %3 = tensor.empty() : tensor<32x32xf32>
    %4 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %5 = scf.for %arg12 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg13 = %4) -> (tensor<32x32xf32>)  : i32 {
      %15 = tensor.empty() : tensor<32x32xf32>
      %16 = arith.divsi %1, %c32_i32 : i32
      %17 = arith.index_cast %16 : i32 to index
      %18 = arith.remsi %1, %c32_i32 : i32
      %19 = arith.divsi %18, %c8_i32 : i32
      %20 = arith.muli %19, %c32_i32 : i32
      %21 = arith.index_cast %20 : i32 to index
      %22 = arith.remsi %1, %c8_i32 : i32
      %23 = arith.index_cast %22 : i32 to index
      %24 = arith.muli %arg12, %c32_i32 : i32
      %25 = arith.index_cast %24 : i32 to index
      %subview_2 = memref.subview %reinterpret_cast[%17, %21, %23, %25] [1, 32, 1, 32] [1, 1, 1, 1] : memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>> to memref<32x32xbf16, strided<[4096, 1], offset: ?>>
      %alloc = memref.alloc() : memref<32x32xbf16>
      memref.copy %subview_2, %alloc : memref<32x32xbf16, strided<[4096, 1], offset: ?>> to memref<32x32xbf16>
      %26 = bufferization.to_tensor %alloc restrict : memref<32x32xbf16>
      %27 = tensor.empty() : tensor<32x32xf32>
      %28 = hivm.hir.vcast ins(%26 : tensor<32x32xbf16>) outs(%27 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %subview_3 = memref.subview %reinterpret_cast_1[%17, %21, %23, %25] [1, 32, 1, 32] [1, 1, 1, 1] : memref<2x128x8x512xbf16, strided<[524288, 4096, 512, 1]>> to memref<32x32xbf16, strided<[4096, 1], offset: ?>>
      %alloc_4 = memref.alloc() : memref<32x32xbf16>
      memref.copy %subview_3, %alloc_4 : memref<32x32xbf16, strided<[4096, 1], offset: ?>> to memref<32x32xbf16>
      %29 = bufferization.to_tensor %alloc_4 restrict : memref<32x32xbf16>
      %30 = tensor.empty() : tensor<32x32xf32>
      %31 = hivm.hir.vcast ins(%29 : tensor<32x32xbf16>) outs(%30 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %32 = hivm.hir.vmul ins(%28, %31 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%15 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %33 = hivm.hir.vadd ins(%arg13, %32 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%arg13 : tensor<32x32xf32>) -> tensor<32x32xf32>
      scf.yield %33 : tensor<32x32xf32>
    }
    %6 = hivm.hir.vreduce <sum> ins(%5 : tensor<32x32xf32>) outs(%2 : tensor<32x1xf32>) reduce_dims = [1] -> tensor<32x1xf32>
    %7 = arith.divsi %1, %c32_i32 : i32
    %8 = arith.index_cast %7 : i32 to index
    %9 = arith.remsi %1, %c32_i32 : i32
    %10 = arith.divsi %9, %c8_i32 : i32
    %11 = arith.muli %10, %c32_i32 : i32
    %12 = arith.index_cast %11 : i32 to index
    %13 = arith.remsi %1, %c8_i32 : i32
    %14 = arith.index_cast %13 : i32 to index
    %subview = memref.subview %reinterpret_cast_0[%8, %12, %14] [1, 32, 1] [1, 1, 1] : memref<2x128x8xf32, strided<[1024, 8, 1]>> to memref<32x1xf32, strided<[8, 1], offset: ?>>
    bufferization.materialize_in_destination %6 in writable %subview : (tensor<32x1xf32>, memref<32x1xf32, strided<[8, 1], offset: ?>>) -> ()
    return
  }
}