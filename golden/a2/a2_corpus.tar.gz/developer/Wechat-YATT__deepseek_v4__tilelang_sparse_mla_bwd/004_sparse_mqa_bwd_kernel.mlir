module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @sparse_mqa_bwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xf32>, %arg7: memref<?xi32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xbf16>, %arg11: memref<?xf32>, %arg12: memref<?xf32>, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %cst = arith.constant 0.000000e+00 : bf16
    %c163840 = arith.constant 163840 : index
    %c32768 = arith.constant 32768 : index
    %c128 = arith.constant 128 : index
    %c4096 = arith.constant 4096 : index
    %c16 = arith.constant 16 : index
    %c2097152 = arith.constant 2097152 : index
    %c8192 = arith.constant 8192 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant -1.000000e+00 : f32
    %cst_1 = arith.constant 1.44269502 : f32
    %c2_i32 = arith.constant 2 : i32
    %cst_2 = arith.constant 0.0441941731 : f32
    %true = arith.constant true
    %cst_3 = arith.constant 0.693147182 : f32
    %cst_4 = arith.constant 0.063758716 : f32
    %false = arith.constant false
    %cst_5 = arith.constant 0xFF800000 : f32
    %cst_6 = arith.constant 0.000000e+00 : f32
    %c8_i32 = arith.constant 8 : i32
    %c-1_i32 = arith.constant -1 : i32
    %c0_i32 = arith.constant 0 : i32
    %c16_i32 = arith.constant 16 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 256, 16, 512], strides: [%c2097152, %c8192, %c512, %c1] : memref<?xbf16> to memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 256, 16, 512], strides: [%c2097152, %c8192, %c512, %c1] : memref<?xbf16> to memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [1, 256, 16], strides: [%c4096, %c16, %c1] : memref<?xf32> to memref<1x256x16xf32, strided<[4096, 16, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 256, 128], strides: [%c32768, %c128, %c1] : memref<?xi32> to memref<1x256x128xi32, strided<[32768, 128, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [1, 320, 512], strides: [%c163840, %c512, %c1] : memref<?xf32> to memref<1x320x512xf32, strided<[163840, 512, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [1, 256, 16], strides: [%c4096, %c16, %c1] : memref<?xf32> to memref<1x256x16xf32, strided<[4096, 16, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 320, 512], strides: [%c163840, %c512, %c1] : memref<?xbf16> to memref<1x320x512xbf16, strided<[163840, 512, 1]>>
    %reinterpret_cast_13 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [16], strides: [%c1] : memref<?xf32> to memref<16xf32, strided<[1]>>
    %reinterpret_cast_14 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [16], strides: [%c1] : memref<?xf32> to memref<16xf32, strided<[1]>>
    %reinterpret_cast_15 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [1, 256, 16, 512], strides: [%c2097152, %c8192, %c512, %c1] : memref<?xbf16> to memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16xi32>
    %3 = tensor.empty() : tensor<16x512xf32>
    %4 = tensor.empty() : tensor<16xf32>
    %5 = tensor.empty() : tensor<16x16xf32>
    %6 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %6, 0, 0] [1, 1, 16, 512] [1, 1, 1, 1] : memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>> to memref<16x512xbf16, strided<[512, 1], offset: ?>>
    %alloc = memref.alloc() : memref<16x512xbf16>
    memref.copy %subview, %alloc : memref<16x512xbf16, strided<[512, 1], offset: ?>> to memref<16x512xbf16>
    %7 = bufferization.to_tensor %alloc restrict : memref<16x512xbf16>
    %subview_16 = memref.subview %reinterpret_cast_7[0, %6, 0, 0] [1, 1, 16, 512] [1, 1, 1, 1] : memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>> to memref<16x512xbf16, strided<[512, 1], offset: ?>>
    %alloc_17 = memref.alloc() : memref<16x512xbf16>
    memref.copy %subview_16, %alloc_17 : memref<16x512xbf16, strided<[512, 1], offset: ?>> to memref<16x512xbf16>
    %8 = bufferization.to_tensor %alloc_17 restrict : memref<16x512xbf16>
    %subview_18 = memref.subview %reinterpret_cast_8[0, %6, 0] [1, 1, 16] [1, 1, 1] : memref<1x256x16xf32, strided<[4096, 16, 1]>> to memref<16xf32, strided<[1], offset: ?>>
    %alloc_19 = memref.alloc() : memref<16xf32>
    memref.copy %subview_18, %alloc_19 : memref<16xf32, strided<[1], offset: ?>> to memref<16xf32>
    %9 = bufferization.to_tensor %alloc_19 restrict : memref<16xf32>
    %subview_20 = memref.subview %reinterpret_cast_11[0, %6, 0] [1, 1, 16] [1, 1, 1] : memref<1x256x16xf32, strided<[4096, 16, 1]>> to memref<16xf32, strided<[1], offset: ?>>
    %alloc_21 = memref.alloc() : memref<16xf32>
    memref.copy %subview_20, %alloc_21 : memref<16xf32, strided<[1], offset: ?>> to memref<16xf32>
    %10 = bufferization.to_tensor %alloc_21 restrict : memref<16xf32>
    %11 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%3 : tensor<16x512xf32>) -> tensor<16x512xf32>
    %12 = hivm.hir.vbrc ins(%c-1_i32 : i32) outs(%2 : tensor<16xi32>) -> tensor<16xi32>
    %13:2 = scf.for %arg19 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg20 = %5, %arg21 = %11) -> (tensor<16x16xf32>, tensor<16x512xf32>)  : i32 {
      %23 = tensor.empty() : tensor<16x512xbf16>
      %24 = tensor.empty() : tensor<16xi1>
      %25 = tensor.empty() : tensor<16x16xf32>
      %26 = tensor.empty() : tensor<16x16xf32>
      %27 = tensor.empty() : tensor<16x512xf32>
      %28 = tensor.empty() : tensor<16x512xf32>
      %29 = tensor.empty() : tensor<16x16xi1>
      %30 = tensor.empty() : tensor<16x16xf32>
      %31 = tensor.empty() : tensor<16x16xf32>
      %32 = tensor.empty() : tensor<16x16xf32>
      %33 = tensor.empty() : tensor<16x16xf32>
      %34 = tensor.empty() : tensor<16x16xf32>
      %35 = tensor.empty() : tensor<16x16xf32>
      %36 = tensor.empty() : tensor<16x16xf32>
      %37 = arith.index_cast %1 : i32 to index
      %38 = arith.muli %arg19, %c16_i32 : i32
      %39 = arith.index_cast %38 : i32 to index
      %subview_24 = memref.subview %reinterpret_cast_9[0, %37, %39] [1, 1, 16] [1, 1, 1] : memref<1x256x128xi32, strided<[32768, 128, 1]>> to memref<16xi32, strided<[1], offset: ?>>
      %alloc_25 = memref.alloc() : memref<16xi32>
      memref.copy %subview_24, %alloc_25 : memref<16xi32, strided<[1], offset: ?>> to memref<16xi32>
      %40 = bufferization.to_tensor %alloc_25 restrict : memref<16xi32>
      %41 = hivm.hir.vcmp ins(%40, %12 : tensor<16xi32>, tensor<16xi32>) outs(%24 : tensor<16xi1>) compare_mode = <ne> -> tensor<16xi1>
      %42 = hivm.hir.vbrc ins(%cst : bf16) outs(%23 : tensor<16x512xbf16>) -> tensor<16x512xbf16>
      %expanded = tensor.expand_shape %41 [[0, 1]] output_shape [1, 16] : tensor<16xi1> into tensor<1x16xi1>
      %43 = hivm.hir.vbrc ins(%expanded : tensor<1x16xi1>) outs(%29 : tensor<16x16xi1>) broadcast_dims = [0] -> tensor<16x16xi1>
      %44 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%30 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %45 = hivm.hir.vbrc ins(%cst_5 : f32) outs(%31 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %46 = hivm.hir.vsel ins(%43, %44, %45 : tensor<16x16xi1>, tensor<16x16xf32>, tensor<16x16xf32>) outs(%arg20 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %47 = scf.for %arg22 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg23 = %42) -> (tensor<16x512xbf16>)  : i32 {
        %67 = arith.index_cast %arg22 : i32 to index
        %extracted = tensor.extract %40[%67] : tensor<16xi32>
        %68 = arith.cmpi ne, %extracted, %c-1_i32 : i32
        %69 = scf.if %68 -> (tensor<16x512xbf16>) {
          %70 = arith.index_cast %extracted : i32 to index
          %71 = arith.index_cast %arg22 : i32 to index
          %subview_28 = memref.subview %reinterpret_cast_12[0, %70, 0] [1, 1, 512] [1, 1, 1] : memref<1x320x512xbf16, strided<[163840, 512, 1]>> to memref<512xbf16, strided<[1], offset: ?>>
          %alloc_29 = memref.alloc() : memref<512xbf16>
          memref.copy %subview_28, %alloc_29 : memref<512xbf16, strided<[1], offset: ?>> to memref<512xbf16>
          %72 = bufferization.to_tensor %alloc_29 restrict : memref<512xbf16>
          %inserted_slice = tensor.insert_slice %72 into %arg23[%71, 0] [1, 512] [1, 1] : tensor<512xbf16> into tensor<16x512xbf16>
          scf.yield %inserted_slice : tensor<16x512xbf16>
        } else {
          scf.yield %arg23 : tensor<16x512xbf16>
        }
        scf.yield %69 : tensor<16x512xbf16>
      }
      %48 = hivm.hir.mmadL1 {b_transpose} ins(%7, %47, %false, %c16, %c16, %c512 : tensor<16x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%46 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %expanded_26 = tensor.expand_shape %10 [[0, 1]] output_shape [16, 1] : tensor<16xf32> into tensor<16x1xf32>
      %49 = hivm.hir.vbrc ins(%expanded_26 : tensor<16x1xf32>) outs(%33 : tensor<16x16xf32>) broadcast_dims = [1] -> tensor<16x16xf32>
      %50 = hivm.hir.vmul ins(%48, %cst_4 : tensor<16x16xf32>, f32) outs(%32 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %51 = hivm.hir.vsub ins(%50, %49 : tensor<16x16xf32>, tensor<16x16xf32>) outs(%48 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %52 = hivm.hir.vmul ins(%51, %cst_3 : tensor<16x16xf32>, f32) outs(%25 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %53 = hivm.hir.vexp ins(%52 : tensor<16x16xf32>) outs(%51 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %54 = tensor.empty() : tensor<16x16xbf16>
      %55 = hivm.hir.vcast ins(%53 : tensor<16x16xf32>) outs(%54 : tensor<16x16xbf16>) -> tensor<16x16xbf16>
      %56 = hivm.hir.mmadL1 {b_transpose} ins(%8, %47, %true, %c16, %c16, %c512 : tensor<16x512xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%26 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %expanded_27 = tensor.expand_shape %9 [[0, 1]] output_shape [16, 1] : tensor<16xf32> into tensor<16x1xf32>
      %57 = hivm.hir.vbrc ins(%expanded_27 : tensor<16x1xf32>) outs(%34 : tensor<16x16xf32>) broadcast_dims = [1] -> tensor<16x16xf32>
      %58 = hivm.hir.vsub ins(%56, %57 : tensor<16x16xf32>, tensor<16x16xf32>) outs(%35 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %59 = hivm.hir.vmul ins(%53, %58 : tensor<16x16xf32>, tensor<16x16xf32>) outs(%36 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %60 = hivm.hir.vmul ins(%59, %cst_2 : tensor<16x16xf32>, f32) outs(%56 : tensor<16x16xf32>) -> tensor<16x16xf32>
      %61 = tensor.empty() : tensor<16x16xbf16>
      %62 = hivm.hir.vcast ins(%60 : tensor<16x16xf32>) outs(%61 : tensor<16x16xbf16>) -> tensor<16x16xbf16>
      %63 = hivm.hir.mmadL1 ins(%62, %47, %false, %c16, %c16, %c512 : tensor<16x16xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%arg21 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %64 = hivm.hir.mmadL1 {a_transpose} ins(%62, %7, %true, %c16, %c16, %c512 : tensor<16x16xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%27 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %65 = hivm.hir.mmadL1 {a_transpose} ins(%55, %8, %true, %c16, %c16, %c512 : tensor<16x16xbf16>, tensor<16x512xbf16>, i1, index, index, index) outs(%28 : tensor<16x512xf32>) -> tensor<16x512xf32>
      %66 = hivm.hir.vadd ins(%64, %65 : tensor<16x512xf32>, tensor<16x512xf32>) outs(%64 : tensor<16x512xf32>) -> tensor<16x512xf32>
      scf.for %arg22 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
        scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
          %67 = arith.muli %arg22, %c8_i32 : i32
          %68 = arith.addi %67, %arg23 : i32
          %69 = arith.index_cast %68 : i32 to index
          %extracted = tensor.extract %40[%69] : tensor<16xi32>
          %70 = arith.cmpi ne, %extracted, %c-1_i32 : i32
          scf.if %70 {
            %71 = arith.muli %arg22, %c8_i32 : i32
            %72 = arith.addi %71, %arg23 : i32
            %73 = arith.index_cast %72 : i32 to index
            %extracted_slice = tensor.extract_slice %66[%73, 0] [1, 512] [1, 1] : tensor<16x512xf32> to tensor<1x512xf32>
            %74 = arith.index_cast %extracted : i32 to index
            %subview_28 = memref.subview %reinterpret_cast_10[0, %74, 0] [1, 1, 512] [1, 1, 1] : memref<1x320x512xf32, strided<[163840, 512, 1]>> to memref<1x1x512xf32, strided<[163840, 512, 1], offset: ?>>
            %expanded_29 = tensor.expand_shape %extracted_slice [[0, 1], [2]] output_shape [1, 1, 512] : tensor<1x512xf32> into tensor<1x1x512xf32>
            hivm.hir.store ins(%expanded_29 : tensor<1x1x512xf32>) outs(%subview_28 : memref<1x1x512xf32, strided<[163840, 512, 1], offset: ?>>) atomic = <add>
          }
        }
      }
      scf.yield %53, %63 : tensor<16x16xf32>, tensor<16x512xf32>
    }
    %14 = tensor.empty() : tensor<16x512xbf16>
    %15 = hivm.hir.vcast ins(%13#1 : tensor<16x512xf32>) outs(%14 : tensor<16x512xbf16>) -> tensor<16x512xbf16>
    %subview_22 = memref.subview %reinterpret_cast_15[0, %6, 0, 0] [1, 1, 16, 512] [1, 1, 1, 1] : memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>> to memref<16x512xbf16, strided<[512, 1], offset: ?>>
    bufferization.materialize_in_destination %15 in writable %subview_22 : (tensor<16x512xbf16>, memref<16x512xbf16, strided<[512, 1], offset: ?>>) -> ()
    %alloc_23 = memref.alloc() : memref<16xf32>
    memref.copy %reinterpret_cast_13, %alloc_23 : memref<16xf32, strided<[1]>> to memref<16xf32>
    %16 = bufferization.to_tensor %alloc_23 restrict : memref<16xf32>
    %17 = hivm.hir.vmul ins(%16, %cst_1 : tensor<16xf32>, f32) outs(%16 : tensor<16xf32>) -> tensor<16xf32>
    %18 = hivm.hir.vsub ins(%17, %10 : tensor<16xf32>, tensor<16xf32>) outs(%17 : tensor<16xf32>) -> tensor<16xf32>
    %19 = hivm.hir.vmul ins(%18, %cst_3 : tensor<16xf32>, f32) outs(%4 : tensor<16xf32>) -> tensor<16xf32>
    %20 = hivm.hir.vexp ins(%19 : tensor<16xf32>) outs(%18 : tensor<16xf32>) -> tensor<16xf32>
    %21 = hivm.hir.vmul ins(%20, %9 : tensor<16xf32>, tensor<16xf32>) outs(%20 : tensor<16xf32>) -> tensor<16xf32>
    %22 = hivm.hir.vmul ins(%21, %cst_0 : tensor<16xf32>, f32) outs(%21 : tensor<16xf32>) -> tensor<16xf32>
    hivm.hir.store ins(%22 : tensor<16xf32>) outs(%reinterpret_cast_14 : memref<16xf32, strided<[1]>>) atomic = <add>
    return
  }
}