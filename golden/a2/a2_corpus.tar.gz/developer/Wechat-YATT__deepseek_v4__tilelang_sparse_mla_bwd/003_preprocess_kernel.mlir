module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @preprocess_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xf32>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c4096 = arith.constant 4096 : index
    %c16 = arith.constant 16 : index
    %c2097152 = arith.constant 2097152 : index
    %c8192 = arith.constant 8192 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %c32_i32 = arith.constant 32 : i32
    %c0_i32 = arith.constant 0 : i32
    %c16_i32 = arith.constant 16 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 256, 16, 512], strides: [%c2097152, %c8192, %c512, %c1] : memref<?xbf16> to memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 256, 16], strides: [%c4096, %c16, %c1] : memref<?xf32> to memref<1x256x16xf32, strided<[4096, 16, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 256, 16, 512], strides: [%c2097152, %c8192, %c512, %c1] : memref<?xbf16> to memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<32x1xf32>
    %3 = tensor.empty() : tensor<32x32xf32>
    %4 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<32x32xf32>) -> tensor<32x32xf32>
    %5 = scf.for %arg12 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg13 = %4) -> (tensor<32x32xf32>)  : i32 {
      %12 = tensor.empty() : tensor<32x32xf32>
      %13 = arith.divsi %1, %c16_i32 : i32
      %14 = arith.muli %13, %c32_i32 : i32
      %15 = arith.index_cast %14 : i32 to index
      %16 = arith.remsi %1, %c16_i32 : i32
      %17 = arith.index_cast %16 : i32 to index
      %18 = arith.muli %arg12, %c32_i32 : i32
      %19 = arith.index_cast %18 : i32 to index
      %subview_2 = memref.subview %reinterpret_cast[0, %15, %17, %19] [1, 32, 1, 32] [1, 1, 1, 1] : memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>> to memref<32x32xbf16, strided<[8192, 1], offset: ?>>
      %alloc = memref.alloc() : memref<32x32xbf16>
      memref.copy %subview_2, %alloc : memref<32x32xbf16, strided<[8192, 1], offset: ?>> to memref<32x32xbf16>
      %20 = bufferization.to_tensor %alloc restrict : memref<32x32xbf16>
      %21 = tensor.empty() : tensor<32x32xf32>
      %22 = hivm.hir.vcast ins(%20 : tensor<32x32xbf16>) outs(%21 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %subview_3 = memref.subview %reinterpret_cast_1[0, %15, %17, %19] [1, 32, 1, 32] [1, 1, 1, 1] : memref<1x256x16x512xbf16, strided<[2097152, 8192, 512, 1]>> to memref<32x32xbf16, strided<[8192, 1], offset: ?>>
      %alloc_4 = memref.alloc() : memref<32x32xbf16>
      memref.copy %subview_3, %alloc_4 : memref<32x32xbf16, strided<[8192, 1], offset: ?>> to memref<32x32xbf16>
      %23 = bufferization.to_tensor %alloc_4 restrict : memref<32x32xbf16>
      %24 = tensor.empty() : tensor<32x32xf32>
      %25 = hivm.hir.vcast ins(%23 : tensor<32x32xbf16>) outs(%24 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %26 = hivm.hir.vmul ins(%22, %25 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%12 : tensor<32x32xf32>) -> tensor<32x32xf32>
      %27 = hivm.hir.vadd ins(%arg13, %26 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%arg13 : tensor<32x32xf32>) -> tensor<32x32xf32>
      scf.yield %27 : tensor<32x32xf32>
    }
    %6 = hivm.hir.vreduce <sum> ins(%5 : tensor<32x32xf32>) outs(%2 : tensor<32x1xf32>) reduce_dims = [1] -> tensor<32x1xf32>
    %7 = arith.divsi %1, %c16_i32 : i32
    %8 = arith.muli %7, %c32_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %10 = arith.remsi %1, %c16_i32 : i32
    %11 = arith.index_cast %10 : i32 to index
    %subview = memref.subview %reinterpret_cast_0[0, %9, %11] [1, 32, 1] [1, 1, 1] : memref<1x256x16xf32, strided<[4096, 16, 1]>> to memref<32x1xf32, strided<[16, 1], offset: ?>>
    bufferization.materialize_in_destination %6 in writable %subview : (tensor<32x1xf32>, memref<32x1xf32, strided<[16, 1], offset: ?>>) -> ()
    return
  }
}