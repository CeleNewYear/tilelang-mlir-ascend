module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xi32>, %arg6: memref<?xf16>, %arg7: memref<?xf32>, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c8192 = arith.constant 8192 : index
    %c1024 = arith.constant 1024 : index
    %c128 = arith.constant 128 : index
    %c16 = arith.constant 16 : index
    %c64 = arith.constant 64 : index
    %c8 = arith.constant 8 : index
    %c10240 = arith.constant 10240 : index
    %c1280 = arith.constant 1280 : index
    %c80 = arith.constant 80 : index
    %c1 = arith.constant 1 : index
    %false = arith.constant false
    %true = arith.constant true
    %cst_0 = arith.constant 0.111803398 : f32
    %cst_1 = arith.constant 0xFF800000 : f32
    %c0_i32 = arith.constant 0 : i32
    %c8_i32 = arith.constant 8 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 16, 80], strides: [%c10240, %c1280, %c80, %c1] : memref<?xf16> to memref<1x8x16x80xf16, strided<[10240, 1280, 80, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 8, 1, 8], strides: [%c64, %c8, %c8, %c1] : memref<?xi32> to memref<1x8x1x8xi32, strided<[64, 8, 8, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 8, 16, 1], strides: [%c128, %c16, %c1, %c1] : memref<?xf32> to memref<1x8x16x1xf32, strided<[128, 16, 1, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1, 16, 1, 80], strides: [%c1280, %c80, %c80, %c1] : memref<?xf16> to memref<1x16x1x80xf16, strided<[1280, 80, 80, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1, 8, 16, 64], strides: [%c8192, %c1024, %c64, %c1] : memref<?xf16> to memref<1x8x16x64xf16, strided<[8192, 1024, 64, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<16x1xf32>
    %3 = tensor.empty() : tensor<16x1xf32>
    %4 = tensor.empty() : tensor<16x64xf32>
    %5 = tensor.empty() : tensor<16x8xf32>
    %6 = tensor.empty() : tensor<16x64xf16>
    %7 = tensor.empty() : tensor<16x1xf32>
    %8 = tensor.empty() : tensor<16x8xf32>
    %9 = hivm.hir.vbrc ins(%cst : f32) outs(%4 : tensor<16x64xf32>) -> tensor<16x64xf32>
    %10 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %11 = hivm.hir.vbrc ins(%cst_1 : f32) outs(%2 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %12 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%5 : tensor<16x8xf32>) -> tensor<16x8xf32>
    %13 = arith.index_cast %1 : i32 to index
    %subview = memref.subview %reinterpret_cast[0, %13, 0, 0] [1, 1, 16, 64] [1, 1, 1, 1] : memref<1x8x16x80xf16, strided<[10240, 1280, 80, 1]>> to memref<16x64xf16, strided<[80, 1], offset: ?>>
    %alloc = memref.alloc() : memref<16x64xf16>
    memref.copy %subview, %alloc : memref<16x64xf16, strided<[80, 1], offset: ?>> to memref<16x64xf16>
    %14 = bufferization.to_tensor %alloc restrict : memref<16x64xf16>
    %subview_6 = memref.subview %reinterpret_cast[0, %13, 0, 64] [1, 1, 16, 16] [1, 1, 1, 1] : memref<1x8x16x80xf16, strided<[10240, 1280, 80, 1]>> to memref<16x16xf16, strided<[80, 1], offset: ?>>
    %alloc_7 = memref.alloc() : memref<16x16xf16>
    memref.copy %subview_6, %alloc_7 : memref<16x16xf16, strided<[80, 1], offset: ?>> to memref<16x16xf16>
    %15 = bufferization.to_tensor %alloc_7 restrict : memref<16x16xf16>
    %16 = tensor.empty() : tensor<8x64xf16>
    %17 = tensor.empty() : tensor<8x16xf16>
    %18 = tensor.empty() : tensor<16x8xf16>
    %19 = tensor.empty() : tensor<16x1xf32>
    %20 = tensor.empty() : tensor<16x1xf32>
    %21 = tensor.empty() : tensor<16x1xf32>
    %22 = tensor.empty() : tensor<16x8xf32>
    %23 = tensor.empty() : tensor<16x1xf32>
    %24 = tensor.empty() : tensor<16x1xf32>
    %25 = arith.index_cast %1 : i32 to index
    %subview_8 = memref.subview %reinterpret_cast_2[0, %25, 0, 0] [1, 1, 1, 8] [1, 1, 1, 1] : memref<1x8x1x8xi32, strided<[64, 8, 8, 1]>> to memref<8xi32, strided<[1], offset: ?>>
    %alloc_9 = memref.alloc() : memref<8xi32>
    memref.copy %subview_8, %alloc_9 : memref<8xi32, strided<[1], offset: ?>> to memref<8xi32>
    %26 = bufferization.to_tensor %alloc_9 restrict : memref<8xi32>
    %27:2 = scf.for %arg14 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg15 = %16, %arg16 = %17) -> (tensor<8x64xf16>, tensor<8x16xf16>)  : i32 {
      %49 = arith.index_cast %arg14 : i32 to index
      %extracted = tensor.extract %26[%49] : tensor<8xi32>
      %50 = arith.index_cast %extracted : i32 to index
      %subview_12 = memref.subview %reinterpret_cast_4[0, %50, 0, 0] [1, 1, 1, 64] [1, 1, 1, 1] : memref<1x16x1x80xf16, strided<[1280, 80, 80, 1]>> to memref<64xf16, strided<[1], offset: ?>>
      %alloc_13 = memref.alloc() : memref<64xf16>
      memref.copy %subview_12, %alloc_13 : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
      %51 = bufferization.to_tensor %alloc_13 restrict : memref<64xf16>
      %inserted_slice = tensor.insert_slice %51 into %arg15[%49, 0] [1, 64] [1, 1] : tensor<64xf16> into tensor<8x64xf16>
      %subview_14 = memref.subview %reinterpret_cast_4[0, %50, 0, 64] [1, 1, 1, 16] [1, 1, 1, 1] : memref<1x16x1x80xf16, strided<[1280, 80, 80, 1]>> to memref<16xf16, strided<[1], offset: ?>>
      %alloc_15 = memref.alloc() : memref<16xf16>
      memref.copy %subview_14, %alloc_15 : memref<16xf16, strided<[1], offset: ?>> to memref<16xf16>
      %52 = bufferization.to_tensor %alloc_15 restrict : memref<16xf16>
      %inserted_slice_16 = tensor.insert_slice %52 into %arg16[%49, 0] [1, 16] [1, 1] : tensor<16xf16> into tensor<8x16xf16>
      scf.yield %inserted_slice, %inserted_slice_16 : tensor<8x64xf16>, tensor<8x16xf16>
    }
    %28 = hivm.hir.mmadL1 {b_transpose} ins(%14, %27#0, %true, %c16, %c8, %c64 : tensor<16x64xf16>, tensor<8x64xf16>, i1, index, index, index) outs(%8 : tensor<16x8xf32>) -> tensor<16x8xf32>
    %29 = hivm.hir.mmadL1 {b_transpose} ins(%15, %27#1, %false, %c16, %c8, %c16 : tensor<16x16xf16>, tensor<8x16xf16>, i1, index, index, index) outs(%28 : tensor<16x8xf32>) -> tensor<16x8xf32>
    %30 = hivm.hir.vmul ins(%29, %12 : tensor<16x8xf32>, tensor<16x8xf32>) outs(%29 : tensor<16x8xf32>) -> tensor<16x8xf32>
    %31 = hivm.hir.vreduce <max> ins(%30 : tensor<16x8xf32>) outs(%20 : tensor<16x1xf32>) reduce_dims = [1] -> tensor<16x1xf32>
    %32 = hivm.hir.vmax ins(%11, %31 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%24 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %33 = hivm.hir.vsub ins(%11, %32 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%23 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %34 = hivm.hir.vexp ins(%33 : tensor<16x1xf32>) outs(%19 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %35 = hivm.hir.vsub ins(%30, %32 : tensor<16x8xf32>, tensor<16x1xf32>) outs(%22 : tensor<16x8xf32>) broadcast = [1] -> tensor<16x8xf32>
    %36 = hivm.hir.vexp ins(%35 : tensor<16x8xf32>) outs(%30 : tensor<16x8xf32>) -> tensor<16x8xf32>
    %37 = hivm.hir.vreduce <sum> ins(%36 : tensor<16x8xf32>) outs(%21 : tensor<16x1xf32>) reduce_dims = [1] -> tensor<16x1xf32>
    %38 = hivm.hir.vmul ins(%10, %34 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%10 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %39 = hivm.hir.vadd ins(%38, %37 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%38 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %40 = hivm.hir.vmul ins(%9, %34 : tensor<16x64xf32>, tensor<16x1xf32>) outs(%9 : tensor<16x64xf32>) broadcast = [1] -> tensor<16x64xf32>
    %41 = hivm.hir.vcast ins(%36 : tensor<16x8xf32>) outs(%18 : tensor<16x8xf16>) -> tensor<16x8xf16>
    %42 = hivm.hir.vbrc ins(%cst : f32) outs(%33 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %43 = hivm.hir.vadd ins(%42, %32 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%11 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %44 = hivm.hir.mmadL1 ins(%41, %27#0, %false, %c16, %c8, %c64 : tensor<16x8xf16>, tensor<8x64xf16>, i1, index, index, index) outs(%40 : tensor<16x64xf32>) -> tensor<16x64xf32>
    %45 = hivm.hir.vdiv ins(%44, %39 : tensor<16x64xf32>, tensor<16x1xf32>) outs(%44 : tensor<16x64xf32>) broadcast = [1] -> tensor<16x64xf32>
    %46 = hivm.hir.vcast ins(%45 : tensor<16x64xf32>) outs(%6 : tensor<16x64xf16>) -> tensor<16x64xf16>
    %subview_10 = memref.subview %reinterpret_cast_5[0, %13, 0, 0] [1, 1, 16, 64] [1, 1, 1, 1] : memref<1x8x16x64xf16, strided<[8192, 1024, 64, 1]>> to memref<16x64xf16, strided<[64, 1], offset: ?>>
    bufferization.materialize_in_destination %46 in writable %subview_10 : (tensor<16x64xf16>, memref<16x64xf16, strided<[64, 1], offset: ?>>) -> ()
    %47 = hivm.hir.vln ins(%39 : tensor<16x1xf32>) outs(%7 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %48 = hivm.hir.vadd ins(%47, %43 : tensor<16x1xf32>, tensor<16x1xf32>) outs(%47 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %subview_11 = memref.subview %reinterpret_cast_3[0, %13, 0, 0] [1, 1, 16, 1] [1, 1, 1, 1] : memref<1x8x16x1xf32, strided<[128, 16, 1, 1]>> to memref<16x1xf32, strided<[1, 1], offset: ?>>
    bufferization.materialize_in_destination %48 in writable %subview_11 : (tensor<16x1xf32>, memref<16x1xf32, strided<[1, 1], offset: ?>>) -> ()
    return
  }
}