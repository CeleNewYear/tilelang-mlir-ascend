module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 1.442380e+00 : f16
    %c8_i32 = arith.constant 8 : i32
    %c2_i32 = arith.constant 2 : i32
    %c4_i32 = arith.constant 4 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [16, 16], strides: [%c16, %c1] : memref<?xf16> to memref<16x16xf16, strided<[16, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [16, 16], strides: [%c16, %c1] : memref<?xf16> to memref<16x16xf16, strided<[16, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<8x8xf16>
    %3 = tensor.empty() : tensor<8x8xf16>
    %4 = arith.cmpi slt, %1, %c4_i32 : i32
    scf.if %4 {
      %5 = arith.divsi %1, %c2_i32 : i32
      %6 = arith.muli %5, %c8_i32 : i32
      %7 = arith.index_cast %6 : i32 to index
      %8 = arith.remsi %1, %c2_i32 : i32
      %9 = arith.muli %8, %c8_i32 : i32
      %10 = arith.index_cast %9 : i32 to index
      %subview = memref.subview %reinterpret_cast[%7, %10] [8, 8] [1, 1] : memref<16x16xf16, strided<[16, 1]>> to memref<8x8xf16, strided<[16, 1], offset: ?>>
      %alloc = memref.alloc() : memref<8x8xf16>
      memref.copy %subview, %alloc : memref<8x8xf16, strided<[16, 1], offset: ?>> to memref<8x8xf16>
      %11 = bufferization.to_tensor %alloc restrict : memref<8x8xf16>
      %12 = hivm.hir.vln ins(%11 : tensor<8x8xf16>) outs(%3 : tensor<8x8xf16>) -> tensor<8x8xf16>
      %13 = hivm.hir.vmul ins(%12, %cst : tensor<8x8xf16>, f16) outs(%2 : tensor<8x8xf16>) -> tensor<8x8xf16>
      %subview_1 = memref.subview %reinterpret_cast_0[%7, %10] [8, 8] [1, 1] : memref<16x16xf16, strided<[16, 1]>> to memref<8x8xf16, strided<[16, 1], offset: ?>>
      bufferization.materialize_in_destination %13 in writable %subview_1 : (tensor<8x8xf16>, memref<8x8xf16, strided<[16, 1], offset: ?>>) -> ()
    }
    return
  }
}