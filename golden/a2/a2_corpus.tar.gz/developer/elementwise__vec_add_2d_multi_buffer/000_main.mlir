module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %c384_i32 = arith.constant 384 : i32
    %c128_i32 = arith.constant 128 : i32
    %c32_i32 = arith.constant 32 : i32
    %c48_i32 = arith.constant 48 : i32
    %c1071_i32 = arith.constant 1071 : i32
    %c2_i32 = arith.constant 2 : i32
    %c3_i32 = arith.constant 3 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4096, 4096], strides: [%c4096, %c1] : memref<?xf16> to memref<4096x4096xf16, strided<[4096, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4096, 4096], strides: [%c4096, %c1] : memref<?xf16> to memref<4096x4096xf16, strided<[4096, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4096, 4096], strides: [%c4096, %c1] : memref<?xf16> to memref<4096x4096xf16, strided<[4096, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    scf.for %arg12 = %c0_i32 to %c3_i32 step %c1_i32  : i32 {
      %5 = arith.extsi %arg12 : i32 to i64
      hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, %5]
    }
    scf.for %arg12 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
      %5 = arith.extsi %arg12 : i32 to i64
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, %5]
    }
    %2 = arith.subi %c1071_i32, %1 : i32
    %3 = arith.divsi %2, %c48_i32 : i32
    %4 = arith.addi %3, %c2_i32 : i32
    scf.for %arg12 = %c0_i32 to %4 step %c1_i32  : i32 {
      %5 = tensor.empty() : tensor<5x128x128xf16>
      %6 = arith.subi %c1071_i32, %1 : i32
      %7 = arith.divsi %6, %c48_i32 : i32
      %8 = arith.cmpi slt, %arg12, %7 : i32
      %9 = scf.if %8 -> (tensor<5x128x128xf16>) {
        %15 = arith.remsi %arg12, %c3_i32 : i32
        %16 = arith.extsi %15 : i32 to i64
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, %16]
        %17 = arith.muli %arg12, %c48_i32 : i32
        %18 = arith.addi %17, %1 : i32
        %19 = arith.divsi %18, %c32_i32 : i32
        %20 = arith.muli %19, %c128_i32 : i32
        %21 = arith.index_cast %20 : i32 to index
        %22 = arith.remsi %18, %c32_i32 : i32
        %23 = arith.muli %22, %c128_i32 : i32
        %24 = arith.index_cast %23 : i32 to index
        %25 = arith.index_cast %15 : i32 to index
        %subview = memref.subview %reinterpret_cast[%21, %24] [128, 128] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<128x128xf16, strided<[4096, 1], offset: ?>>
        %alloc = memref.alloc() : memref<128x128xf16>
        memref.copy %subview, %alloc : memref<128x128xf16, strided<[4096, 1], offset: ?>> to memref<128x128xf16>
        %26 = bufferization.to_tensor %alloc restrict : memref<128x128xf16>
        %inserted_slice = tensor.insert_slice %26 into %5[%25, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<128x128xf16> into tensor<5x128x128xf16>
        %27 = arith.remsi %arg12, %c2_i32 : i32
        %28 = arith.extsi %27 : i32 to i64
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, %28]
        %29 = arith.addi %27, %c3_i32 : i32
        %30 = arith.index_cast %29 : i32 to index
        %subview_2 = memref.subview %reinterpret_cast_1[%21, %24] [128, 128] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<128x128xf16, strided<[4096, 1], offset: ?>>
        %alloc_3 = memref.alloc() : memref<128x128xf16>
        memref.copy %subview_2, %alloc_3 : memref<128x128xf16, strided<[4096, 1], offset: ?>> to memref<128x128xf16>
        %31 = bufferization.to_tensor %alloc_3 restrict : memref<128x128xf16>
        %inserted_slice_4 = tensor.insert_slice %31 into %inserted_slice[%30, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<128x128xf16> into tensor<5x128x128xf16>
        %32 = arith.extsi %15 : i32 to i64
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, %32]
        scf.yield %inserted_slice_4 : tensor<5x128x128xf16>
      } else {
        scf.yield %5 : tensor<5x128x128xf16>
      }
      %10 = arith.cmpi sgt, %arg12, %c0_i32 : i32
      %11 = arith.cmpi sle, %arg12, %7 : i32
      %12 = arith.andi %10, %11 : i1
      %13 = scf.if %12 -> (tensor<5x128x128xf16>) {
        %15 = arith.addi %arg12, %c2_i32 : i32
        %16 = arith.remsi %15, %c3_i32 : i32
        %17 = arith.extsi %16 : i32 to i64
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, %17]
        %18 = arith.index_cast %16 : i32 to index
        %extracted_slice = tensor.extract_slice %9[%18, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<5x128x128xf16> to tensor<1x128x128xf16>
        %19 = arith.addi %arg12, %c1_i32 : i32
        %20 = arith.remsi %19, %c2_i32 : i32
        %21 = arith.addi %20, %c3_i32 : i32
        %22 = arith.index_cast %21 : i32 to index
        %extracted_slice_2 = tensor.extract_slice %9[%22, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<5x128x128xf16> to tensor<1x128x128xf16>
        %23 = tensor.empty() : tensor<1x128x128xf16>
        %24 = hivm.hir.vadd ins(%extracted_slice, %extracted_slice_2 : tensor<1x128x128xf16>, tensor<1x128x128xf16>) outs(%23 : tensor<1x128x128xf16>) -> tensor<1x128x128xf16>
        %inserted_slice = tensor.insert_slice %24 into %9[%18, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<1x128x128xf16> into tensor<5x128x128xf16>
        %25 = arith.extsi %20 : i32 to i64
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, %25]
        %26 = arith.extsi %16 : i32 to i64
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, %26]
        scf.yield %inserted_slice : tensor<5x128x128xf16>
      } else {
        scf.yield %9 : tensor<5x128x128xf16>
      }
      %14 = arith.cmpi sgt, %arg12, %c1_i32 : i32
      scf.if %14 {
        %15 = arith.addi %arg12, %c1_i32 : i32
        %16 = arith.remsi %15, %c3_i32 : i32
        %17 = arith.extsi %16 : i32 to i64
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, %17]
        %18 = arith.index_cast %16 : i32 to index
        %19 = arith.muli %arg12, %c48_i32 : i32
        %20 = arith.addi %19, %1 : i32
        %21 = arith.divsi %20, %c32_i32 : i32
        %22 = arith.muli %21, %c128_i32 : i32
        %23 = arith.subi %22, %c384_i32 : i32
        %24 = arith.index_cast %23 : i32 to index
        %25 = arith.remsi %20, %c32_i32 : i32
        %26 = arith.muli %25, %c128_i32 : i32
        %27 = arith.index_cast %26 : i32 to index
        %extracted_slice = tensor.extract_slice %13[%18, 0, 0] [1, 128, 128] [1, 1, 1] : tensor<5x128x128xf16> to tensor<128x128xf16>
        %subview = memref.subview %reinterpret_cast_0[%24, %27] [128, 128] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<128x128xf16, strided<[4096, 1], offset: ?>>
        bufferization.materialize_in_destination %extracted_slice in writable %subview : (tensor<128x128xf16>, memref<128x128xf16, strided<[4096, 1], offset: ?>>) -> ()
        %28 = arith.extsi %16 : i32 to i64
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, %28]
      }
    }
    scf.for %arg12 = %c0_i32 to %c3_i32 step %c1_i32  : i32 {
      %5 = arith.extsi %arg12 : i32 to i64
      hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, %5]
    }
    scf.for %arg12 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
      %5 = arith.extsi %arg12 : i32 to i64
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, %5]
    }
    return
  }
}