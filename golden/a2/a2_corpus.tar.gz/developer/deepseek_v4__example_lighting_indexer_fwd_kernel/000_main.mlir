module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c16 = arith.constant 16 : index
    %c8 = arith.constant 8 : index
    %c32 = arith.constant 32 : index
    %c1 = arith.constant 1 : index
    %true = arith.constant true
    %c0_i32 = arith.constant 0 : i32
    %c4_i32 = arith.constant 4 : i32
    %c16_i32 = arith.constant 16 : i32
    %c8_i32 = arith.constant 8 : i32
    %c32_i32 = arith.constant 32 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [64, 32], strides: [%c32, %c1] : memref<?xbf16> to memref<64x32xbf16, strided<[32, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [8, 8], strides: [%c8, %c1] : memref<?xf32> to memref<8x8xf32, strided<[8, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [16, 32], strides: [%c32, %c1] : memref<?xbf16> to memref<16x32xbf16, strided<[32, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [8, 16], strides: [%c16, %c1] : memref<?xf32> to memref<8x16xf32, strided<[16, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = arith.muli %1, %c32_i32 : i32
    %3 = arith.index_cast %2 : i32 to index
    %subview = memref.subview %reinterpret_cast[%3, 0] [32, 32] [1, 1] : memref<64x32xbf16, strided<[32, 1]>> to memref<32x32xbf16, strided<[32, 1], offset: ?>>
    %alloc = memref.alloc() : memref<32x32xbf16>
    memref.copy %subview, %alloc : memref<32x32xbf16, strided<[32, 1], offset: ?>> to memref<32x32xbf16>
    %4 = bufferization.to_tensor %alloc restrict : memref<32x32xbf16>
    %5 = arith.muli %1, %c4_i32 : i32
    %6 = arith.index_cast %5 : i32 to index
    %subview_3 = memref.subview %reinterpret_cast_0[%6, 0] [4, 8] [1, 1] : memref<8x8xf32, strided<[8, 1]>> to memref<4x8xf32, strided<[8, 1], offset: ?>>
    %alloc_4 = memref.alloc() : memref<4x8xf32>
    memref.copy %subview_3, %alloc_4 : memref<4x8xf32, strided<[8, 1], offset: ?>> to memref<4x8xf32>
    %7 = bufferization.to_tensor %alloc_4 restrict : memref<4x8xf32>
    %8 = tensor.empty() : tensor<16x32xf32>
    %9 = tensor.empty() : tensor<16x32xf32>
    %10 = tensor.empty() : tensor<16x32xf32>
    %11 = tensor.empty() : tensor<16x32xf32>
    %12 = tensor.empty() : tensor<16x32xf32>
    %13 = tensor.empty() : tensor<16x4xf32>
    %14 = tensor.empty() : tensor<4x16xf32>
    %alloc_5 = memref.alloc() : memref<16x32xbf16>
    memref.copy %reinterpret_cast_1, %alloc_5 : memref<16x32xbf16, strided<[32, 1]>> to memref<16x32xbf16>
    %15 = bufferization.to_tensor %alloc_5 restrict : memref<16x32xbf16>
    %16 = hivm.hir.mmadL1 {b_transpose} ins(%15, %4, %true, %c16, %c32, %c32 : tensor<16x32xbf16>, tensor<32x32xbf16>, i1, index, index, index) outs(%8 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %17 = hivm.hir.vbrc ins(%cst : f32) outs(%11 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %18 = hivm.hir.vmax ins(%16, %17 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%9 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %19 = scf.for %arg13 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg14 = %12) -> (tensor<16x32xf32>)  : i32 {
      %26 = scf.for %arg15 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg16 = %arg14) -> (tensor<16x32xf32>)  : i32 {
        %27 = arith.divsi %arg15, %c8_i32 : i32
        %28 = arith.index_cast %27 : i32 to index
        %29 = arith.remsi %arg15, %c8_i32 : i32
        %30 = arith.index_cast %29 : i32 to index
        %extracted = tensor.extract %7[%28, %30] : tensor<4x8xf32>
        %31 = arith.index_cast %arg13 : i32 to index
        %32 = arith.index_cast %arg15 : i32 to index
        %inserted = tensor.insert %extracted into %arg16[%31, %32] : tensor<16x32xf32>
        scf.yield %inserted : tensor<16x32xf32>
      }
      scf.yield %26 : tensor<16x32xf32>
    }
    %20 = hivm.hir.vmul ins(%18, %19 : tensor<16x32xf32>, tensor<16x32xf32>) outs(%10 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %21 = hivm.hir.vbrc ins(%cst : f32) outs(%13 : tensor<16x4xf32>) -> tensor<16x4xf32>
    %22 = scf.for %arg13 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg14 = %21) -> (tensor<16x4xf32>)  : i32 {
      %26 = scf.for %arg15 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg16 = %arg14) -> (tensor<16x4xf32>)  : i32 {
        %27 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %arg16) -> (tensor<16x4xf32>)  : i32 {
          %28 = arith.index_cast %arg17 : i32 to index
          %29 = arith.index_cast %arg15 : i32 to index
          %extracted = tensor.extract %arg18[%28, %29] : tensor<16x4xf32>
          %30 = arith.muli %arg15, %c8_i32 : i32
          %31 = arith.addi %30, %arg13 : i32
          %32 = arith.index_cast %31 : i32 to index
          %extracted_7 = tensor.extract %20[%28, %32] : tensor<16x32xf32>
          %33 = arith.addf %extracted, %extracted_7 : f32
          %inserted = tensor.insert %33 into %arg18[%28, %29] : tensor<16x4xf32>
          scf.yield %inserted : tensor<16x4xf32>
        }
        scf.yield %27 : tensor<16x4xf32>
      }
      scf.yield %26 : tensor<16x4xf32>
    }
    %23 = scf.for %arg13 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg14 = %14) -> (tensor<4x16xf32>)  : i32 {
      %26 = scf.for %arg15 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg16 = %arg14) -> (tensor<4x16xf32>)  : i32 {
        %27 = arith.index_cast %arg15 : i32 to index
        %28 = arith.index_cast %arg13 : i32 to index
        %extracted = tensor.extract %22[%27, %28] : tensor<16x4xf32>
        %inserted = tensor.insert %extracted into %arg16[%28, %27] : tensor<4x16xf32>
        scf.yield %inserted : tensor<4x16xf32>
      }
      scf.yield %26 : tensor<4x16xf32>
    }
    %24 = arith.muli %1, %c4_i32 : i32
    %25 = arith.index_cast %24 : i32 to index
    %subview_6 = memref.subview %reinterpret_cast_2[%25, 0] [4, 16] [1, 1] : memref<8x16xf32, strided<[16, 1]>> to memref<4x16xf32, strided<[16, 1], offset: ?>>
    bufferization.materialize_in_destination %23 in writable %subview_6 : (tensor<4x16xf32>, memref<4x16xf32, strided<[16, 1], offset: ?>>) -> ()
    return
  }
}