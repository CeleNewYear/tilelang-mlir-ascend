module attributes {hivm.module_core_type = #hivm.module_core_type<AIC>, memref.memref_as_ptr} {
  func.func @gemm(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xi8>, %arg4: memref<?xi8>, %arg5: memref<?xi32>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, mix_mode = "aic"} {
    %c32 = arith.constant 32 : index
    %c128 = arith.constant 128 : index
    %c1024 = arith.constant 1024 : index
    %c1 = arith.constant 1 : index
    %c128_i32 = arith.constant 128 : i32
    %c8_i32 = arith.constant 8 : i32
    %c32_i32 = arith.constant 32 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xi8> to memref<1024x1024xi8, strided<[1024, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xi32> to memref<1024x1024xi32, strided<[1024, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1024, 1024], strides: [%c1024, %c1] : memref<?xi8> to memref<1024x1024xi8, strided<[1024, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<128x128xi32>
    %3 = scf.for %arg12 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg13 = %2) -> (tensor<128x128xi32>)  : i32 {
      %10 = arith.divsi %1, %c8_i32 : i32
      %11 = arith.muli %10, %c128_i32 : i32
      %12 = arith.index_cast %11 : i32 to index
      %13 = arith.muli %arg12, %c32_i32 : i32
      %14 = arith.index_cast %13 : i32 to index
      %subview_2 = memref.subview %reinterpret_cast[%12, %14] [128, 32] [1, 1] : memref<1024x1024xi8, strided<[1024, 1]>> to memref<128x32xi8, strided<[1024, 1], offset: ?>>
      %alloc = memref.alloc() : memref<128x32xi8>
      memref.copy %subview_2, %alloc : memref<128x32xi8, strided<[1024, 1], offset: ?>> to memref<128x32xi8>
      %15 = bufferization.to_tensor %alloc restrict : memref<128x32xi8>
      %16 = arith.remsi %1, %c8_i32 : i32
      %17 = arith.muli %16, %c128_i32 : i32
      %18 = arith.index_cast %17 : i32 to index
      %subview_3 = memref.subview %reinterpret_cast_1[%14, %18] [32, 128] [1, 1] : memref<1024x1024xi8, strided<[1024, 1]>> to memref<32x128xi8, strided<[1024, 1], offset: ?>>
      %alloc_4 = memref.alloc() : memref<32x128xi8>
      memref.copy %subview_3, %alloc_4 : memref<32x128xi8, strided<[1024, 1], offset: ?>> to memref<32x128xi8>
      %19 = bufferization.to_tensor %alloc_4 restrict : memref<32x128xi8>
      %20 = arith.cmpi eq, %arg12, %c0_i32 : i32
      %21 = hivm.hir.mmadL1 ins(%15, %19, %20, %c128, %c32, %c128 : tensor<128x32xi8>, tensor<32x128xi8>, i1, index, index, index) outs(%arg13 : tensor<128x128xi32>) -> tensor<128x128xi32>
      scf.yield %21 : tensor<128x128xi32>
    }
    %4 = arith.divsi %1, %c8_i32 : i32
    %5 = arith.muli %4, %c128_i32 : i32
    %6 = arith.index_cast %5 : i32 to index
    %7 = arith.remsi %1, %c8_i32 : i32
    %8 = arith.muli %7, %c128_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %subview = memref.subview %reinterpret_cast_0[%6, %9] [128, 128] [1, 1] : memref<1024x1024xi32, strided<[1024, 1]>> to memref<128x128xi32, strided<[1024, 1], offset: ?>>
    bufferization.materialize_in_destination %3 in writable %subview : (tensor<128x128xi32>, memref<128x128xi32, strided<[1024, 1], offset: ?>>) -> ()
    return
  }
}