module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xf32>, %arg6: memref<?xi32>, %arg7: memref<?xf32>, %arg8: memref<?xbf16>, %arg9: memref<?xf32>, %arg10: memref<?xf32>, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f32
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %c256 = arith.constant 256 : index
    %c32 = arith.constant 32 : index
    %c1 = arith.constant 1 : index
    %false = arith.constant false
    %cst_0 = arith.constant 1.000000e+00 : f32
    %cst_1 = arith.constant 1.000000e+06 : f32
    %true = arith.constant true
    %c16_i32 = arith.constant 16 : i32
    %c0_i32 = arith.constant 0 : i32
    %c4_i32 = arith.constant 4 : i32
    %c8_i32 = arith.constant 8 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1, 8, 32], strides: [%c256, %c32, %c1] : memref<?xbf16> to memref<1x8x32xbf16, strided<[256, 32, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1, 8], strides: [%c8, %c1] : memref<?xf32> to memref<1x8xf32, strided<[8, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [1, 8], strides: [%c8, %c1] : memref<?xf32> to memref<1x8xf32, strided<[8, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [1, 4], strides: [%c4, %c1] : memref<?xf32> to memref<1x4xf32, strided<[4, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [1, 8, 32], strides: [%c256, %c32, %c1] : memref<?xbf16> to memref<1x8x32xbf16, strided<[256, 32, 1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [16, 32], strides: [%c32, %c1] : memref<?xbf16> to memref<16x32xbf16, strided<[32, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1, 4], strides: [%c4, %c1] : memref<?xi32> to memref<1x4xi32, strided<[4, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [16, 32], strides: [%c32, %c1] : memref<?xf32> to memref<16x32xf32, strided<[32, 1]>>
    %0 = tensor.empty() : tensor<16x1xf32>
    %1 = tensor.empty() : tensor<4x16xf32>
    %2 = tensor.empty() : tensor<16x32xf32>
    %3 = tensor.empty() : tensor<16x32xbf16>
    %4 = tensor.empty() : tensor<16x1xf32>
    %5 = tensor.empty() : tensor<1x16xf32>
    %6 = hivm.hir.vbrc ins(%cst : f32) outs(%1 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %7 = hivm.hir.vbrc ins(%cst : f32) outs(%2 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %8 = hivm.hir.vbrc ins(%cst : f32) outs(%4 : tensor<16x1xf32>) -> tensor<16x1xf32>
    %subview = memref.subview %reinterpret_cast[0, 0, 0] [1, 16, 32] [1, 1, 1] : memref<1x8x32xbf16, strided<[256, 32, 1]>> to memref<16x32xbf16, strided<[32, 1]>>
    %alloc = memref.alloc() : memref<16x32xbf16>
    memref.copy %subview, %alloc : memref<16x32xbf16, strided<[32, 1]>> to memref<16x32xbf16>
    %9 = bufferization.to_tensor %alloc restrict : memref<16x32xbf16>
    %subview_9 = memref.subview %reinterpret_cast_2[0, 0] [1, 16] [1, 1] : memref<1x8xf32, strided<[8, 1]>> to memref<16xf32, strided<[1]>>
    %alloc_10 = memref.alloc() : memref<16xf32>
    memref.copy %subview_9, %alloc_10 : memref<16xf32, strided<[1]>> to memref<16xf32>
    %10 = bufferization.to_tensor %alloc_10 restrict : memref<16xf32>
    %11 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %0) -> (tensor<16x1xf32>)  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %10[%50] : tensor<16xf32>
      %inserted = tensor.insert %extracted into %arg18[%50, %c0] : tensor<16x1xf32>
      scf.yield %inserted : tensor<16x1xf32>
    }
    %12 = tensor.empty() : tensor<4x32xbf16>
    %13 = tensor.empty() : tensor<4xi32>
    %14 = tensor.empty() : tensor<4x1xf32>
    %15 = tensor.empty() : tensor<1x4xf32>
    %16 = tensor.empty() : tensor<4x16xf32>
    %17 = tensor.empty() : tensor<4x16xf32>
    %18 = tensor.empty() : tensor<4x16xf32>
    %19 = tensor.empty() : tensor<4x16xf32>
    %20 = tensor.empty() : tensor<4x16xf32>
    %21 = tensor.empty() : tensor<4x32xf32>
    %22 = tensor.empty() : tensor<4x16xf32>
    %23 = tensor.empty() : tensor<4x16xf32>
    %24 = tensor.empty() : tensor<4x16xf32>
    %25 = tensor.empty() : tensor<4x16xf32>
    %26 = tensor.empty() : tensor<4x16xbf16>
    %27 = tensor.empty() : tensor<1x4xi32>
    %subview_11 = memref.subview %reinterpret_cast_7[0, 0] [1, 4] [1, 1] : memref<1x4xi32, strided<[4, 1]>> to memref<4xi32, strided<[1]>>
    %alloc_12 = memref.alloc() : memref<4xi32>
    memref.copy %subview_11, %alloc_12 : memref<4xi32, strided<[1]>> to memref<4xi32>
    %28 = bufferization.to_tensor %alloc_12 restrict : memref<4xi32>
    %inserted_slice = tensor.insert_slice %28 into %27[0, 0] [1, 4] [1, 1] : tensor<4xi32> into tensor<1x4xi32>
    %29 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %13) -> (tensor<4xi32>)  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %inserted_slice[%c0, %50] : tensor<1x4xi32>
      %inserted = tensor.insert %extracted into %arg18[%50] : tensor<4xi32>
      scf.yield %inserted : tensor<4xi32>
    }
    %subview_13 = memref.subview %reinterpret_cast_4[0, 0] [1, 4] [1, 1] : memref<1x4xf32, strided<[4, 1]>> to memref<4xf32, strided<[1]>>
    %alloc_14 = memref.alloc() : memref<4xf32>
    memref.copy %subview_13, %alloc_14 : memref<4xf32, strided<[1]>> to memref<4xf32>
    %30 = bufferization.to_tensor %alloc_14 restrict : memref<4xf32>
    %inserted_slice_15 = tensor.insert_slice %30 into %15[0, 0] [1, 4] [1, 1] : tensor<4xf32> into tensor<1x4xf32>
    %31 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %14) -> (tensor<4x1xf32>)  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %inserted_slice_15[%c0, %50] : tensor<1x4xf32>
      %inserted = tensor.insert %extracted into %arg18[%50, %c0] : tensor<4x1xf32>
      scf.yield %inserted : tensor<4x1xf32>
    }
    %32 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %12) -> (tensor<4x32xbf16>)  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %29[%50] : tensor<4xi32>
      %51 = arith.index_cast %extracted : i32 to index
      %subview_18 = memref.subview %reinterpret_cast_6[%51, 0] [1, 32] [1, 1] : memref<16x32xbf16, strided<[32, 1]>> to memref<32xbf16, strided<[1], offset: ?>>
      %alloc_19 = memref.alloc() : memref<32xbf16>
      memref.copy %subview_18, %alloc_19 : memref<32xbf16, strided<[1], offset: ?>> to memref<32xbf16>
      %52 = bufferization.to_tensor %alloc_19 restrict : memref<32xbf16>
      %inserted_slice_20 = tensor.insert_slice %52 into %arg18[%50, 0] [1, 32] [1, 1] : tensor<32xbf16> into tensor<4x32xbf16>
      scf.yield %inserted_slice_20 : tensor<4x32xbf16>
    }
    %33 = hivm.hir.mmadL1 {b_transpose} ins(%32, %9, %true, %c4, %c16, %c32 : tensor<4x32xbf16>, tensor<16x32xbf16>, i1, index, index, index) outs(%16 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %34 = hivm.hir.vmax ins(%33, %6 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%17 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %35 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %24) -> (tensor<4x16xf32>)  : i32 {
      %50 = scf.for %arg19 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg20 = %arg18) -> (tensor<4x16xf32>)  : i32 {
        %51 = arith.index_cast %arg17 : i32 to index
        %extracted = tensor.extract %31[%51, %c0] : tensor<4x1xf32>
        %52 = arith.index_cast %arg19 : i32 to index
        %inserted = tensor.insert %extracted into %arg20[%51, %52] : tensor<4x16xf32>
        scf.yield %inserted : tensor<4x16xf32>
      }
      scf.yield %50 : tensor<4x16xf32>
    }
    %36 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %25) -> (tensor<4x16xf32>)  : i32 {
      %50 = scf.for %arg19 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg20 = %arg18) -> (tensor<4x16xf32>)  : i32 {
        %51 = arith.index_cast %arg19 : i32 to index
        %extracted = tensor.extract %11[%51, %c0] : tensor<16x1xf32>
        %52 = arith.index_cast %arg17 : i32 to index
        %inserted = tensor.insert %extracted into %arg20[%52, %51] : tensor<4x16xf32>
        scf.yield %inserted : tensor<4x16xf32>
      }
      scf.yield %50 : tensor<4x16xf32>
    }
    %37 = hivm.hir.vmul ins(%35, %34 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%22 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %38 = scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg18 = %8) -> (tensor<16x1xf32>)  : i32 {
      %50 = scf.for %arg19 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg20 = %arg18) -> (tensor<16x1xf32>)  : i32 {
        %51 = arith.index_cast %arg19 : i32 to index
        %extracted = tensor.extract %arg20[%51, %c0] : tensor<16x1xf32>
        %52 = arith.index_cast %arg17 : i32 to index
        %extracted_18 = tensor.extract %37[%52, %51] : tensor<4x16xf32>
        %53 = arith.addf %extracted, %extracted_18 : f32
        %inserted = tensor.insert %53 into %arg20[%51, %c0] : tensor<16x1xf32>
        scf.yield %inserted : tensor<16x1xf32>
      }
      scf.yield %50 : tensor<16x1xf32>
    }
    %39 = hivm.hir.vbrc ins(%cst_1 : f32) outs(%19 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %40 = hivm.hir.vmul ins(%34, %39 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%18 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %41 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%20 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %42 = hivm.hir.vmin ins(%40, %41 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%40 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %43 = hivm.hir.vmul ins(%35, %36 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%23 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %44 = hivm.hir.vmul ins(%43, %42 : tensor<4x16xf32>, tensor<4x16xf32>) outs(%43 : tensor<4x16xf32>) -> tensor<4x16xf32>
    %45 = hivm.hir.vcast ins(%44 : tensor<4x16xf32>) outs(%26 : tensor<4x16xbf16>) -> tensor<4x16xbf16>
    %46 = hivm.hir.mmadL1 {a_transpose} ins(%45, %32, %false, %c4, %c4, %c32 : tensor<4x16xbf16>, tensor<4x32xbf16>, i1, index, index, index) outs(%7 : tensor<16x32xf32>) -> tensor<16x32xf32>
    %47 = hivm.hir.mmadL1 ins(%45, %9, %true, %c4, %c16, %c32 : tensor<4x16xbf16>, tensor<16x32xbf16>, i1, index, index, index) outs(%21 : tensor<4x32xf32>) -> tensor<4x32xf32>
    scf.for %arg17 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %29[%50] : tensor<4xi32>
      scf.for %arg18 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
        %51 = arith.index_cast %arg17 : i32 to index
        %52 = arith.muli %arg18, %c4_i32 : i32
        %53 = arith.index_cast %52 : i32 to index
        %extracted_slice_18 = tensor.extract_slice %47[%51, %53] [1, 4] [1, 1] : tensor<4x32xf32> to tensor<1x4xf32>
        %54 = arith.index_cast %extracted : i32 to index
        %subview_19 = memref.subview %reinterpret_cast_8[%54, %53] [1, 4] [1, 1] : memref<16x32xf32, strided<[32, 1]>> to memref<1x4xf32, strided<[32, 1], offset: ?>>
        hivm.hir.store ins(%extracted_slice_18 : tensor<1x4xf32>) outs(%subview_19 : memref<1x4xf32, strided<[32, 1], offset: ?>>) atomic = <add>
      }
    }
    %48 = hivm.hir.vcast ins(%46 : tensor<16x32xf32>) outs(%3 : tensor<16x32xbf16>) -> tensor<16x32xbf16>
    %extracted_slice = tensor.extract_slice %48[0, 0] [8, 32] [1, 1] : tensor<16x32xbf16> to tensor<8x32xbf16>
    %subview_16 = memref.subview %reinterpret_cast_5[0, 0, 0] [1, 8, 32] [1, 1, 1] : memref<1x8x32xbf16, strided<[256, 32, 1]>> to memref<8x32xbf16, strided<[32, 1]>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_16 : (tensor<8x32xbf16>, memref<8x32xbf16, strided<[32, 1]>>) -> ()
    %49 = scf.for %arg17 = %c0_i32 to %c16_i32 step %c1_i32 iter_args(%arg18 = %5) -> (tensor<1x16xf32>)  : i32 {
      %50 = arith.index_cast %arg17 : i32 to index
      %extracted = tensor.extract %38[%50, %c0] : tensor<16x1xf32>
      %inserted = tensor.insert %extracted into %arg18[%c0, %50] : tensor<1x16xf32>
      scf.yield %inserted : tensor<1x16xf32>
    }
    %extracted_slice_17 = tensor.extract_slice %49[0, 0] [1, 8] [1, 1] : tensor<1x16xf32> to tensor<1x8xf32>
    bufferization.materialize_in_destination %extracted_slice_17 in writable %reinterpret_cast_3 : (tensor<1x8xf32>, memref<1x8xf32, strided<[8, 1]>>) -> ()
    return
  }
}