module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %c128_i32 = arith.constant 128 : i32
    %c4_i32 = arith.constant 4 : i32
    %c16_i32 = arith.constant 16 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [512, 512], strides: [%c512, %c1] : memref<?xf16> to memref<512x512xf16, strided<[512, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [512, 512], strides: [%c512, %c1] : memref<?xf16> to memref<512x512xf16, strided<[512, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [512, 512], strides: [%c512, %c1] : memref<?xf16> to memref<512x512xf16, strided<[512, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<128x128xf16>
    %3 = arith.cmpi slt, %1, %c16_i32 : i32
    scf.if %3 {
      %4 = arith.divsi %1, %c4_i32 : i32
      %5 = arith.muli %4, %c128_i32 : i32
      %6 = arith.index_cast %5 : i32 to index
      %7 = arith.remsi %1, %c4_i32 : i32
      %8 = arith.muli %7, %c128_i32 : i32
      %9 = arith.index_cast %8 : i32 to index
      %subview = memref.subview %reinterpret_cast[%6, %9] [128, 128] [1, 1] : memref<512x512xf16, strided<[512, 1]>> to memref<128x128xf16, strided<[512, 1], offset: ?>>
      %alloc = memref.alloc() : memref<128x128xf16>
      memref.copy %subview, %alloc : memref<128x128xf16, strided<[512, 1], offset: ?>> to memref<128x128xf16>
      %10 = bufferization.to_tensor %alloc restrict : memref<128x128xf16>
      %subview_2 = memref.subview %reinterpret_cast_1[%6, %9] [128, 128] [1, 1] : memref<512x512xf16, strided<[512, 1]>> to memref<128x128xf16, strided<[512, 1], offset: ?>>
      %alloc_3 = memref.alloc() : memref<128x128xf16>
      memref.copy %subview_2, %alloc_3 : memref<128x128xf16, strided<[512, 1], offset: ?>> to memref<128x128xf16>
      %11 = bufferization.to_tensor %alloc_3 restrict : memref<128x128xf16>
      %12 = hivm.hir.vadd ins(%10, %11 : tensor<128x128xf16>, tensor<128x128xf16>) outs(%2 : tensor<128x128xf16>) -> tensor<128x128xf16>
      %subview_4 = memref.subview %reinterpret_cast_0[%6, %9] [128, 128] [1, 1] : memref<512x512xf16, strided<[512, 1]>> to memref<128x128xf16, strided<[512, 1], offset: ?>>
      bufferization.materialize_in_destination %12 in writable %subview_4 : (tensor<128x128xf16>, memref<128x128xf16, strided<[512, 1], offset: ?>>) -> ()
    }
    return
  }
}