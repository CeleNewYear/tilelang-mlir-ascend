module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c64 = arith.constant 64 : index
    %c1024 = arith.constant 1024 : index
    %c128 = arith.constant 128 : index
    %c1 = arith.constant 1 : index
    %c4_i32 = arith.constant 4 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [128, 8, 128], strides: [%c1024, %c128, %c1] : memref<?xf16> to memref<128x8x128xf16, strided<[1024, 128, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [128, 64], strides: [%c64, %c1] : memref<?xf16> to memref<128x64xf16, strided<[64, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [128, 64], strides: [%c64, %c1] : memref<?xf16> to memref<128x64xf16, strided<[64, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [128, 8, 128], strides: [%c1024, %c128, %c1] : memref<?xf16> to memref<128x8x128xf16, strided<[1024, 128, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<4x8x64xf16>
    %3 = tensor.empty() : tensor<4x8x64xf16>
    %4 = tensor.empty() : tensor<4x8x128xf16>
    %5 = tensor.empty() : tensor<4x1x64xf16>
    %6 = tensor.empty() : tensor<4x1x64xf16>
    %7 = tensor.empty() : tensor<4x8x64xf32>
    %8 = tensor.empty() : tensor<4x8x64xf32>
    %9 = tensor.empty() : tensor<4x1x64xf32>
    %10 = tensor.empty() : tensor<4x1x64xf32>
    %11 = tensor.empty() : tensor<4x8x64xf32>
    %12 = tensor.empty() : tensor<4x8x64xf32>
    %13 = arith.muli %1, %c4_i32 : i32
    %14 = arith.index_cast %13 : i32 to index
    %subview = memref.subview %reinterpret_cast_1[%14, 0] [4, 64] [1, 1] : memref<128x64xf16, strided<[64, 1]>> to memref<4x64xf16, strided<[64, 1], offset: ?>>
    %alloc = memref.alloc() : memref<4x64xf16>
    memref.copy %subview, %alloc : memref<4x64xf16, strided<[64, 1], offset: ?>> to memref<4x64xf16>
    %15 = bufferization.to_tensor %alloc restrict : memref<4x64xf16>
    %inserted_slice = tensor.insert_slice %15 into %5[0, 0, 0] [4, 1, 64] [1, 1, 1] : tensor<4x64xf16> into tensor<4x1x64xf16>
    %16 = hivm.hir.vcast ins(%inserted_slice : tensor<4x1x64xf16>) outs(%9 : tensor<4x1x64xf32>) round_mode = <round> -> tensor<4x1x64xf32>
    %subview_3 = memref.subview %reinterpret_cast[%14, 0, 0] [4, 8, 64] [1, 1, 1] : memref<128x8x128xf16, strided<[1024, 128, 1]>> to memref<4x8x64xf16, strided<[1024, 128, 1], offset: ?>>
    %alloc_4 = memref.alloc() : memref<4x8x64xf16>
    memref.copy %subview_3, %alloc_4 : memref<4x8x64xf16, strided<[1024, 128, 1], offset: ?>> to memref<4x8x64xf16>
    %17 = bufferization.to_tensor %alloc_4 restrict : memref<4x8x64xf16>
    %18 = hivm.hir.vcast ins(%17 : tensor<4x8x64xf16>) outs(%7 : tensor<4x8x64xf32>) round_mode = <round> -> tensor<4x8x64xf32>
    %19 = hivm.hir.vmul ins(%18, %16 : tensor<4x8x64xf32>, tensor<4x1x64xf32>) outs(%11 : tensor<4x8x64xf32>) broadcast = [1] -> tensor<4x8x64xf32>
    %subview_5 = memref.subview %reinterpret_cast[%14, 0, 64] [4, 8, 64] [1, 1, 1] : memref<128x8x128xf16, strided<[1024, 128, 1]>> to memref<4x8x64xf16, strided<[1024, 128, 1], offset: ?>>
    %alloc_6 = memref.alloc() : memref<4x8x64xf16>
    memref.copy %subview_5, %alloc_6 : memref<4x8x64xf16, strided<[1024, 128, 1], offset: ?>> to memref<4x8x64xf16>
    %20 = bufferization.to_tensor %alloc_6 restrict : memref<4x8x64xf16>
    %21 = hivm.hir.vcast ins(%20 : tensor<4x8x64xf16>) outs(%8 : tensor<4x8x64xf32>) round_mode = <round> -> tensor<4x8x64xf32>
    %subview_7 = memref.subview %reinterpret_cast_0[%14, 0] [4, 64] [1, 1] : memref<128x64xf16, strided<[64, 1]>> to memref<4x64xf16, strided<[64, 1], offset: ?>>
    %alloc_8 = memref.alloc() : memref<4x64xf16>
    memref.copy %subview_7, %alloc_8 : memref<4x64xf16, strided<[64, 1], offset: ?>> to memref<4x64xf16>
    %22 = bufferization.to_tensor %alloc_8 restrict : memref<4x64xf16>
    %inserted_slice_9 = tensor.insert_slice %22 into %6[0, 0, 0] [4, 1, 64] [1, 1, 1] : tensor<4x64xf16> into tensor<4x1x64xf16>
    %23 = hivm.hir.vcast ins(%inserted_slice_9 : tensor<4x1x64xf16>) outs(%10 : tensor<4x1x64xf32>) round_mode = <round> -> tensor<4x1x64xf32>
    %24 = hivm.hir.vmul ins(%21, %23 : tensor<4x8x64xf32>, tensor<4x1x64xf32>) outs(%12 : tensor<4x8x64xf32>) broadcast = [1] -> tensor<4x8x64xf32>
    %25 = hivm.hir.vsub ins(%19, %24 : tensor<4x8x64xf32>, tensor<4x8x64xf32>) outs(%19 : tensor<4x8x64xf32>) -> tensor<4x8x64xf32>
    %26 = hivm.hir.vcast ins(%25 : tensor<4x8x64xf32>) outs(%2 : tensor<4x8x64xf16>) -> tensor<4x8x64xf16>
    %inserted_slice_10 = tensor.insert_slice %26 into %4[0, 0, 0] [4, 8, 64] [1, 1, 1] : tensor<4x8x64xf16> into tensor<4x8x128xf16>
    %27 = hivm.hir.vmul ins(%18, %23 : tensor<4x8x64xf32>, tensor<4x1x64xf32>) outs(%24 : tensor<4x8x64xf32>) broadcast = [1] -> tensor<4x8x64xf32>
    %28 = hivm.hir.vmul ins(%21, %16 : tensor<4x8x64xf32>, tensor<4x1x64xf32>) outs(%21 : tensor<4x8x64xf32>) broadcast = [1] -> tensor<4x8x64xf32>
    %29 = hivm.hir.vadd ins(%28, %27 : tensor<4x8x64xf32>, tensor<4x8x64xf32>) outs(%28 : tensor<4x8x64xf32>) -> tensor<4x8x64xf32>
    %30 = hivm.hir.vcast ins(%29 : tensor<4x8x64xf32>) outs(%3 : tensor<4x8x64xf16>) -> tensor<4x8x64xf16>
    %inserted_slice_11 = tensor.insert_slice %30 into %inserted_slice_10[0, 0, 64] [4, 8, 64] [1, 1, 1] : tensor<4x8x64xf16> into tensor<4x8x128xf16>
    %subview_12 = memref.subview %reinterpret_cast_2[%14, 0, 0] [4, 8, 128] [1, 1, 1] : memref<128x8x128xf16, strided<[1024, 128, 1]>> to memref<4x8x128xf16, strided<[1024, 128, 1], offset: ?>>
    bufferization.materialize_in_destination %inserted_slice_11 in writable %subview_12 : (tensor<4x8x128xf16>, memref<4x8x128xf16, strided<[1024, 128, 1], offset: ?>>) -> ()
    return
  }
}