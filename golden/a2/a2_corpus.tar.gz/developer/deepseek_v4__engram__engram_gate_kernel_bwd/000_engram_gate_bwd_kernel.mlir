module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @engram_gate_bwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xbf16>, %arg7: memref<?xf32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xf32>, %arg11: memref<?xf32>, %arg12: memref<?xbf16>, %arg13: memref<?xbf16>, %arg14: memref<?xbf16>, %arg15: memref<?xf32>, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32, %arg21: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c16384 = arith.constant 16384 : index
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %c128_i32 = arith.constant 128 : i32
    %c3_i32 = arith.constant 3 : i32
    %cst = arith.constant 2.44140625E-4 : f32
    %cst_0 = arith.constant 5.000000e-01 : f32
    %cst_1 = arith.constant 1.000000e+00 : f32
    %cst_2 = arith.constant 9.99999997E-7 : f32
    %cst_3 = arith.constant 1.562500e-02 : f32
    %cst_4 = arith.constant 1.000000e-30 : f32
    %cst_5 = arith.constant -1.000000e+00 : f32
    %cst_6 = arith.constant 0.000000e+00 : f32
    %c1024_i32 = arith.constant 1024 : i32
    %c2048_i32 = arith.constant 2048 : i32
    %c256_i32 = arith.constant 256 : i32
    %c512_i32 = arith.constant 512 : i32
    %c8_i32 = arith.constant 8 : i32
    %c32_i32 = arith.constant 32 : i32
    %c2_i32 = arith.constant 2 : i32
    %c0_i32 = arith.constant 0 : i32
    %c4_i32 = arith.constant 4 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [16, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xbf16> to memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [16, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xbf16> to memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [16, 4], strides: [%c4, %c1] : memref<?xf32> to memref<16x4xf32, strided<[4, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [4, 4096], strides: [%c4096, %c1] : memref<?xf32> to memref<4x4096xf32, strided<[4096, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg14 to offset: [0], sizes: [16, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<16x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg15 to offset: [0], sizes: [4, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xf32> to memref<4x4x4096xf32, strided<[16384, 4096, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [16, 4], strides: [%c4, %c1] : memref<?xf32> to memref<16x4xf32, strided<[4, 1]>>
    %reinterpret_cast_13 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [16, 4], strides: [%c4, %c1] : memref<?xf32> to memref<16x4xf32, strided<[4, 1]>>
    %reinterpret_cast_14 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [16, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xbf16> to memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
    %reinterpret_cast_15 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [16, 4096], strides: [%c4096, %c1] : memref<?xbf16> to memref<16x4096xbf16, strided<[4096, 1]>>
    %reinterpret_cast_16 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [16, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xbf16> to memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
    %reinterpret_cast_17 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [16, 4], strides: [%c4, %c1] : memref<?xf32> to memref<16x4xf32, strided<[4, 1]>>
    %reinterpret_cast_18 = memref.reinterpret_cast %arg13 to offset: [0], sizes: [16, 4, 4096], strides: [%c16384, %c4096, %c1] : memref<?xbf16> to memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<4xf32>
    %3 = tensor.empty() : tensor<4xf32>
    %4 = tensor.empty() : tensor<2x4x1024xbf16>
    %5 = tensor.empty() : tensor<2x4x1024xbf16>
    %6 = tensor.empty() : tensor<4x4xf32>
    %7:5 = scf.for %arg22 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg23 = %6, %arg24 = %4, %arg25 = %5, %arg26 = %2, %arg27 = %3) -> (tensor<4x4xf32>, tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>)  : i32 {
      %9 = tensor.empty() : tensor<4x4096xbf16>
      %10 = tensor.empty() : tensor<4x2xf32>
      %11 = arith.muli %1, %c4_i32 : i32
      %12 = arith.addi %11, %arg22 : i32
      %13 = arith.index_cast %12 : i32 to index
      %subview = memref.subview %reinterpret_cast_15[%13, 0] [1, 4096] [1, 1] : memref<16x4096xbf16, strided<[4096, 1]>> to memref<4096xbf16, strided<[1], offset: ?>>
      %alloc = memref.alloc() : memref<4096xbf16>
      memref.copy %subview, %alloc : memref<4096xbf16, strided<[1], offset: ?>> to memref<4096xbf16>
      %14 = bufferization.to_tensor %alloc restrict : memref<4096xbf16>
      %subview_19 = memref.subview %reinterpret_cast[%13, 0, 0] [1, 4, 2048] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x2048xbf16, strided<[4096, 1], offset: ?>>
      %alloc_20 = memref.alloc() : memref<4x2048xbf16>
      memref.copy %subview_19, %alloc_20 : memref<4x2048xbf16, strided<[4096, 1], offset: ?>> to memref<4x2048xbf16>
      %15 = bufferization.to_tensor %alloc_20 restrict : memref<4x2048xbf16>
      %inserted_slice = tensor.insert_slice %15 into %9[0, 0] [4, 2048] [1, 1] : tensor<4x2048xbf16> into tensor<4x4096xbf16>
      %subview_21 = memref.subview %reinterpret_cast_8[%13, 0] [1, 4] [1, 1] : memref<16x4xf32, strided<[4, 1]>> to memref<4xf32, strided<[1], offset: ?>>
      %alloc_22 = memref.alloc() : memref<4xf32>
      memref.copy %subview_21, %alloc_22 : memref<4xf32, strided<[1], offset: ?>> to memref<4xf32>
      %16 = bufferization.to_tensor %alloc_22 restrict : memref<4xf32>
      %17:2 = scf.for %arg28 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg29 = %inserted_slice, %arg30 = %10) -> (tensor<4x4096xbf16>, tensor<4x2xf32>)  : i32 {
        %19:2 = scf.for %arg31 = %c0_i32 to %c2_i32 step %c1_i32 iter_args(%arg32 = %arg29, %arg33 = %arg30) -> (tensor<4x4096xbf16>, tensor<4x2xf32>)  : i32 {
          %20 = tensor.empty() : tensor<8xf32>
          %21 = tensor.empty() : tensor<8xf32>
          %22 = tensor.empty() : tensor<1xf32>
          %23 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%22 : tensor<1xf32>) -> tensor<1xf32>
          %24 = arith.muli %1, %c4_i32 : i32
          %25 = arith.addi %24, %arg22 : i32
          %26 = arith.index_cast %25 : i32 to index
          %subview_23 = memref.subview %reinterpret_cast[%26, 0, 2048] [1, 4, 2048] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x2048xbf16, strided<[4096, 1], offset: ?>>
          %alloc_24 = memref.alloc() : memref<4x2048xbf16>
          memref.copy %subview_23, %alloc_24 : memref<4x2048xbf16, strided<[4096, 1], offset: ?>> to memref<4x2048xbf16>
          %27 = bufferization.to_tensor %alloc_24 restrict : memref<4x2048xbf16>
          %inserted_slice_25 = tensor.insert_slice %27 into %arg32[0, 2048] [4, 2048] [1, 1] : tensor<4x2048xbf16> into tensor<4x4096xbf16>
          %28:3 = scf.for %arg34 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg35 = %20, %arg36 = %21, %arg37 = %23) -> (tensor<8xf32>, tensor<8xf32>, tensor<1xf32>)  : i32 {
            %32:3 = scf.for %arg38 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg39 = %arg35, %arg40 = %arg36, %arg41 = %arg37) -> (tensor<8xf32>, tensor<8xf32>, tensor<1xf32>)  : i32 {
              %33 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg39) -> (tensor<8xf32>)  : i32 {
                %36 = arith.index_cast %arg28 : i32 to index
                %37 = arith.muli %arg34, %c512_i32 : i32
                %38 = arith.muli %arg31, %c256_i32 : i32
                %39 = arith.addi %37, %38 : i32
                %40 = arith.muli %arg38, %c8_i32 : i32
                %41 = arith.addi %39, %40 : i32
                %42 = arith.addi %41, %arg42 : i32
                %43 = arith.index_cast %42 : i32 to index
                %extracted_26 = tensor.extract %inserted_slice_25[%36, %43] : tensor<4x4096xbf16>
                %44 = arith.extf %extracted_26 : bf16 to f32
                %45 = arith.index_cast %arg42 : i32 to index
                %inserted_27 = tensor.insert %44 into %arg43[%45] : tensor<8xf32>
                scf.yield %inserted_27 : tensor<8xf32>
              }
              %34 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg40) -> (tensor<8xf32>)  : i32 {
                %36 = arith.muli %arg34, %c512_i32 : i32
                %37 = arith.muli %arg31, %c256_i32 : i32
                %38 = arith.addi %36, %37 : i32
                %39 = arith.muli %arg38, %c8_i32 : i32
                %40 = arith.addi %38, %39 : i32
                %41 = arith.addi %40, %arg42 : i32
                %42 = arith.index_cast %41 : i32 to index
                %extracted_26 = tensor.extract %14[%42] : tensor<4096xbf16>
                %43 = arith.extf %extracted_26 : bf16 to f32
                %44 = arith.index_cast %arg42 : i32 to index
                %inserted_27 = tensor.insert %43 into %arg43[%44] : tensor<8xf32>
                scf.yield %inserted_27 : tensor<8xf32>
              }
              %35 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg41) -> (tensor<1xf32>)  : i32 {
                %extracted_26 = tensor.extract %arg43[%c0] : tensor<1xf32>
                %36 = arith.index_cast %arg42 : i32 to index
                %extracted_27 = tensor.extract %33[%36] : tensor<8xf32>
                %extracted_28 = tensor.extract %34[%36] : tensor<8xf32>
                %37 = arith.mulf %extracted_27, %extracted_28 : f32
                %38 = arith.addf %extracted_26, %37 : f32
                %inserted_29 = tensor.insert %38 into %arg43[%c0] : tensor<1xf32>
                scf.yield %inserted_29 : tensor<1xf32>
              }
              scf.yield %33, %34, %35 : tensor<8xf32>, tensor<8xf32>, tensor<1xf32>
            }
            scf.yield %32#0, %32#1, %32#2 : tensor<8xf32>, tensor<8xf32>, tensor<1xf32>
          }
          %29:3 = scf.for %arg34 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg35 = %28#0, %arg36 = %28#1, %arg37 = %28#2) -> (tensor<8xf32>, tensor<8xf32>, tensor<1xf32>)  : i32 {
            %32:3 = scf.for %arg38 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg39 = %arg35, %arg40 = %arg36, %arg41 = %arg37) -> (tensor<8xf32>, tensor<8xf32>, tensor<1xf32>)  : i32 {
              %33 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg39) -> (tensor<8xf32>)  : i32 {
                %36 = arith.index_cast %arg28 : i32 to index
                %37 = arith.muli %arg34, %c512_i32 : i32
                %38 = arith.muli %arg31, %c256_i32 : i32
                %39 = arith.addi %37, %38 : i32
                %40 = arith.muli %arg38, %c8_i32 : i32
                %41 = arith.addi %39, %40 : i32
                %42 = arith.addi %41, %arg42 : i32
                %43 = arith.addi %42, %c2048_i32 : i32
                %44 = arith.index_cast %43 : i32 to index
                %extracted_26 = tensor.extract %inserted_slice_25[%36, %44] : tensor<4x4096xbf16>
                %45 = arith.extf %extracted_26 : bf16 to f32
                %46 = arith.index_cast %arg42 : i32 to index
                %inserted_27 = tensor.insert %45 into %arg43[%46] : tensor<8xf32>
                scf.yield %inserted_27 : tensor<8xf32>
              }
              %34 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg40) -> (tensor<8xf32>)  : i32 {
                %36 = arith.muli %arg34, %c512_i32 : i32
                %37 = arith.muli %arg31, %c256_i32 : i32
                %38 = arith.addi %36, %37 : i32
                %39 = arith.muli %arg38, %c8_i32 : i32
                %40 = arith.addi %38, %39 : i32
                %41 = arith.addi %40, %arg42 : i32
                %42 = arith.addi %41, %c2048_i32 : i32
                %43 = arith.index_cast %42 : i32 to index
                %extracted_26 = tensor.extract %14[%43] : tensor<4096xbf16>
                %44 = arith.extf %extracted_26 : bf16 to f32
                %45 = arith.index_cast %arg42 : i32 to index
                %inserted_27 = tensor.insert %44 into %arg43[%45] : tensor<8xf32>
                scf.yield %inserted_27 : tensor<8xf32>
              }
              %35 = scf.for %arg42 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg43 = %arg41) -> (tensor<1xf32>)  : i32 {
                %extracted_26 = tensor.extract %arg43[%c0] : tensor<1xf32>
                %36 = arith.index_cast %arg42 : i32 to index
                %extracted_27 = tensor.extract %33[%36] : tensor<8xf32>
                %extracted_28 = tensor.extract %34[%36] : tensor<8xf32>
                %37 = arith.mulf %extracted_27, %extracted_28 : f32
                %38 = arith.addf %extracted_26, %37 : f32
                %inserted_29 = tensor.insert %38 into %arg43[%c0] : tensor<1xf32>
                scf.yield %inserted_29 : tensor<1xf32>
              }
              scf.yield %33, %34, %35 : tensor<8xf32>, tensor<8xf32>, tensor<1xf32>
            }
            scf.yield %32#0, %32#1, %32#2 : tensor<8xf32>, tensor<8xf32>, tensor<1xf32>
          }
          %extracted = tensor.extract %29#2[%c0] : tensor<1xf32>
          %30 = arith.index_cast %arg28 : i32 to index
          %31 = arith.index_cast %arg31 : i32 to index
          %inserted = tensor.insert %extracted into %arg33[%30, %31] : tensor<4x2xf32>
          scf.yield %inserted_slice_25, %inserted : tensor<4x4096xbf16>, tensor<4x2xf32>
        }
        scf.yield %19#0, %19#1 : tensor<4x4096xbf16>, tensor<4x2xf32>
      }
      scf.for %arg28 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
        scf.for %arg29 = %c0_i32 to %c256_i32 step %c1_i32  : i32 {
          %19 = tensor.empty() : tensor<4xf32>
          %20 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%19 : tensor<4xf32>) -> tensor<4xf32>
          %21 = scf.for %arg30 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg31 = %20) -> (tensor<4xf32>)  : i32 {
            %22 = tensor.empty() : tensor<4xf32>
            %23 = tensor.empty() : tensor<4xf32>
            %24 = tensor.empty() : tensor<4xf32>
            %25 = scf.for %arg32 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg33 = %22) -> (tensor<4xf32>)  : i32 {
              %30 = arith.index_cast %arg30 : i32 to index
              %31 = arith.muli %arg28, %c1024_i32 : i32
              %32 = arith.muli %arg29, %c4_i32 : i32
              %33 = arith.addi %31, %32 : i32
              %34 = arith.addi %33, %arg32 : i32
              %35 = arith.index_cast %34 : i32 to index
              %extracted_23 = tensor.extract %17#0[%30, %35] : tensor<4x4096xbf16>
              %36 = arith.extf %extracted_23 : bf16 to f32
              %37 = arith.index_cast %arg32 : i32 to index
              %inserted = tensor.insert %36 into %arg33[%37] : tensor<4xf32>
              scf.yield %inserted : tensor<4xf32>
            }
            %26 = arith.index_cast %arg30 : i32 to index
            %extracted = tensor.extract %16[%26] : tensor<4xf32>
            %27 = hivm.hir.vbrc ins(%extracted : f32) outs(%23 : tensor<4xf32>) -> tensor<4xf32>
            %28 = hivm.hir.vmul ins(%25, %27 : tensor<4xf32>, tensor<4xf32>) outs(%24 : tensor<4xf32>) -> tensor<4xf32>
            %29 = hivm.hir.vadd ins(%arg31, %28 : tensor<4xf32>, tensor<4xf32>) outs(%arg31 : tensor<4xf32>) -> tensor<4xf32>
            scf.yield %29 : tensor<4xf32>
          }
          scf.for %arg30 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
            %22 = arith.index_cast %arg30 : i32 to index
            %extracted = tensor.extract %21[%22] : tensor<4xf32>
            %23 = arith.truncf %extracted : f32 to bf16
            %24 = arith.muli %1, %c4_i32 : i32
            %25 = arith.addi %24, %arg22 : i32
            %26 = arith.index_cast %25 : i32 to index
            %27 = arith.muli %arg28, %c1024_i32 : i32
            %28 = arith.muli %arg29, %c4_i32 : i32
            %29 = arith.addi %27, %28 : i32
            %30 = arith.addi %29, %arg30 : i32
            %31 = arith.index_cast %30 : i32 to index
            memref.store %23, %reinterpret_cast_10[%26, %31] : memref<16x4096xbf16, strided<[4096, 1]>>
          }
        }
      }
      %18:5 = scf.for %arg28 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg29 = %arg23, %arg30 = %arg24, %arg31 = %arg25, %arg32 = %arg26, %arg33 = %arg27) -> (tensor<4x4xf32>, tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>)  : i32 {
        %19 = tensor.empty() : tensor<1xf32>
        %20 = tensor.empty() : tensor<1xf32>
        %21 = tensor.empty() : tensor<1xf32>
        %22 = tensor.empty() : tensor<1xf32>
        %23 = tensor.empty() : tensor<1xf32>
        %24 = tensor.empty() : tensor<1xf32>
        %25 = tensor.empty() : tensor<1xf32>
        %26 = tensor.empty() : tensor<1xf32>
        %27 = tensor.empty() : tensor<8xf32>
        %28 = tensor.empty() : tensor<8xf32>
        %29 = tensor.empty() : tensor<2x4x1024xf32>
        %30 = arith.muli %1, %c4_i32 : i32
        %31 = arith.addi %30, %arg22 : i32
        %32 = arith.index_cast %31 : i32 to index
        %33 = arith.index_cast %arg28 : i32 to index
        %34 = memref.load %reinterpret_cast_8[%32, %33] : memref<16x4xf32, strided<[4, 1]>>
        %inserted = tensor.insert %34 into %20[%c0] : tensor<1xf32>
        %35 = memref.load %reinterpret_cast_17[%32, %33] : memref<16x4xf32, strided<[4, 1]>>
        %inserted_23 = tensor.insert %35 into %21[%c0] : tensor<1xf32>
        %36 = memref.load %reinterpret_cast_12[%32, %33] : memref<16x4xf32, strided<[4, 1]>>
        %inserted_24 = tensor.insert %36 into %22[%c0] : tensor<1xf32>
        %37 = memref.load %reinterpret_cast_13[%32, %33] : memref<16x4xf32, strided<[4, 1]>>
        %inserted_25 = tensor.insert %37 into %23[%c0] : tensor<1xf32>
        %extracted = tensor.extract %inserted_25[%c0] : tensor<1xf32>
        %38 = arith.cmpf olt, %extracted, %cst_6 : f32
        %39 = scf.if %38 -> (tensor<1xf32>) {
          %extracted_50 = tensor.extract %inserted_25[%c0] : tensor<1xf32>
          %61 = arith.mulf %extracted_50, %cst_5 : f32
          %inserted_51 = tensor.insert %61 into %26[%c0] : tensor<1xf32>
          scf.yield %inserted_51 : tensor<1xf32>
        } else {
          %extracted_50 = tensor.extract %inserted_25[%c0] : tensor<1xf32>
          %inserted_51 = tensor.insert %extracted_50 into %26[%c0] : tensor<1xf32>
          scf.yield %inserted_51 : tensor<1xf32>
        }
        %40 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%27 : tensor<8xf32>) -> tensor<8xf32>
        %41 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%28 : tensor<8xf32>) -> tensor<8xf32>
        %extracted_26 = tensor.extract %39[%c0] : tensor<1xf32>
        %42 = arith.cmpf olt, %extracted_26, %cst_4 : f32
        %43 = scf.if %42 -> (tensor<8xf32>) {
          %inserted_50 = tensor.insert %cst_6 into %40[%c0] : tensor<8xf32>
          scf.yield %inserted_50 : tensor<8xf32>
        } else {
          %extracted_50 = tensor.extract %inserted_23[%c0] : tensor<1xf32>
          %61 = arith.mulf %extracted_50, %cst_3 : f32
          %extracted_51 = tensor.extract %inserted_24[%c0] : tensor<1xf32>
          %62 = arith.mulf %61, %extracted_51 : f32
          %extracted_52 = tensor.extract %39[%c0] : tensor<1xf32>
          %63 = arith.divf %62, %extracted_52 : f32
          %inserted_53 = tensor.insert %63 into %40[%c0] : tensor<8xf32>
          scf.yield %inserted_53 : tensor<8xf32>
        }
        %44 = hivm.hir.vsqrt ins(%43 : tensor<8xf32>) outs(%41 : tensor<8xf32>) -> tensor<8xf32>
        %inserted_27 = tensor.insert %cst_6 into %19[%c0] : tensor<1xf32>
        %extracted_28 = tensor.extract %39[%c0] : tensor<1xf32>
        %45 = arith.mulf %extracted_28, %cst_3 : f32
        %extracted_29 = tensor.extract %inserted_23[%c0] : tensor<1xf32>
        %46 = arith.mulf %45, %extracted_29 : f32
        %extracted_30 = tensor.extract %inserted_24[%c0] : tensor<1xf32>
        %47 = arith.mulf %46, %extracted_30 : f32
        %48 = arith.cmpf ole, %cst_2, %47 : f32
        %49 = scf.if %48 -> (tensor<1xf32>) {
          %61 = arith.index_cast %arg28 : i32 to index
          %extracted_50 = tensor.extract %17#1[%61, %c0] : tensor<4x2xf32>
          %extracted_51 = tensor.extract %17#1[%61, %c1] : tensor<4x2xf32>
          %62 = arith.addf %extracted_50, %extracted_51 : f32
          %extracted_52 = tensor.extract %inserted[%c0] : tensor<1xf32>
          %63 = arith.mulf %62, %extracted_52 : f32
          %extracted_53 = tensor.extract %inserted[%c0] : tensor<1xf32>
          %64 = arith.subf %cst_1, %extracted_53 : f32
          %65 = arith.mulf %63, %64 : f32
          %66 = arith.mulf %65, %cst_0 : f32
          %extracted_54 = tensor.extract %44[%c0] : tensor<8xf32>
          %67 = arith.mulf %66, %extracted_54 : f32
          %inserted_55 = tensor.insert %67 into %inserted_27[%c0] : tensor<1xf32>
          scf.yield %inserted_55 : tensor<1xf32>
        } else {
          scf.yield %inserted_27 : tensor<1xf32>
        }
        %extracted_31 = tensor.extract %49[%c0] : tensor<1xf32>
        %50 = arith.index_cast %arg22 : i32 to index
        %inserted_32 = tensor.insert %extracted_31 into %arg29[%50, %33] : tensor<4x4xf32>
        %extracted_33 = tensor.extract %inserted_25[%c0] : tensor<1xf32>
        %extracted_34 = tensor.extract %inserted_23[%c0] : tensor<1xf32>
        %51 = arith.mulf %extracted_33, %extracted_34 : f32
        %extracted_35 = tensor.extract %inserted_23[%c0] : tensor<1xf32>
        %52 = arith.mulf %51, %extracted_35 : f32
        %53 = arith.mulf %52, %cst : f32
        %inserted_36 = tensor.insert %53 into %24[%c0] : tensor<1xf32>
        %extracted_37 = tensor.extract %inserted_25[%c0] : tensor<1xf32>
        %extracted_38 = tensor.extract %inserted_24[%c0] : tensor<1xf32>
        %54 = arith.mulf %extracted_37, %extracted_38 : f32
        %extracted_39 = tensor.extract %inserted_24[%c0] : tensor<1xf32>
        %55 = arith.mulf %54, %extracted_39 : f32
        %56 = arith.mulf %55, %cst : f32
        %inserted_40 = tensor.insert %56 into %25[%c0] : tensor<1xf32>
        %subview_41 = memref.subview %reinterpret_cast_14[%32, 0, 0] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
        %alloc_42 = memref.alloc() : memref<4x1024xbf16>
        memref.copy %subview_41, %alloc_42 : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
        %57 = bufferization.to_tensor %alloc_42 restrict : memref<4x1024xbf16>
        %inserted_slice_43 = tensor.insert_slice %57 into %arg30[0, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
        %subview_44 = memref.subview %reinterpret_cast_7[%32, 0, 0] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
        %alloc_45 = memref.alloc() : memref<4x1024xbf16>
        memref.copy %subview_44, %alloc_45 : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
        %58 = bufferization.to_tensor %alloc_45 restrict : memref<4x1024xbf16>
        %inserted_slice_46 = tensor.insert_slice %58 into %arg31[0, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
        %subview_47 = memref.subview %reinterpret_cast_9[0, 0] [4, 1024] [1, 1] : memref<4x4096xf32, strided<[4096, 1]>> to memref<4x1024xf32, strided<[4096, 1]>>
        %alloc_48 = memref.alloc() : memref<4x1024xf32>
        memref.copy %subview_47, %alloc_48 : memref<4x1024xf32, strided<[4096, 1]>> to memref<4x1024xf32>
        %59 = bufferization.to_tensor %alloc_48 restrict : memref<4x1024xf32>
        %inserted_slice_49 = tensor.insert_slice %59 into %29[0, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xf32> into tensor<2x4x1024xf32>
        %60:5 = scf.for %arg34 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg35 = %inserted_slice_43, %arg36 = %inserted_slice_46, %arg37 = %inserted_slice_49, %arg38 = %arg32, %arg39 = %arg33) -> (tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<2x4x1024xf32>, tensor<4xf32>, tensor<4xf32>)  : i32 {
          %61 = arith.cmpi slt, %arg34, %c3_i32 : i32
          %62:3 = scf.if %61 -> (tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<2x4x1024xf32>) {
            %64 = arith.muli %1, %c4_i32 : i32
            %65 = arith.addi %64, %arg22 : i32
            %66 = arith.index_cast %65 : i32 to index
            %67 = arith.muli %arg34, %c1024_i32 : i32
            %68 = arith.addi %67, %c1024_i32 : i32
            %69 = arith.index_cast %68 : i32 to index
            %70 = arith.addi %arg34, %c1_i32 : i32
            %71 = arith.remsi %70, %c2_i32 : i32
            %72 = arith.index_cast %71 : i32 to index
            %subview_50 = memref.subview %reinterpret_cast_14[%66, 0, %69] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
            %alloc_51 = memref.alloc() : memref<4x1024xbf16>
            memref.copy %subview_50, %alloc_51 : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
            %73 = bufferization.to_tensor %alloc_51 restrict : memref<4x1024xbf16>
            %inserted_slice_52 = tensor.insert_slice %73 into %arg35[%72, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
            %subview_53 = memref.subview %reinterpret_cast_7[%66, 0, %69] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
            %alloc_54 = memref.alloc() : memref<4x1024xbf16>
            memref.copy %subview_53, %alloc_54 : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
            %74 = bufferization.to_tensor %alloc_54 restrict : memref<4x1024xbf16>
            %inserted_slice_55 = tensor.insert_slice %74 into %arg36[%72, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
            %subview_56 = memref.subview %reinterpret_cast_9[0, %69] [4, 1024] [1, 1] : memref<4x4096xf32, strided<[4096, 1]>> to memref<4x1024xf32, strided<[4096, 1], offset: ?>>
            %alloc_57 = memref.alloc() : memref<4x1024xf32>
            memref.copy %subview_56, %alloc_57 : memref<4x1024xf32, strided<[4096, 1], offset: ?>> to memref<4x1024xf32>
            %75 = bufferization.to_tensor %alloc_57 restrict : memref<4x1024xf32>
            %inserted_slice_58 = tensor.insert_slice %75 into %arg37[%72, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xf32> into tensor<2x4x1024xf32>
            scf.yield %inserted_slice_52, %inserted_slice_55, %inserted_slice_58 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<2x4x1024xf32>
          } else {
            scf.yield %arg35, %arg36, %arg37 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<2x4x1024xf32>
          }
          %63:2 = scf.for %arg40 = %c0_i32 to %c2_i32 step %c1_i32 iter_args(%arg41 = %arg38, %arg42 = %arg39) -> (tensor<4xf32>, tensor<4xf32>)  : i32 {
            %64:2 = scf.for %arg43 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg44 = %arg41, %arg45 = %arg42) -> (tensor<4xf32>, tensor<4xf32>)  : i32 {
              %65:2 = scf.for %arg46 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg47 = %arg44, %arg48 = %arg45) -> (tensor<4xf32>, tensor<4xf32>)  : i32 {
                %66 = tensor.empty() : tensor<4xf32>
                %67 = tensor.empty() : tensor<4xf32>
                %68 = tensor.empty() : tensor<4xf32>
                %69 = tensor.empty() : tensor<4xf32>
                %70 = tensor.empty() : tensor<4xf32>
                %71 = tensor.empty() : tensor<4xf32>
                %72 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %66) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.index_cast %arg28 : i32 to index
                  %81 = arith.muli %arg34, %c1024_i32 : i32
                  %82 = arith.muli %arg46, %c256_i32 : i32
                  %83 = arith.addi %81, %82 : i32
                  %84 = arith.muli %arg40, %c128_i32 : i32
                  %85 = arith.addi %83, %84 : i32
                  %86 = arith.muli %arg43, %c4_i32 : i32
                  %87 = arith.addi %85, %86 : i32
                  %88 = arith.addi %87, %arg49 : i32
                  %89 = arith.index_cast %88 : i32 to index
                  %extracted_50 = tensor.extract %17#0[%80, %89] : tensor<4x4096xbf16>
                  %90 = arith.extf %extracted_50 : bf16 to f32
                  %91 = arith.index_cast %arg49 : i32 to index
                  %inserted_51 = tensor.insert %90 into %arg50[%91] : tensor<4xf32>
                  scf.yield %inserted_51 : tensor<4xf32>
                }
                %73 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %arg47) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.remsi %arg34, %c2_i32 : i32
                  %81 = arith.index_cast %80 : i32 to index
                  %82 = arith.index_cast %arg28 : i32 to index
                  %83 = arith.muli %arg46, %c256_i32 : i32
                  %84 = arith.muli %arg40, %c128_i32 : i32
                  %85 = arith.addi %83, %84 : i32
                  %86 = arith.muli %arg43, %c4_i32 : i32
                  %87 = arith.addi %85, %86 : i32
                  %88 = arith.addi %87, %arg49 : i32
                  %89 = arith.index_cast %88 : i32 to index
                  %extracted_50 = tensor.extract %62#0[%81, %82, %89] : tensor<2x4x1024xbf16>
                  %90 = arith.extf %extracted_50 : bf16 to f32
                  %91 = arith.index_cast %arg49 : i32 to index
                  %inserted_51 = tensor.insert %90 into %arg50[%91] : tensor<4xf32>
                  scf.yield %inserted_51 : tensor<4xf32>
                }
                %74 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %arg48) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.remsi %arg34, %c2_i32 : i32
                  %81 = arith.index_cast %80 : i32 to index
                  %82 = arith.index_cast %arg28 : i32 to index
                  %83 = arith.muli %arg46, %c256_i32 : i32
                  %84 = arith.muli %arg40, %c128_i32 : i32
                  %85 = arith.addi %83, %84 : i32
                  %86 = arith.muli %arg43, %c4_i32 : i32
                  %87 = arith.addi %85, %86 : i32
                  %88 = arith.addi %87, %arg49 : i32
                  %89 = arith.index_cast %88 : i32 to index
                  %extracted_50 = tensor.extract %62#1[%81, %82, %89] : tensor<2x4x1024xbf16>
                  %90 = arith.extf %extracted_50 : bf16 to f32
                  %91 = arith.index_cast %arg49 : i32 to index
                  %inserted_51 = tensor.insert %90 into %arg50[%91] : tensor<4xf32>
                  scf.yield %inserted_51 : tensor<4xf32>
                }
                %75 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %67) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.remsi %arg34, %c2_i32 : i32
                  %81 = arith.index_cast %80 : i32 to index
                  %82 = arith.index_cast %arg28 : i32 to index
                  %83 = arith.muli %arg46, %c256_i32 : i32
                  %84 = arith.muli %arg40, %c128_i32 : i32
                  %85 = arith.addi %83, %84 : i32
                  %86 = arith.muli %arg43, %c4_i32 : i32
                  %87 = arith.addi %85, %86 : i32
                  %88 = arith.addi %87, %arg49 : i32
                  %89 = arith.index_cast %88 : i32 to index
                  %extracted_50 = tensor.extract %62#2[%81, %82, %89] : tensor<2x4x1024xf32>
                  %90 = arith.index_cast %arg49 : i32 to index
                  %inserted_51 = tensor.insert %extracted_50 into %arg50[%90] : tensor<4xf32>
                  scf.yield %inserted_51 : tensor<4xf32>
                }
                %76 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %68) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_50 = tensor.extract %73[%80] : tensor<4xf32>
                  %extracted_51 = tensor.extract %75[%80] : tensor<4xf32>
                  %81 = arith.mulf %extracted_50, %extracted_51 : f32
                  %inserted_52 = tensor.insert %81 into %arg50[%80] : tensor<4xf32>
                  scf.yield %inserted_52 : tensor<4xf32>
                }
                %77 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %69) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_50 = tensor.extract %74[%80] : tensor<4xf32>
                  %extracted_51 = tensor.extract %inserted_40[%c0] : tensor<1xf32>
                  %81 = arith.mulf %extracted_50, %extracted_51 : f32
                  %inserted_52 = tensor.insert %81 into %arg50[%80] : tensor<4xf32>
                  scf.yield %inserted_52 : tensor<4xf32>
                }
                %78 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %70) -> (tensor<4xf32>)  : i32 {
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_50 = tensor.extract %72[%80] : tensor<4xf32>
                  %extracted_51 = tensor.extract %49[%c0] : tensor<1xf32>
                  %extracted_52 = tensor.extract %74[%80] : tensor<4xf32>
                  %extracted_53 = tensor.extract %75[%80] : tensor<4xf32>
                  %81 = arith.mulf %extracted_52, %extracted_53 : f32
                  %extracted_54 = tensor.extract %73[%80] : tensor<4xf32>
                  %extracted_55 = tensor.extract %inserted_36[%c0] : tensor<1xf32>
                  %82 = arith.mulf %extracted_54, %extracted_55 : f32
                  %83 = arith.subf %81, %82 : f32
                  %84 = arith.mulf %extracted_51, %83 : f32
                  %85 = arith.addf %extracted_50, %84 : f32
                  %inserted_56 = tensor.insert %85 into %arg50[%80] : tensor<4xf32>
                  scf.yield %inserted_56 : tensor<4xf32>
                }
                %79 = scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg50 = %71) -> (tensor<4xf32>)  : i32 {
                  %extracted_50 = tensor.extract %49[%c0] : tensor<1xf32>
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_51 = tensor.extract %76[%80] : tensor<4xf32>
                  %extracted_52 = tensor.extract %77[%80] : tensor<4xf32>
                  %81 = arith.subf %extracted_51, %extracted_52 : f32
                  %82 = arith.mulf %extracted_50, %81 : f32
                  %inserted_53 = tensor.insert %82 into %arg50[%80] : tensor<4xf32>
                  scf.yield %inserted_53 : tensor<4xf32>
                }
                scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_50 = tensor.extract %78[%80] : tensor<4xf32>
                  %81 = arith.truncf %extracted_50 : f32 to bf16
                  %82 = arith.muli %1, %c4_i32 : i32
                  %83 = arith.addi %82, %arg22 : i32
                  %84 = arith.index_cast %83 : i32 to index
                  %85 = arith.index_cast %arg28 : i32 to index
                  %86 = arith.muli %arg34, %c1024_i32 : i32
                  %87 = arith.muli %arg46, %c256_i32 : i32
                  %88 = arith.addi %86, %87 : i32
                  %89 = arith.muli %arg40, %c128_i32 : i32
                  %90 = arith.addi %88, %89 : i32
                  %91 = arith.muli %arg43, %c4_i32 : i32
                  %92 = arith.addi %90, %91 : i32
                  %93 = arith.addi %92, %arg49 : i32
                  %94 = arith.index_cast %93 : i32 to index
                  memref.store %81, %reinterpret_cast_16[%84, %85, %94] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
                }
                scf.for %arg49 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
                  %80 = arith.index_cast %arg49 : i32 to index
                  %extracted_50 = tensor.extract %79[%80] : tensor<4xf32>
                  %81 = arith.truncf %extracted_50 : f32 to bf16
                  %82 = arith.muli %1, %c4_i32 : i32
                  %83 = arith.addi %82, %arg22 : i32
                  %84 = arith.index_cast %83 : i32 to index
                  %85 = arith.index_cast %arg28 : i32 to index
                  %86 = arith.muli %arg34, %c1024_i32 : i32
                  %87 = arith.muli %arg46, %c256_i32 : i32
                  %88 = arith.addi %86, %87 : i32
                  %89 = arith.muli %arg40, %c128_i32 : i32
                  %90 = arith.addi %88, %89 : i32
                  %91 = arith.muli %arg43, %c4_i32 : i32
                  %92 = arith.addi %90, %91 : i32
                  %93 = arith.addi %92, %arg49 : i32
                  %94 = arith.index_cast %93 : i32 to index
                  memref.store %81, %reinterpret_cast_18[%84, %85, %94] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>>
                }
                scf.yield %73, %74 : tensor<4xf32>, tensor<4xf32>
              }
              scf.yield %65#0, %65#1 : tensor<4xf32>, tensor<4xf32>
            }
            scf.yield %64#0, %64#1 : tensor<4xf32>, tensor<4xf32>
          }
          scf.yield %62#0, %62#1, %62#2, %63#0, %63#1 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<2x4x1024xf32>, tensor<4xf32>, tensor<4xf32>
        }
        scf.yield %inserted_32, %60#0, %60#1, %60#3, %60#4 : tensor<4x4xf32>, tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>
      }
      scf.yield %18#0, %18#1, %18#2, %18#3, %18#4 : tensor<4x4xf32>, tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>
    }
    %8:4 = scf.for %arg22 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg23 = %7#1, %arg24 = %7#2, %arg25 = %7#3, %arg26 = %7#4) -> (tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>)  : i32 {
      %9:4 = scf.for %arg27 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg28 = %arg23, %arg29 = %arg24, %arg30 = %arg25, %arg31 = %arg26) -> (tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>)  : i32 {
        %10 = tensor.empty() : tensor<1024xf32>
        %11 = hivm.hir.vbrc ins(%cst_6 : f32) outs(%10 : tensor<1024xf32>) -> tensor<1024xf32>
        %12:5 = scf.for %arg32 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg33 = %arg28, %arg34 = %arg29, %arg35 = %arg30, %arg36 = %arg31, %arg37 = %11) -> (tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>)  : i32 {
          %13 = arith.muli %1, %c4_i32 : i32
          %14 = arith.addi %13, %arg32 : i32
          %15 = arith.index_cast %14 : i32 to index
          %16 = arith.muli %arg27, %c1024_i32 : i32
          %17 = arith.index_cast %16 : i32 to index
          %subview = memref.subview %reinterpret_cast_14[%15, 0, %17] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
          %alloc = memref.alloc() : memref<4x1024xbf16>
          memref.copy %subview, %alloc : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
          %18 = bufferization.to_tensor %alloc restrict : memref<4x1024xbf16>
          %inserted_slice = tensor.insert_slice %18 into %arg33[0, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
          %subview_19 = memref.subview %reinterpret_cast_7[%15, 0, %17] [1, 4, 1024] [1, 1, 1] : memref<16x4x4096xbf16, strided<[16384, 4096, 1]>> to memref<4x1024xbf16, strided<[4096, 1], offset: ?>>
          %alloc_20 = memref.alloc() : memref<4x1024xbf16>
          memref.copy %subview_19, %alloc_20 : memref<4x1024xbf16, strided<[4096, 1], offset: ?>> to memref<4x1024xbf16>
          %19 = bufferization.to_tensor %alloc_20 restrict : memref<4x1024xbf16>
          %inserted_slice_21 = tensor.insert_slice %19 into %arg34[0, 0, 0] [1, 4, 1024] [1, 1, 1] : tensor<4x1024xbf16> into tensor<2x4x1024xbf16>
          %20:3 = scf.for %arg38 = %c0_i32 to %c2_i32 step %c1_i32 iter_args(%arg39 = %arg35, %arg40 = %arg36, %arg41 = %arg37) -> (tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>)  : i32 {
            %21:3 = scf.for %arg42 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg43 = %arg39, %arg44 = %arg40, %arg45 = %arg41) -> (tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>)  : i32 {
              %22:3 = scf.for %arg46 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg47 = %arg43, %arg48 = %arg44, %arg49 = %arg45) -> (tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>)  : i32 {
                %23 = scf.for %arg50 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg51 = %arg47) -> (tensor<4xf32>)  : i32 {
                  %26 = arith.index_cast %arg22 : i32 to index
                  %27 = arith.muli %arg46, %c256_i32 : i32
                  %28 = arith.muli %arg38, %c128_i32 : i32
                  %29 = arith.addi %27, %28 : i32
                  %30 = arith.muli %arg42, %c4_i32 : i32
                  %31 = arith.addi %29, %30 : i32
                  %32 = arith.addi %31, %arg50 : i32
                  %33 = arith.index_cast %32 : i32 to index
                  %extracted = tensor.extract %inserted_slice[%c0, %26, %33] : tensor<2x4x1024xbf16>
                  %34 = arith.extf %extracted : bf16 to f32
                  %35 = arith.index_cast %arg50 : i32 to index
                  %inserted = tensor.insert %34 into %arg51[%35] : tensor<4xf32>
                  scf.yield %inserted : tensor<4xf32>
                }
                %24 = scf.for %arg50 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg51 = %arg48) -> (tensor<4xf32>)  : i32 {
                  %26 = arith.index_cast %arg22 : i32 to index
                  %27 = arith.muli %arg46, %c256_i32 : i32
                  %28 = arith.muli %arg38, %c128_i32 : i32
                  %29 = arith.addi %27, %28 : i32
                  %30 = arith.muli %arg42, %c4_i32 : i32
                  %31 = arith.addi %29, %30 : i32
                  %32 = arith.addi %31, %arg50 : i32
                  %33 = arith.index_cast %32 : i32 to index
                  %extracted = tensor.extract %inserted_slice_21[%c0, %26, %33] : tensor<2x4x1024xbf16>
                  %34 = arith.extf %extracted : bf16 to f32
                  %35 = arith.index_cast %arg50 : i32 to index
                  %inserted = tensor.insert %34 into %arg51[%35] : tensor<4xf32>
                  scf.yield %inserted : tensor<4xf32>
                }
                %25 = scf.for %arg50 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg51 = %arg49) -> (tensor<1024xf32>)  : i32 {
                  %26 = arith.muli %arg46, %c256_i32 : i32
                  %27 = arith.muli %arg38, %c128_i32 : i32
                  %28 = arith.addi %26, %27 : i32
                  %29 = arith.muli %arg42, %c4_i32 : i32
                  %30 = arith.addi %28, %29 : i32
                  %31 = arith.addi %30, %arg50 : i32
                  %32 = arith.index_cast %31 : i32 to index
                  %extracted = tensor.extract %arg51[%32] : tensor<1024xf32>
                  %33 = arith.index_cast %arg32 : i32 to index
                  %34 = arith.index_cast %arg22 : i32 to index
                  %extracted_22 = tensor.extract %7#0[%33, %34] : tensor<4x4xf32>
                  %35 = arith.index_cast %arg50 : i32 to index
                  %extracted_23 = tensor.extract %23[%35] : tensor<4xf32>
                  %36 = arith.mulf %extracted_22, %extracted_23 : f32
                  %extracted_24 = tensor.extract %24[%35] : tensor<4xf32>
                  %37 = arith.mulf %36, %extracted_24 : f32
                  %38 = arith.addf %extracted, %37 : f32
                  %inserted = tensor.insert %38 into %arg51[%32] : tensor<1024xf32>
                  scf.yield %inserted : tensor<1024xf32>
                }
                scf.yield %23, %24, %25 : tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>
              }
              scf.yield %22#0, %22#1, %22#2 : tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>
            }
            scf.yield %21#0, %21#1, %21#2 : tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>
          }
          scf.yield %inserted_slice, %inserted_slice_21, %20#0, %20#1, %20#2 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>, tensor<1024xf32>
        }
        scf.for %arg32 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
          scf.for %arg33 = %c0_i32 to %c32_i32 step %c1_i32  : i32 {
            scf.for %arg34 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
              scf.for %arg35 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
                %13 = arith.muli %arg34, %c256_i32 : i32
                %14 = arith.muli %arg32, %c128_i32 : i32
                %15 = arith.addi %13, %14 : i32
                %16 = arith.muli %arg33, %c4_i32 : i32
                %17 = arith.addi %15, %16 : i32
                %18 = arith.addi %17, %arg35 : i32
                %19 = arith.index_cast %18 : i32 to index
                %extracted = tensor.extract %12#4[%19] : tensor<1024xf32>
                %20 = arith.index_cast %1 : i32 to index
                %21 = arith.index_cast %arg22 : i32 to index
                %22 = arith.muli %arg27, %c1024_i32 : i32
                %23 = arith.addi %22, %13 : i32
                %24 = arith.addi %23, %14 : i32
                %25 = arith.addi %24, %16 : i32
                %26 = arith.addi %25, %arg35 : i32
                %27 = arith.index_cast %26 : i32 to index
                memref.store %extracted, %reinterpret_cast_11[%20, %21, %27] : memref<4x4x4096xf32, strided<[16384, 4096, 1]>>
              }
            }
          }
        }
        scf.yield %12#0, %12#1, %12#2, %12#3 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>
      }
      scf.yield %9#0, %9#1, %9#2, %9#3 : tensor<2x4x1024xbf16>, tensor<2x4x1024xbf16>, tensor<4xf32>, tensor<4xf32>
    }
    return
  }
}