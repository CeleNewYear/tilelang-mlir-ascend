module attributes {hivm.module_core_type = #hivm.module_core_type<MIX>, memref.memref_as_ptr} {
  func.func @flash_attention(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<MIX>, hivm.part_of_mix, mix_mode = "mix"} {
    %c64 = arith.constant 64 : index
    %cst = arith.constant 0.000000e+00 : f32
    %c128 = arith.constant 128 : index
    %c1 = arith.constant 1 : index
    %false = arith.constant false
    %true = arith.constant true
    %c8_i32 = arith.constant 8 : i32
    %cst_0 = arith.constant 0.0883883461 : f32
    %cst_1 = arith.constant 0xFF800000 : f32
    %c0_i32 = arith.constant 0 : i32
    %c64_i32 = arith.constant 64 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [512, 128], strides: [%c128, %c1] : memref<?xf16> to memref<512x128xf16, strided<[128, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [512, 128], strides: [%c128, %c1] : memref<?xf16> to memref<512x128xf16, strided<[128, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [512, 128], strides: [%c128, %c1] : memref<?xf16> to memref<512x128xf16, strided<[128, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [512, 128], strides: [%c128, %c1] : memref<?xf16> to memref<512x128xf16, strided<[128, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<64x1xf32>
    %3 = tensor.empty() : tensor<64x1xf32>
    %4 = tensor.empty() : tensor<64x128xf32>
    %5 = tensor.empty() : tensor<64x64xf32>
    %6 = tensor.empty() : tensor<64x128xf16>
    %7 = arith.muli %1, %c64_i32 : i32
    %8 = arith.index_cast %7 : i32 to index
    %subview = memref.subview %reinterpret_cast[%8, 0] [64, 128] [1, 1] : memref<512x128xf16, strided<[128, 1]>> to memref<64x128xf16, strided<[128, 1], offset: ?>>
    %alloc = memref.alloc() : memref<64x128xf16>
    memref.copy %subview, %alloc : memref<64x128xf16, strided<[128, 1], offset: ?>> to memref<64x128xf16>
    %9 = bufferization.to_tensor %alloc restrict : memref<64x128xf16>
    %10 = hivm.hir.vbrc ins(%cst : f32) outs(%4 : tensor<64x128xf32>) -> tensor<64x128xf32>
    %11 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %12 = hivm.hir.vbrc ins(%cst_1 : f32) outs(%2 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %13 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%5 : tensor<64x64xf32>) -> tensor<64x64xf32>
    %14:3 = scf.for %arg13 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg14 = %12, %arg15 = %11, %arg16 = %10) -> (tensor<64x1xf32>, tensor<64x1xf32>, tensor<64x128xf32>)  : i32 {
      %17 = tensor.empty() : tensor<64x64xf32>
      %18 = tensor.empty() : tensor<64x64xf16>
      %19 = tensor.empty() : tensor<64x1xf32>
      %20 = tensor.empty() : tensor<64x1xf32>
      %21 = tensor.empty() : tensor<64x1xf32>
      %22 = tensor.empty() : tensor<64x64xf32>
      %23 = tensor.empty() : tensor<64x1xf32>
      %24 = tensor.empty() : tensor<64x1xf32>
      %25 = arith.muli %arg13, %c64_i32 : i32
      %26 = arith.index_cast %25 : i32 to index
      %subview_6 = memref.subview %reinterpret_cast_3[%26, 0] [64, 128] [1, 1] : memref<512x128xf16, strided<[128, 1]>> to memref<64x128xf16, strided<[128, 1], offset: ?>>
      %alloc_7 = memref.alloc() : memref<64x128xf16>
      memref.copy %subview_6, %alloc_7 : memref<64x128xf16, strided<[128, 1], offset: ?>> to memref<64x128xf16>
      %27 = bufferization.to_tensor %alloc_7 restrict : memref<64x128xf16>
      %28 = hivm.hir.mmadL1 {b_transpose} ins(%9, %27, %true, %c64, %c64, %c128 : tensor<64x128xf16>, tensor<64x128xf16>, i1, index, index, index) outs(%17 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %29 = hivm.hir.vmul ins(%28, %13 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%28 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %30 = hivm.hir.vreduce <max> ins(%29 : tensor<64x64xf32>) outs(%20 : tensor<64x1xf32>) reduce_dims = [1] -> tensor<64x1xf32>
      %31 = hivm.hir.vmax ins(%arg14, %30 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%24 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %32 = hivm.hir.vsub ins(%arg14, %31 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%23 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %33 = hivm.hir.vexp ins(%32 : tensor<64x1xf32>) outs(%19 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %34 = hivm.hir.vsub ins(%29, %31 : tensor<64x64xf32>, tensor<64x1xf32>) outs(%22 : tensor<64x64xf32>) broadcast = [1] -> tensor<64x64xf32>
      %35 = hivm.hir.vexp ins(%34 : tensor<64x64xf32>) outs(%29 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %36 = hivm.hir.vreduce <sum> ins(%35 : tensor<64x64xf32>) outs(%21 : tensor<64x1xf32>) reduce_dims = [1] -> tensor<64x1xf32>
      %37 = hivm.hir.vmul ins(%arg15, %33 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%arg15 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %38 = hivm.hir.vadd ins(%37, %36 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%37 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %39 = hivm.hir.vmul ins(%arg16, %33 : tensor<64x128xf32>, tensor<64x1xf32>) outs(%arg16 : tensor<64x128xf32>) broadcast = [1] -> tensor<64x128xf32>
      %40 = hivm.hir.vcast ins(%35 : tensor<64x64xf32>) outs(%18 : tensor<64x64xf16>) -> tensor<64x64xf16>
      %41 = hivm.hir.vbrc ins(%cst : f32) outs(%32 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %42 = hivm.hir.vadd ins(%41, %31 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%arg14 : tensor<64x1xf32>) -> tensor<64x1xf32>
      %subview_8 = memref.subview %reinterpret_cast_2[%26, 0] [64, 128] [1, 1] : memref<512x128xf16, strided<[128, 1]>> to memref<64x128xf16, strided<[128, 1], offset: ?>>
      %alloc_9 = memref.alloc() : memref<64x128xf16>
      memref.copy %subview_8, %alloc_9 : memref<64x128xf16, strided<[128, 1], offset: ?>> to memref<64x128xf16>
      %43 = bufferization.to_tensor %alloc_9 restrict : memref<64x128xf16>
      %44 = hivm.hir.mmadL1 ins(%40, %43, %false, %c64, %c64, %c128 : tensor<64x64xf16>, tensor<64x128xf16>, i1, index, index, index) outs(%39 : tensor<64x128xf32>) -> tensor<64x128xf32>
      scf.yield %42, %38, %44 : tensor<64x1xf32>, tensor<64x1xf32>, tensor<64x128xf32>
    }
    %15 = hivm.hir.vdiv ins(%14#2, %14#1 : tensor<64x128xf32>, tensor<64x1xf32>) outs(%14#2 : tensor<64x128xf32>) broadcast = [1] -> tensor<64x128xf32>
    %16 = hivm.hir.vcast ins(%15 : tensor<64x128xf32>) outs(%6 : tensor<64x128xf16>) -> tensor<64x128xf16>
    %subview_5 = memref.subview %reinterpret_cast_4[%8, 0] [64, 128] [1, 1] : memref<512x128xf16, strided<[128, 1]>> to memref<64x128xf16, strided<[128, 1], offset: ?>>
    bufferization.materialize_in_destination %16 in writable %subview_5 : (tensor<64x128xf16>, memref<64x128xf16, strided<[128, 1], offset: ?>>) -> ()
    return
  }
}