module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @engram_gate_fwd_kernel(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xf32>, %arg7: memref<?xbf16>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xf32>, %arg11: memref<?xf32>, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32, %arg16: i32, %arg17: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %cst = arith.constant 0x7F800000 : f32
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c2048 = arith.constant 2048 : index
    %c512 = arith.constant 512 : index
    %c1 = arith.constant 1 : index
    %c6_i32 = arith.constant 6 : i32
    %cst_0 = arith.constant 1.000000e+00 : f32
    %cst_1 = arith.constant -1.000000e+00 : f32
    %cst_2 = arith.constant 0.000000e+00 : f32
    %cst_3 = arith.constant 9.99999997E-7 : f32
    %cst_4 = arith.constant 0.0441941731 : f32
    %cst_5 = arith.constant 9.99999968E-21 : f32
    %cst_6 = arith.constant 0.001953125 : f32
    %c256_i32 = arith.constant 256 : i32
    %c8_i32 = arith.constant 8 : i32
    %c32_i32 = arith.constant 32 : i32
    %c0_i32 = arith.constant 0 : i32
    %c7_i32 = arith.constant 7 : i32
    %c2_i32 = arith.constant 2 : i32
    %c4_i32 = arith.constant 4 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [7, 4, 512], strides: [%c2048, %c512, %c1] : memref<?xbf16> to memref<7x4x512xbf16, strided<[2048, 512, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [7, 512], strides: [%c512, %c1] : memref<?xbf16> to memref<7x512xbf16, strided<[512, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [7, 4], strides: [%c4, %c1] : memref<?xf32> to memref<7x4xf32, strided<[4, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [7, 4, 512], strides: [%c2048, %c512, %c1] : memref<?xbf16> to memref<7x4x512xbf16, strided<[2048, 512, 1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [7, 4], strides: [%c4, %c1] : memref<?xf32> to memref<7x4xf32, strided<[4, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [7, 4], strides: [%c4, %c1] : memref<?xf32> to memref<7x4xf32, strided<[4, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [7, 4, 512], strides: [%c2048, %c512, %c1] : memref<?xbf16> to memref<7x4x512xbf16, strided<[2048, 512, 1]>>
    %reinterpret_cast_13 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [4, 512], strides: [%c512, %c1] : memref<?xf32> to memref<4x512xf32, strided<[512, 1]>>
    %reinterpret_cast_14 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [7, 4], strides: [%c4, %c1] : memref<?xf32> to memref<7x4xf32, strided<[4, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = arith.divsi %1, %c4_i32 : i32
    %3 = arith.muli %2, %c2_i32 : i32
    %4 = arith.minsi %3, %c7_i32 : i32
    %5 = arith.addi %3, %c2_i32 : i32
    %6 = arith.minsi %5, %c7_i32 : i32
    scf.for %arg18 = %4 to %6 step %c1_i32  : i32 {
      %7 = tensor.empty() : tensor<1xf32>
      %8 = tensor.empty() : tensor<1xf32>
      %9 = tensor.empty() : tensor<1xf32>
      %10 = tensor.empty() : tensor<1xf32>
      %11 = tensor.empty() : tensor<1xf32>
      %12 = tensor.empty() : tensor<1xf32>
      %13 = tensor.empty() : tensor<512xbf16>
      %14 = tensor.empty() : tensor<2x256xbf16>
      %15 = tensor.empty() : tensor<1xf32>
      %16 = tensor.empty() : tensor<1xf32>
      %17 = tensor.empty() : tensor<1xf32>
      %18 = arith.divsi %1, %c4_i32 : i32
      %19 = arith.muli %18, %c2_i32 : i32
      %20 = arith.minsi %19, %c7_i32 : i32
      %21 = arith.cmpi eq, %arg18, %20 : i32
      %22:2 = scf.if %21 -> (tensor<512xbf16>, tensor<2x256xbf16>) {
        %55 = arith.index_cast %arg18 : i32 to index
        %56 = arith.remsi %1, %c4_i32 : i32
        %57 = arith.index_cast %56 : i32 to index
        %subview_43 = memref.subview %reinterpret_cast[%55, %57, 0] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
        %alloc_44 = memref.alloc() : memref<256xbf16>
        memref.copy %subview_43, %alloc_44 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
        %58 = bufferization.to_tensor %alloc_44 restrict : memref<256xbf16>
        %inserted_slice_45 = tensor.insert_slice %58 into %13[0] [256] [1] : tensor<256xbf16> into tensor<512xbf16>
        %subview_46 = memref.subview %reinterpret_cast_12[%55, %57, 0] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
        %alloc_47 = memref.alloc() : memref<256xbf16>
        memref.copy %subview_46, %alloc_47 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
        %59 = bufferization.to_tensor %alloc_47 restrict : memref<256xbf16>
        %inserted_slice_48 = tensor.insert_slice %59 into %14[0, 0] [1, 256] [1, 1] : tensor<256xbf16> into tensor<2x256xbf16>
        scf.yield %inserted_slice_45, %inserted_slice_48 : tensor<512xbf16>, tensor<2x256xbf16>
      } else {
        scf.yield %13, %14 : tensor<512xbf16>, tensor<2x256xbf16>
      }
      %23 = hivm.hir.vbrc ins(%cst_2 : f32) outs(%9 : tensor<1xf32>) -> tensor<1xf32>
      %24 = hivm.hir.vbrc ins(%cst_2 : f32) outs(%8 : tensor<1xf32>) -> tensor<1xf32>
      %25 = hivm.hir.vbrc ins(%cst_2 : f32) outs(%7 : tensor<1xf32>) -> tensor<1xf32>
      %26 = arith.index_cast %arg18 : i32 to index
      %27 = arith.remsi %1, %c4_i32 : i32
      %28 = arith.index_cast %27 : i32 to index
      %subview = memref.subview %reinterpret_cast[%26, %28, 256] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
      %alloc = memref.alloc() : memref<256xbf16>
      memref.copy %subview, %alloc : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
      %29 = bufferization.to_tensor %alloc restrict : memref<256xbf16>
      %inserted_slice = tensor.insert_slice %29 into %22#0[256] [256] [1] : tensor<256xbf16> into tensor<512xbf16>
      %subview_15 = memref.subview %reinterpret_cast_12[%26, %28, 256] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
      %alloc_16 = memref.alloc() : memref<256xbf16>
      memref.copy %subview_15, %alloc_16 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
      %30 = bufferization.to_tensor %alloc_16 restrict : memref<256xbf16>
      %inserted_slice_17 = tensor.insert_slice %30 into %22#1[1, 0] [1, 256] [1, 1] : tensor<256xbf16> into tensor<2x256xbf16>
      %31:3 = scf.for %arg19 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg20 = %24, %arg21 = %23, %arg22 = %25) -> (tensor<1xf32>, tensor<1xf32>, tensor<1xf32>)  : i32 {
        %55 = tensor.empty() : tensor<8xf32>
        %56 = tensor.empty() : tensor<8xf32>
        %57 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %55) -> (tensor<8xf32>)  : i32 {
          %65 = arith.muli %arg19, %c8_i32 : i32
          %66 = arith.addi %65, %arg23 : i32
          %67 = arith.index_cast %66 : i32 to index
          %extracted_45 = tensor.extract %inserted_slice[%67] : tensor<512xbf16>
          %68 = arith.extf %extracted_45 : bf16 to f32
          %69 = arith.index_cast %arg23 : i32 to index
          %inserted_46 = tensor.insert %68 into %arg24[%69] : tensor<8xf32>
          scf.yield %inserted_46 : tensor<8xf32>
        }
        %58 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %56) -> (tensor<8xf32>)  : i32 {
          %65 = arith.muli %arg19, %c8_i32 : i32
          %66 = arith.addi %65, %arg23 : i32
          %67 = arith.index_cast %66 : i32 to index
          %extracted_45 = tensor.extract %inserted_slice_17[%c0, %67] : tensor<2x256xbf16>
          %68 = arith.extf %extracted_45 : bf16 to f32
          %69 = arith.index_cast %arg23 : i32 to index
          %inserted_46 = tensor.insert %68 into %arg24[%69] : tensor<8xf32>
          scf.yield %inserted_46 : tensor<8xf32>
        }
        %59 = arith.remsi %1, %c4_i32 : i32
        %60 = arith.index_cast %59 : i32 to index
        %61 = arith.muli %arg19, %c8_i32 : i32
        %62 = arith.index_cast %61 : i32 to index
        %subview_43 = memref.subview %reinterpret_cast_13[%60, %62] [1, 8] [1, 1] : memref<4x512xf32, strided<[512, 1]>> to memref<8xf32, strided<[1], offset: ?>>
        %alloc_44 = memref.alloc() : memref<8xf32>
        memref.copy %subview_43, %alloc_44 : memref<8xf32, strided<[1], offset: ?>> to memref<8xf32>
        %63 = bufferization.to_tensor %alloc_44 restrict : memref<8xf32>
        %64:3 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %arg20, %arg25 = %arg21, %arg26 = %arg22) -> (tensor<1xf32>, tensor<1xf32>, tensor<1xf32>)  : i32 {
          %extracted_45 = tensor.extract %arg24[%c0] : tensor<1xf32>
          %65 = arith.index_cast %arg23 : i32 to index
          %extracted_46 = tensor.extract %57[%65] : tensor<8xf32>
          %extracted_47 = tensor.extract %57[%65] : tensor<8xf32>
          %66 = arith.mulf %extracted_46, %extracted_47 : f32
          %67 = arith.addf %extracted_45, %66 : f32
          %inserted_48 = tensor.insert %67 into %arg24[%c0] : tensor<1xf32>
          %extracted_49 = tensor.extract %arg25[%c0] : tensor<1xf32>
          %extracted_50 = tensor.extract %58[%65] : tensor<8xf32>
          %extracted_51 = tensor.extract %58[%65] : tensor<8xf32>
          %68 = arith.mulf %extracted_50, %extracted_51 : f32
          %69 = arith.addf %extracted_49, %68 : f32
          %inserted_52 = tensor.insert %69 into %arg25[%c0] : tensor<1xf32>
          %extracted_53 = tensor.extract %arg26[%c0] : tensor<1xf32>
          %extracted_54 = tensor.extract %57[%65] : tensor<8xf32>
          %extracted_55 = tensor.extract %63[%65] : tensor<8xf32>
          %70 = arith.mulf %extracted_54, %extracted_55 : f32
          %extracted_56 = tensor.extract %58[%65] : tensor<8xf32>
          %71 = arith.mulf %70, %extracted_56 : f32
          %72 = arith.addf %extracted_53, %71 : f32
          %inserted_57 = tensor.insert %72 into %arg26[%c0] : tensor<1xf32>
          scf.yield %inserted_48, %inserted_52, %inserted_57 : tensor<1xf32>, tensor<1xf32>, tensor<1xf32>
        }
        scf.yield %64#0, %64#1, %64#2 : tensor<1xf32>, tensor<1xf32>, tensor<1xf32>
      }
      %32:3 = scf.for %arg19 = %c0_i32 to %c32_i32 step %c1_i32 iter_args(%arg20 = %31#0, %arg21 = %31#1, %arg22 = %31#2) -> (tensor<1xf32>, tensor<1xf32>, tensor<1xf32>)  : i32 {
        %55 = tensor.empty() : tensor<8xf32>
        %56 = tensor.empty() : tensor<8xf32>
        %57 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %55) -> (tensor<8xf32>)  : i32 {
          %66 = arith.muli %arg19, %c8_i32 : i32
          %67 = arith.addi %66, %arg23 : i32
          %68 = arith.addi %67, %c256_i32 : i32
          %69 = arith.index_cast %68 : i32 to index
          %extracted_45 = tensor.extract %inserted_slice[%69] : tensor<512xbf16>
          %70 = arith.extf %extracted_45 : bf16 to f32
          %71 = arith.index_cast %arg23 : i32 to index
          %inserted_46 = tensor.insert %70 into %arg24[%71] : tensor<8xf32>
          scf.yield %inserted_46 : tensor<8xf32>
        }
        %58 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %56) -> (tensor<8xf32>)  : i32 {
          %66 = arith.muli %arg19, %c8_i32 : i32
          %67 = arith.addi %66, %arg23 : i32
          %68 = arith.index_cast %67 : i32 to index
          %extracted_45 = tensor.extract %inserted_slice_17[%c1, %68] : tensor<2x256xbf16>
          %69 = arith.extf %extracted_45 : bf16 to f32
          %70 = arith.index_cast %arg23 : i32 to index
          %inserted_46 = tensor.insert %69 into %arg24[%70] : tensor<8xf32>
          scf.yield %inserted_46 : tensor<8xf32>
        }
        %59 = arith.remsi %1, %c4_i32 : i32
        %60 = arith.index_cast %59 : i32 to index
        %61 = arith.muli %arg19, %c8_i32 : i32
        %62 = arith.addi %61, %c256_i32 : i32
        %63 = arith.index_cast %62 : i32 to index
        %subview_43 = memref.subview %reinterpret_cast_13[%60, %63] [1, 8] [1, 1] : memref<4x512xf32, strided<[512, 1]>> to memref<8xf32, strided<[1], offset: ?>>
        %alloc_44 = memref.alloc() : memref<8xf32>
        memref.copy %subview_43, %alloc_44 : memref<8xf32, strided<[1], offset: ?>> to memref<8xf32>
        %64 = bufferization.to_tensor %alloc_44 restrict : memref<8xf32>
        %65:3 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %arg20, %arg25 = %arg21, %arg26 = %arg22) -> (tensor<1xf32>, tensor<1xf32>, tensor<1xf32>)  : i32 {
          %extracted_45 = tensor.extract %arg24[%c0] : tensor<1xf32>
          %66 = arith.index_cast %arg23 : i32 to index
          %extracted_46 = tensor.extract %57[%66] : tensor<8xf32>
          %extracted_47 = tensor.extract %57[%66] : tensor<8xf32>
          %67 = arith.mulf %extracted_46, %extracted_47 : f32
          %68 = arith.addf %extracted_45, %67 : f32
          %inserted_48 = tensor.insert %68 into %arg24[%c0] : tensor<1xf32>
          %extracted_49 = tensor.extract %arg25[%c0] : tensor<1xf32>
          %extracted_50 = tensor.extract %58[%66] : tensor<8xf32>
          %extracted_51 = tensor.extract %58[%66] : tensor<8xf32>
          %69 = arith.mulf %extracted_50, %extracted_51 : f32
          %70 = arith.addf %extracted_49, %69 : f32
          %inserted_52 = tensor.insert %70 into %arg25[%c0] : tensor<1xf32>
          %extracted_53 = tensor.extract %arg26[%c0] : tensor<1xf32>
          %extracted_54 = tensor.extract %57[%66] : tensor<8xf32>
          %extracted_55 = tensor.extract %64[%66] : tensor<8xf32>
          %71 = arith.mulf %extracted_54, %extracted_55 : f32
          %extracted_56 = tensor.extract %58[%66] : tensor<8xf32>
          %72 = arith.mulf %71, %extracted_56 : f32
          %73 = arith.addf %extracted_53, %72 : f32
          %inserted_57 = tensor.insert %73 into %arg26[%c0] : tensor<1xf32>
          scf.yield %inserted_48, %inserted_52, %inserted_57 : tensor<1xf32>, tensor<1xf32>, tensor<1xf32>
        }
        scf.yield %65#0, %65#1, %65#2 : tensor<1xf32>, tensor<1xf32>, tensor<1xf32>
      }
      %extracted = tensor.extract %32#1[%c0] : tensor<1xf32>
      %inserted = tensor.insert %extracted into %12[%c0] : tensor<1xf32>
      %extracted_18 = tensor.extract %32#0[%c0] : tensor<1xf32>
      %inserted_19 = tensor.insert %extracted_18 into %11[%c0] : tensor<1xf32>
      %extracted_20 = tensor.extract %32#2[%c0] : tensor<1xf32>
      %inserted_21 = tensor.insert %extracted_20 into %10[%c0] : tensor<1xf32>
      %extracted_22 = tensor.extract %inserted_19[%c0] : tensor<1xf32>
      %33 = arith.mulf %extracted_22, %cst_6 : f32
      %34 = arith.addf %33, %cst_5 : f32
      %inserted_23 = tensor.insert %34 into %inserted_19[%c0] : tensor<1xf32>
      %35 = hivm.hir.vrsqrt ins(%inserted_23 : tensor<1xf32>) outs(%inserted_23 : tensor<1xf32>) -> tensor<1xf32>
      %extracted_24 = tensor.extract %inserted[%c0] : tensor<1xf32>
      %36 = arith.mulf %extracted_24, %cst_6 : f32
      %37 = arith.addf %36, %cst_5 : f32
      %inserted_25 = tensor.insert %37 into %inserted[%c0] : tensor<1xf32>
      %38 = hivm.hir.vrsqrt ins(%inserted_25 : tensor<1xf32>) outs(%inserted_25 : tensor<1xf32>) -> tensor<1xf32>
      %subview_26 = memref.subview %reinterpret_cast_11[%26, %28] [1, 1] [1, 1] : memref<7x4xf32, strided<[4, 1]>> to memref<1xf32, strided<[4], offset: ?>>
      bufferization.materialize_in_destination %inserted_21 in writable %subview_26 : (tensor<1xf32>, memref<1xf32, strided<[4], offset: ?>>) -> ()
      %subview_27 = memref.subview %reinterpret_cast_14[%26, %28] [1, 1] [1, 1] : memref<7x4xf32, strided<[4, 1]>> to memref<1xf32, strided<[4], offset: ?>>
      bufferization.materialize_in_destination %35 in writable %subview_27 : (tensor<1xf32>, memref<1xf32, strided<[4], offset: ?>>) -> ()
      %subview_28 = memref.subview %reinterpret_cast_10[%26, %28] [1, 1] [1, 1] : memref<7x4xf32, strided<[4, 1]>> to memref<1xf32, strided<[4], offset: ?>>
      bufferization.materialize_in_destination %38 in writable %subview_28 : (tensor<1xf32>, memref<1xf32, strided<[4], offset: ?>>) -> ()
      %extracted_29 = tensor.extract %inserted_21[%c0] : tensor<1xf32>
      %extracted_30 = tensor.extract %35[%c0] : tensor<1xf32>
      %39 = arith.mulf %extracted_29, %extracted_30 : f32
      %extracted_31 = tensor.extract %38[%c0] : tensor<1xf32>
      %40 = arith.mulf %39, %extracted_31 : f32
      %41 = arith.mulf %40, %cst_4 : f32
      %inserted_32 = tensor.insert %41 into %inserted_21[%c0] : tensor<1xf32>
      %extracted_33 = tensor.extract %inserted_32[%c0] : tensor<1xf32>
      %inserted_34 = tensor.insert %extracted_33 into %15[%c0] : tensor<1xf32>
      %42 = hivm.hir.vabs ins(%inserted_34 : tensor<1xf32>) outs(%16 : tensor<1xf32>) -> tensor<1xf32>
      %43 = hivm.hir.vmax ins(%42, %cst_3 : tensor<1xf32>, f32) outs(%42 : tensor<1xf32>) -> tensor<1xf32>
      %44 = hivm.hir.vmin ins(%43, %cst : tensor<1xf32>, f32) outs(%43 : tensor<1xf32>) -> tensor<1xf32>
      %45 = hivm.hir.vsqrt ins(%44 : tensor<1xf32>) outs(%17 : tensor<1xf32>) -> tensor<1xf32>
      %extracted_35 = tensor.extract %inserted_34[%c0] : tensor<1xf32>
      %46 = arith.cmpf olt, %extracted_35, %cst_2 : f32
      %47 = scf.if %46 -> (tensor<1xf32>) {
        %extracted_43 = tensor.extract %45[%c0] : tensor<1xf32>
        %55 = arith.mulf %extracted_43, %cst_1 : f32
        %inserted_44 = tensor.insert %55 into %inserted_32[%c0] : tensor<1xf32>
        scf.yield %inserted_44 : tensor<1xf32>
      } else {
        %extracted_43 = tensor.extract %45[%c0] : tensor<1xf32>
        %inserted_44 = tensor.insert %extracted_43 into %inserted_32[%c0] : tensor<1xf32>
        scf.yield %inserted_44 : tensor<1xf32>
      }
      %48 = hivm.hir.vsub ins(%cst_2, %47 : f32, tensor<1xf32>) outs(%47 : tensor<1xf32>) -> tensor<1xf32>
      %49 = hivm.hir.vexp ins(%48 : tensor<1xf32>) outs(%47 : tensor<1xf32>) -> tensor<1xf32>
      %50 = hivm.hir.vadd ins(%49, %cst_0 : tensor<1xf32>, f32) outs(%47 : tensor<1xf32>) -> tensor<1xf32>
      %51 = hivm.hir.vdiv ins(%cst_0, %50 : f32, tensor<1xf32>) outs(%47 : tensor<1xf32>) -> tensor<1xf32>
      %subview_36 = memref.subview %reinterpret_cast_8[%26, %28] [1, 1] [1, 1] : memref<7x4xf32, strided<[4, 1]>> to memref<1xf32, strided<[4], offset: ?>>
      bufferization.materialize_in_destination %51 in writable %subview_36 : (tensor<1xf32>, memref<1xf32, strided<[4], offset: ?>>) -> ()
      %subview_37 = memref.subview %reinterpret_cast_7[%26, 0] [1, 256] [1, 1] : memref<7x512xbf16, strided<[512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
      %alloc_38 = memref.alloc() : memref<256xbf16>
      memref.copy %subview_37, %alloc_38 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
      %52 = bufferization.to_tensor %alloc_38 restrict : memref<256xbf16>
      %inserted_slice_39 = tensor.insert_slice %52 into %inserted_slice_17[0, 0] [1, 256] [1, 1] : tensor<256xbf16> into tensor<2x256xbf16>
      %subview_40 = memref.subview %reinterpret_cast_7[%26, 256] [1, 256] [1, 1] : memref<7x512xbf16, strided<[512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
      %alloc_41 = memref.alloc() : memref<256xbf16>
      memref.copy %subview_40, %alloc_41 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
      %53 = bufferization.to_tensor %alloc_41 restrict : memref<256xbf16>
      %inserted_slice_42 = tensor.insert_slice %53 into %inserted_slice_39[1, 0] [1, 256] [1, 1] : tensor<256xbf16> into tensor<2x256xbf16>
      %54:2 = scf.for %arg19 = %c0_i32 to %c2_i32 step %c1_i32 iter_args(%arg20 = %inserted_slice_42, %arg21 = %inserted_slice) -> (tensor<2x256xbf16>, tensor<512xbf16>)  : i32 {
        %55 = arith.cmpi eq, %arg19, %c1_i32 : i32
        %56 = arith.divsi %1, %c4_i32 : i32
        %57 = arith.muli %56, %c2_i32 : i32
        %58 = arith.cmpi sle, %arg18, %57 : i32
        %59 = arith.andi %55, %58 : i1
        %60 = arith.cmpi slt, %arg18, %c6_i32 : i32
        %61 = arith.andi %59, %60 : i1
        %62:2 = scf.if %61 -> (tensor<2x256xbf16>, tensor<512xbf16>) {
          %63 = arith.addi %arg18, %c1_i32 : i32
          %64 = arith.index_cast %63 : i32 to index
          %65 = arith.remsi %1, %c4_i32 : i32
          %66 = arith.index_cast %65 : i32 to index
          %subview_43 = memref.subview %reinterpret_cast_12[%64, %66, 0] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
          %alloc_44 = memref.alloc() : memref<256xbf16>
          memref.copy %subview_43, %alloc_44 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
          %67 = bufferization.to_tensor %alloc_44 restrict : memref<256xbf16>
          %inserted_slice_45 = tensor.insert_slice %67 into %arg20[0, 0] [1, 256] [1, 1] : tensor<256xbf16> into tensor<2x256xbf16>
          %subview_46 = memref.subview %reinterpret_cast[%64, %66, 0] [1, 1, 256] [1, 1, 1] : memref<7x4x512xbf16, strided<[2048, 512, 1]>> to memref<256xbf16, strided<[1], offset: ?>>
          %alloc_47 = memref.alloc() : memref<256xbf16>
          memref.copy %subview_46, %alloc_47 : memref<256xbf16, strided<[1], offset: ?>> to memref<256xbf16>
          %68 = bufferization.to_tensor %alloc_47 restrict : memref<256xbf16>
          %inserted_slice_48 = tensor.insert_slice %68 into %arg21[0] [256] [1] : tensor<256xbf16> into tensor<512xbf16>
          scf.yield %inserted_slice_45, %inserted_slice_48 : tensor<2x256xbf16>, tensor<512xbf16>
        } else {
          scf.yield %arg20, %arg21 : tensor<2x256xbf16>, tensor<512xbf16>
        }
        scf.for %arg22 = %c0_i32 to %c32_i32 step %c1_i32  : i32 {
          %63 = tensor.empty() : tensor<8xf32>
          %64 = tensor.empty() : tensor<8xf32>
          %65 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %64) -> (tensor<8xf32>)  : i32 {
            %67 = arith.muli %arg19, %c256_i32 : i32
            %68 = arith.muli %arg22, %c8_i32 : i32
            %69 = arith.addi %67, %68 : i32
            %70 = arith.addi %69, %arg23 : i32
            %71 = arith.index_cast %70 : i32 to index
            %extracted_43 = tensor.extract %62#1[%71] : tensor<512xbf16>
            %72 = arith.extf %extracted_43 : bf16 to f32
            %73 = arith.index_cast %arg23 : i32 to index
            %inserted_44 = tensor.insert %72 into %arg24[%73] : tensor<8xf32>
            scf.yield %inserted_44 : tensor<8xf32>
          }
          %66 = scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg24 = %63) -> (tensor<8xf32>)  : i32 {
            %67 = arith.index_cast %arg19 : i32 to index
            %68 = arith.muli %arg22, %c8_i32 : i32
            %69 = arith.addi %68, %arg23 : i32
            %70 = arith.index_cast %69 : i32 to index
            %extracted_43 = tensor.extract %62#0[%67, %70] : tensor<2x256xbf16>
            %71 = arith.extf %extracted_43 : bf16 to f32
            %72 = arith.index_cast %arg23 : i32 to index
            %inserted_44 = tensor.insert %71 into %arg24[%72] : tensor<8xf32>
            scf.yield %inserted_44 : tensor<8xf32>
          }
          scf.for %arg23 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
            %67 = arith.index_cast %arg23 : i32 to index
            %extracted_43 = tensor.extract %65[%67] : tensor<8xf32>
            %extracted_44 = tensor.extract %51[%c0] : tensor<1xf32>
            %extracted_45 = tensor.extract %66[%67] : tensor<8xf32>
            %68 = arith.mulf %extracted_44, %extracted_45 : f32
            %69 = arith.addf %extracted_43, %68 : f32
            %70 = arith.truncf %69 : f32 to bf16
            %71 = arith.index_cast %arg18 : i32 to index
            %72 = arith.remsi %1, %c4_i32 : i32
            %73 = arith.index_cast %72 : i32 to index
            %74 = arith.muli %arg19, %c256_i32 : i32
            %75 = arith.muli %arg22, %c8_i32 : i32
            %76 = arith.addi %74, %75 : i32
            %77 = arith.addi %76, %arg23 : i32
            %78 = arith.index_cast %77 : i32 to index
            memref.store %70, %reinterpret_cast_9[%71, %73, %78] : memref<7x4x512xbf16, strided<[2048, 512, 1]>>
          }
        }
        scf.yield %62#0, %62#1 : tensor<2x256xbf16>, tensor<512xbf16>
      }
    }
    return
  }
}