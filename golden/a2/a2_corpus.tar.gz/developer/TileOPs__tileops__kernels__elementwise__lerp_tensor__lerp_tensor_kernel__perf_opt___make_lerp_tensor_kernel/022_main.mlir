module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16>, %arg4: memref<?xbf16>, %arg5: memref<?xbf16>, %arg6: memref<?xbf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %c196609_i32 = arith.constant 196609 : i32
    %c4096_i32 = arith.constant 4096 : i32
    %c196608_i32 = arith.constant 196608 : i32
    %c49_i32 = arith.constant 49 : i32
    %c48_i32 = arith.constant 48 : i32
    %c2_i32 = arith.constant 2 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [196609], strides: [%c1] : memref<?xbf16> to memref<196609xbf16, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [196609], strides: [%c1] : memref<?xbf16> to memref<196609xbf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [196609], strides: [%c1] : memref<?xbf16> to memref<196609xbf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [196609], strides: [%c1] : memref<?xbf16> to memref<196609xbf16, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    scf.for %arg13 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
      %2 = tensor.empty() : tensor<4096xbf16>
      %3 = tensor.empty() : tensor<4096xbf16>
      %4 = tensor.empty() : tensor<4096xbf16>
      %5 = tensor.empty() : tensor<4096xbf16>
      %6 = tensor.empty() : tensor<4096xf32>
      %7 = tensor.empty() : tensor<4096xf32>
      %8 = tensor.empty() : tensor<4096xf32>
      %9 = arith.muli %arg13, %c48_i32 : i32
      %10 = arith.addi %9, %1 : i32
      %11 = arith.cmpi slt, %10, %c49_i32 : i32
      scf.if %11 {
        %12 = arith.muli %arg13, %c196608_i32 : i32
        %13 = arith.muli %1, %c4096_i32 : i32
        %14 = arith.addi %12, %13 : i32
        %15 = arith.index_cast %14 : i32 to index
        %16 = arith.subi %c196609_i32, %13 : i32
        %17 = arith.subi %16, %12 : i32
        %18 = arith.minsi %17, %c4096_i32 : i32
        %19 = arith.index_cast %18 : i32 to index
        %subview = memref.subview %reinterpret_cast[%15] [%19] [1] : memref<196609xbf16, strided<[1]>> to memref<?xbf16, strided<[1], offset: ?>>
        %alloc = memref.alloc() : memref<4096xbf16>
        %subview_3 = memref.subview %alloc[0] [%19] [1] : memref<4096xbf16> to memref<?xbf16, strided<[1]>>
        memref.copy %subview, %subview_3 : memref<?xbf16, strided<[1], offset: ?>> to memref<?xbf16, strided<[1]>>
        %20 = bufferization.to_tensor %subview_3 restrict : memref<?xbf16, strided<[1]>>
        %inserted_slice = tensor.insert_slice %20 into %2[0] [%19] [1] : tensor<?xbf16> into tensor<4096xbf16>
        %subview_4 = memref.subview %reinterpret_cast_1[%15] [%19] [1] : memref<196609xbf16, strided<[1]>> to memref<?xbf16, strided<[1], offset: ?>>
        %alloc_5 = memref.alloc() : memref<4096xbf16>
        %subview_6 = memref.subview %alloc_5[0] [%19] [1] : memref<4096xbf16> to memref<?xbf16, strided<[1]>>
        memref.copy %subview_4, %subview_6 : memref<?xbf16, strided<[1], offset: ?>> to memref<?xbf16, strided<[1]>>
        %21 = bufferization.to_tensor %subview_6 restrict : memref<?xbf16, strided<[1]>>
        %inserted_slice_7 = tensor.insert_slice %21 into %3[0] [%19] [1] : tensor<?xbf16> into tensor<4096xbf16>
        %subview_8 = memref.subview %reinterpret_cast_0[%15] [%19] [1] : memref<196609xbf16, strided<[1]>> to memref<?xbf16, strided<[1], offset: ?>>
        %alloc_9 = memref.alloc() : memref<4096xbf16>
        %subview_10 = memref.subview %alloc_9[0] [%19] [1] : memref<4096xbf16> to memref<?xbf16, strided<[1]>>
        memref.copy %subview_8, %subview_10 : memref<?xbf16, strided<[1], offset: ?>> to memref<?xbf16, strided<[1]>>
        %22 = bufferization.to_tensor %subview_10 restrict : memref<?xbf16, strided<[1]>>
        %inserted_slice_11 = tensor.insert_slice %22 into %4[0] [%19] [1] : tensor<?xbf16> into tensor<4096xbf16>
        %23 = hivm.hir.vcast ins(%inserted_slice : tensor<4096xbf16>) outs(%6 : tensor<4096xf32>) -> tensor<4096xf32>
        %24 = hivm.hir.vcast ins(%inserted_slice_7 : tensor<4096xbf16>) outs(%7 : tensor<4096xf32>) -> tensor<4096xf32>
        %25 = hivm.hir.vcast ins(%inserted_slice_11 : tensor<4096xbf16>) outs(%8 : tensor<4096xf32>) -> tensor<4096xf32>
        %26 = hivm.hir.vsub ins(%24, %23 : tensor<4096xf32>, tensor<4096xf32>) outs(%24 : tensor<4096xf32>) -> tensor<4096xf32>
        %27 = hivm.hir.vmul ins(%25, %26 : tensor<4096xf32>, tensor<4096xf32>) outs(%26 : tensor<4096xf32>) -> tensor<4096xf32>
        %28 = hivm.hir.vadd ins(%23, %27 : tensor<4096xf32>, tensor<4096xf32>) outs(%27 : tensor<4096xf32>) -> tensor<4096xf32>
        %29 = hivm.hir.vcast ins(%28 : tensor<4096xf32>) outs(%5 : tensor<4096xbf16>) -> tensor<4096xbf16>
        %extracted_slice = tensor.extract_slice %29[0] [%19] [1] : tensor<4096xbf16> to tensor<?xbf16>
        %subview_12 = memref.subview %reinterpret_cast_2[%15] [%19] [1] : memref<196609xbf16, strided<[1]>> to memref<?xbf16, strided<[1], offset: ?>>
        bufferization.materialize_in_destination %extracted_slice in writable %subview_12 : (tensor<?xbf16>, memref<?xbf16, strided<[1], offset: ?>>) -> ()
      }
    }
    return
  }
}