module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1], strides: [%c1] : memref<?xf16> to memref<1xf16, strided<[1]>>
    %0 = tensor.empty() : tensor<4096xf16>
    %1 = tensor.empty() : tensor<4096xf16>
    %2 = tensor.empty() : tensor<4096xf16>
    %3 = tensor.empty() : tensor<4096xf16>
    %4 = tensor.empty() : tensor<4096xf32>
    %5 = tensor.empty() : tensor<4096xf32>
    %6 = tensor.empty() : tensor<4096xf32>
    %alloc = memref.alloc() : memref<1xf16>
    memref.copy %reinterpret_cast, %alloc : memref<1xf16, strided<[1]>> to memref<1xf16>
    %7 = bufferization.to_tensor %alloc restrict : memref<1xf16>
    %inserted_slice = tensor.insert_slice %7 into %0[0] [1] [1] : tensor<1xf16> into tensor<4096xf16>
    %alloc_3 = memref.alloc() : memref<1xf16>
    memref.copy %reinterpret_cast_1, %alloc_3 : memref<1xf16, strided<[1]>> to memref<1xf16>
    %8 = bufferization.to_tensor %alloc_3 restrict : memref<1xf16>
    %inserted_slice_4 = tensor.insert_slice %8 into %1[0] [1] [1] : tensor<1xf16> into tensor<4096xf16>
    %alloc_5 = memref.alloc() : memref<1xf16>
    memref.copy %reinterpret_cast_0, %alloc_5 : memref<1xf16, strided<[1]>> to memref<1xf16>
    %9 = bufferization.to_tensor %alloc_5 restrict : memref<1xf16>
    %inserted_slice_6 = tensor.insert_slice %9 into %2[0] [1] [1] : tensor<1xf16> into tensor<4096xf16>
    %10 = hivm.hir.vcast ins(%inserted_slice : tensor<4096xf16>) outs(%4 : tensor<4096xf32>) -> tensor<4096xf32>
    %11 = hivm.hir.vcast ins(%inserted_slice_4 : tensor<4096xf16>) outs(%5 : tensor<4096xf32>) -> tensor<4096xf32>
    %12 = hivm.hir.vcast ins(%inserted_slice_6 : tensor<4096xf16>) outs(%6 : tensor<4096xf32>) -> tensor<4096xf32>
    %13 = hivm.hir.vsub ins(%11, %10 : tensor<4096xf32>, tensor<4096xf32>) outs(%11 : tensor<4096xf32>) -> tensor<4096xf32>
    %14 = hivm.hir.vmul ins(%12, %13 : tensor<4096xf32>, tensor<4096xf32>) outs(%13 : tensor<4096xf32>) -> tensor<4096xf32>
    %15 = hivm.hir.vadd ins(%10, %14 : tensor<4096xf32>, tensor<4096xf32>) outs(%14 : tensor<4096xf32>) -> tensor<4096xf32>
    %16 = hivm.hir.vcast ins(%15 : tensor<4096xf32>) outs(%3 : tensor<4096xf16>) -> tensor<4096xf16>
    %extracted_slice = tensor.extract_slice %16[0] [1] [1] : tensor<4096xf16> to tensor<1xf16>
    bufferization.materialize_in_destination %extracted_slice in writable %reinterpret_cast_2 : (tensor<1xf16>, memref<1xf16, strided<[1]>>) -> ()
    return
  }
}