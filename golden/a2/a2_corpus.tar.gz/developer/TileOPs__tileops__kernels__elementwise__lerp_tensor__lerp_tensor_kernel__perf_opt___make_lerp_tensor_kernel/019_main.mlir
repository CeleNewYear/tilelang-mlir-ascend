module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %c4096_i32 = arith.constant 4096 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [192512], strides: [%c1] : memref<?xf16> to memref<192512xf16, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [192512], strides: [%c1] : memref<?xf16> to memref<192512xf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [192512], strides: [%c1] : memref<?xf16> to memref<192512xf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [192512], strides: [%c1] : memref<?xf16> to memref<192512xf16, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<4096xf16>
    %3 = tensor.empty() : tensor<4096xf32>
    %4 = tensor.empty() : tensor<4096xf32>
    %5 = tensor.empty() : tensor<4096xf32>
    %6 = arith.muli %1, %c4096_i32 : i32
    %7 = arith.index_cast %6 : i32 to index
    %subview = memref.subview %reinterpret_cast[%7] [4096] [1] : memref<192512xf16, strided<[1]>> to memref<4096xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<4096xf16>
    memref.copy %subview, %alloc : memref<4096xf16, strided<[1], offset: ?>> to memref<4096xf16>
    %8 = bufferization.to_tensor %alloc restrict : memref<4096xf16>
    %subview_3 = memref.subview %reinterpret_cast_1[%7] [4096] [1] : memref<192512xf16, strided<[1]>> to memref<4096xf16, strided<[1], offset: ?>>
    %alloc_4 = memref.alloc() : memref<4096xf16>
    memref.copy %subview_3, %alloc_4 : memref<4096xf16, strided<[1], offset: ?>> to memref<4096xf16>
    %9 = bufferization.to_tensor %alloc_4 restrict : memref<4096xf16>
    %subview_5 = memref.subview %reinterpret_cast_0[%7] [4096] [1] : memref<192512xf16, strided<[1]>> to memref<4096xf16, strided<[1], offset: ?>>
    %alloc_6 = memref.alloc() : memref<4096xf16>
    memref.copy %subview_5, %alloc_6 : memref<4096xf16, strided<[1], offset: ?>> to memref<4096xf16>
    %10 = bufferization.to_tensor %alloc_6 restrict : memref<4096xf16>
    %11 = hivm.hir.vcast ins(%8 : tensor<4096xf16>) outs(%3 : tensor<4096xf32>) -> tensor<4096xf32>
    %12 = hivm.hir.vcast ins(%9 : tensor<4096xf16>) outs(%4 : tensor<4096xf32>) -> tensor<4096xf32>
    %13 = hivm.hir.vcast ins(%10 : tensor<4096xf16>) outs(%5 : tensor<4096xf32>) -> tensor<4096xf32>
    %14 = hivm.hir.vsub ins(%12, %11 : tensor<4096xf32>, tensor<4096xf32>) outs(%12 : tensor<4096xf32>) -> tensor<4096xf32>
    %15 = hivm.hir.vmul ins(%13, %14 : tensor<4096xf32>, tensor<4096xf32>) outs(%14 : tensor<4096xf32>) -> tensor<4096xf32>
    %16 = hivm.hir.vadd ins(%11, %15 : tensor<4096xf32>, tensor<4096xf32>) outs(%15 : tensor<4096xf32>) -> tensor<4096xf32>
    %17 = hivm.hir.vcast ins(%16 : tensor<4096xf32>) outs(%2 : tensor<4096xf16>) -> tensor<4096xf16>
    %subview_7 = memref.subview %reinterpret_cast_2[%7] [4096] [1] : memref<192512xf16, strided<[1]>> to memref<4096xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %17 in writable %subview_7 : (tensor<4096xf16>, memref<4096xf16, strided<[1], offset: ?>>) -> ()
    return
  }
}