module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @high_perf(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %cst = arith.constant 0.000000e+00 : f32
    %c4096 = arith.constant 4096 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant 9.99999974E-6 : f32
    %cst_1 = arith.constant 2.44140625E-4 : f32
    %c64_i32 = arith.constant 64 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4096, 4096], strides: [%c4096, %c1] : memref<?xf16> to memref<4096x4096xf16, strided<[4096, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [4096, 4096], strides: [%c4096, %c1] : memref<?xf16> to memref<4096x4096xf16, strided<[4096, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<64x64xf32>
    %3 = tensor.empty() : tensor<64x1xf32>
    %4 = tensor.empty() : tensor<64x1xf32>
    %5 = tensor.empty() : tensor<64x1xf32>
    %6 = tensor.empty() : tensor<64x1xf32>
    %7 = tensor.empty() : tensor<64x1xf32>
    %8 = hivm.hir.vbrc ins(%cst : f32) outs(%3 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %9:2 = scf.for %arg13 = %c0_i32 to %c64_i32 step %c1_i32 iter_args(%arg14 = %5, %arg15 = %8) -> (tensor<64x1xf32>, tensor<64x1xf32>)  : i32 {
      %17 = arith.muli %1, %c64_i32 : i32
      %18 = arith.index_cast %17 : i32 to index
      %19 = arith.muli %arg13, %c64_i32 : i32
      %20 = arith.index_cast %19 : i32 to index
      %subview = memref.subview %reinterpret_cast[%18, %20] [64, 64] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<64x64xf16, strided<[4096, 1], offset: ?>>
      %alloc = memref.alloc() : memref<64x64xf16>
      memref.copy %subview, %alloc : memref<64x64xf16, strided<[4096, 1], offset: ?>> to memref<64x64xf16>
      %21 = bufferization.to_tensor %alloc restrict : memref<64x64xf16>
      %22 = tensor.empty() : tensor<64x64xf32>
      %23 = hivm.hir.vcast ins(%21 : tensor<64x64xf16>) outs(%22 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %24 = tensor.empty() : tensor<64x1xf32>
      %25 = hivm.hir.vreduce <sum> ins(%23 : tensor<64x64xf32>) outs(%24 : tensor<64x1xf32>) reduce_dims = [1] -> tensor<64x1xf32>
      %26 = hivm.hir.vadd ins(%arg15, %25 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%arg15 : tensor<64x1xf32>) -> tensor<64x1xf32>
      scf.yield %25, %26 : tensor<64x1xf32>, tensor<64x1xf32>
    }
    %10 = hivm.hir.vmul ins(%9#1, %cst_1 : tensor<64x1xf32>, f32) outs(%4 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %11 = hivm.hir.vbrc ins(%cst : f32) outs(%9#1 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %12:3 = scf.for %arg13 = %c0_i32 to %c64_i32 step %c1_i32 iter_args(%arg14 = %2, %arg15 = %9#0, %arg16 = %11) -> (tensor<64x64xf32>, tensor<64x1xf32>, tensor<64x1xf32>)  : i32 {
      %17 = tensor.empty() : tensor<64x64xf32>
      %18 = tensor.empty() : tensor<64x64xf32>
      %19 = tensor.empty() : tensor<64x64xf32>
      %20 = tensor.empty() : tensor<64x64xf32>
      %21 = arith.muli %1, %c64_i32 : i32
      %22 = arith.index_cast %21 : i32 to index
      %23 = arith.muli %arg13, %c64_i32 : i32
      %24 = arith.index_cast %23 : i32 to index
      %subview = memref.subview %reinterpret_cast[%22, %24] [64, 64] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<64x64xf16, strided<[4096, 1], offset: ?>>
      %alloc = memref.alloc() : memref<64x64xf16>
      memref.copy %subview, %alloc : memref<64x64xf16, strided<[4096, 1], offset: ?>> to memref<64x64xf16>
      %25 = bufferization.to_tensor %alloc restrict : memref<64x64xf16>
      %26 = tensor.empty() : tensor<64x64xf32>
      %27 = hivm.hir.vcast ins(%25 : tensor<64x64xf16>) outs(%26 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %28 = hivm.hir.vbrc ins(%10 : tensor<64x1xf32>) outs(%17 : tensor<64x64xf32>) broadcast_dims = [1] -> tensor<64x64xf32>
      %29 = hivm.hir.vbrc ins(%10 : tensor<64x1xf32>) outs(%19 : tensor<64x64xf32>) broadcast_dims = [1] -> tensor<64x64xf32>
      %30 = hivm.hir.vsub ins(%27, %28 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%18 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %31 = hivm.hir.vsub ins(%27, %29 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%20 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %32 = hivm.hir.vmul ins(%30, %31 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%arg14 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %33 = tensor.empty() : tensor<64x1xf32>
      %34 = hivm.hir.vreduce <sum> ins(%32 : tensor<64x64xf32>) outs(%33 : tensor<64x1xf32>) reduce_dims = [1] -> tensor<64x1xf32>
      %35 = hivm.hir.vadd ins(%arg16, %34 : tensor<64x1xf32>, tensor<64x1xf32>) outs(%arg16 : tensor<64x1xf32>) -> tensor<64x1xf32>
      scf.yield %32, %34, %35 : tensor<64x64xf32>, tensor<64x1xf32>, tensor<64x1xf32>
    }
    %13 = hivm.hir.vmul ins(%12#2, %cst_1 : tensor<64x1xf32>, f32) outs(%7 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %14 = hivm.hir.vadd ins(%13, %cst_0 : tensor<64x1xf32>, f32) outs(%12#1 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %15 = hivm.hir.vrsqrt ins(%14 : tensor<64x1xf32>) outs(%6 : tensor<64x1xf32>) -> tensor<64x1xf32>
    %16 = scf.for %arg13 = %c0_i32 to %c64_i32 step %c1_i32 iter_args(%arg14 = %12#0) -> (tensor<64x64xf32>)  : i32 {
      %17 = tensor.empty() : tensor<64x64xf32>
      %18 = tensor.empty() : tensor<64x64xf32>
      %19 = tensor.empty() : tensor<64x64xf32>
      %20 = tensor.empty() : tensor<64x64xf32>
      %21 = tensor.empty() : tensor<64x64xf32>
      %22 = tensor.empty() : tensor<64x64xf32>
      %23 = tensor.empty() : tensor<64x64xf32>
      %24 = arith.muli %1, %c64_i32 : i32
      %25 = arith.index_cast %24 : i32 to index
      %26 = arith.muli %arg13, %c64_i32 : i32
      %27 = arith.index_cast %26 : i32 to index
      %subview = memref.subview %reinterpret_cast[%25, %27] [64, 64] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<64x64xf16, strided<[4096, 1], offset: ?>>
      %alloc = memref.alloc() : memref<64x64xf16>
      memref.copy %subview, %alloc : memref<64x64xf16, strided<[4096, 1], offset: ?>> to memref<64x64xf16>
      %28 = bufferization.to_tensor %alloc restrict : memref<64x64xf16>
      %29 = tensor.empty() : tensor<64x64xf32>
      %30 = hivm.hir.vcast ins(%28 : tensor<64x64xf16>) outs(%29 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %subview_5 = memref.subview %reinterpret_cast_3[%27] [64] [1] : memref<4096xf16, strided<[1]>> to memref<64xf16, strided<[1], offset: ?>>
      %alloc_6 = memref.alloc() : memref<64xf16>
      memref.copy %subview_5, %alloc_6 : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
      %31 = bufferization.to_tensor %alloc_6 restrict : memref<64xf16>
      %32 = tensor.empty() : tensor<64xf32>
      %33 = hivm.hir.vcast ins(%31 : tensor<64xf16>) outs(%32 : tensor<64xf32>) -> tensor<64xf32>
      %subview_7 = memref.subview %reinterpret_cast_2[%27] [64] [1] : memref<4096xf16, strided<[1]>> to memref<64xf16, strided<[1], offset: ?>>
      %alloc_8 = memref.alloc() : memref<64xf16>
      memref.copy %subview_7, %alloc_8 : memref<64xf16, strided<[1], offset: ?>> to memref<64xf16>
      %34 = bufferization.to_tensor %alloc_8 restrict : memref<64xf16>
      %35 = tensor.empty() : tensor<64xf32>
      %36 = hivm.hir.vcast ins(%34 : tensor<64xf16>) outs(%35 : tensor<64xf32>) -> tensor<64xf32>
      %37 = hivm.hir.vbrc ins(%10 : tensor<64x1xf32>) outs(%17 : tensor<64x64xf32>) broadcast_dims = [1] -> tensor<64x64xf32>
      %38 = hivm.hir.vbrc ins(%15 : tensor<64x1xf32>) outs(%19 : tensor<64x64xf32>) broadcast_dims = [1] -> tensor<64x64xf32>
      %expanded = tensor.expand_shape %33 [[0, 1]] output_shape [1, 64] : tensor<64xf32> into tensor<1x64xf32>
      %39 = hivm.hir.vbrc ins(%expanded : tensor<1x64xf32>) outs(%21 : tensor<64x64xf32>) broadcast_dims = [0] -> tensor<64x64xf32>
      %expanded_9 = tensor.expand_shape %36 [[0, 1]] output_shape [1, 64] : tensor<64xf32> into tensor<1x64xf32>
      %40 = hivm.hir.vbrc ins(%expanded_9 : tensor<1x64xf32>) outs(%23 : tensor<64x64xf32>) broadcast_dims = [0] -> tensor<64x64xf32>
      %41 = hivm.hir.vsub ins(%30, %37 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%18 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %42 = hivm.hir.vmul ins(%41, %38 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%20 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %43 = hivm.hir.vmul ins(%42, %39 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%22 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %44 = hivm.hir.vadd ins(%43, %40 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%arg14 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %45 = tensor.empty() : tensor<64x64xf16>
      %46 = hivm.hir.vcast ins(%44 : tensor<64x64xf32>) outs(%45 : tensor<64x64xf16>) -> tensor<64x64xf16>
      %subview_10 = memref.subview %reinterpret_cast_4[%25, %27] [64, 64] [1, 1] : memref<4096x4096xf16, strided<[4096, 1]>> to memref<64x64xf16, strided<[4096, 1], offset: ?>>
      bufferization.materialize_in_destination %46 in writable %subview_10 : (tensor<64x64xf16>, memref<64x64xf16, strided<[4096, 1], offset: ?>>) -> ()
      scf.yield %44 : tensor<64x64xf32>
    }
    return
  }
}