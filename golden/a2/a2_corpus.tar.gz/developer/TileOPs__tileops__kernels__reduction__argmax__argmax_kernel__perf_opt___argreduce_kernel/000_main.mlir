module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xi64>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %c256 = arith.constant 256 : index
    %c1 = arith.constant 1 : index
    %c8_i32 = arith.constant 8 : i32
    %cst = arith.constant 1.07374182E+9 : f32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [32, 256], strides: [%c256, %c1] : memref<?xf16> to memref<32x256xf16, strided<[256, 1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [32], strides: [%c1] : memref<?xi64> to memref<32xi64, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<256xf32>
    %3 = tensor.empty() : tensor<8x256xf32>
    %4 = tensor.empty() : tensor<8x256xf32>
    %5 = hivm.hir.varange offset[%c0] strides[%c1] outs(%2 : tensor<256xf32>) -> tensor<256xf32>
    %expanded = tensor.expand_shape %5 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %6 = hivm.hir.vbrc ins(%expanded : tensor<1x256xf32>) outs(%3 : tensor<8x256xf32>) broadcast_dims = [0] -> tensor<8x256xf32>
    %7 = hivm.hir.vbrc ins(%cst : f32) outs(%4 : tensor<8x256xf32>) -> tensor<8x256xf32>
    %8 = tensor.empty() : tensor<8x1xf16>
    %9 = tensor.empty() : tensor<8x256xf16>
    %10 = tensor.empty() : tensor<8x256xi1>
    %11 = tensor.empty() : tensor<8x256xf32>
    %12 = tensor.empty() : tensor<8x1xf32>
    %13 = tensor.empty() : tensor<8xi64>
    %14 = arith.muli %1, %c8_i32 : i32
    %15 = arith.index_cast %14 : i32 to index
    %subview = memref.subview %reinterpret_cast[%15, 0] [8, 256] [1, 1] : memref<32x256xf16, strided<[256, 1]>> to memref<8x256xf16, strided<[256, 1], offset: ?>>
    %alloc = memref.alloc() : memref<8x256xf16>
    memref.copy %subview, %alloc : memref<8x256xf16, strided<[256, 1], offset: ?>> to memref<8x256xf16>
    %16 = bufferization.to_tensor %alloc restrict : memref<8x256xf16>
    %17 = hivm.hir.vreduce <max> ins(%16 : tensor<8x256xf16>) outs(%8 : tensor<8x1xf16>) reduce_dims = [1] -> tensor<8x1xf16>
    %18 = hivm.hir.vbrc ins(%17 : tensor<8x1xf16>) outs(%9 : tensor<8x256xf16>) broadcast_dims = [1] -> tensor<8x256xf16>
    %19 = hivm.hir.vcmp ins(%16, %18 : tensor<8x256xf16>, tensor<8x256xf16>) outs(%10 : tensor<8x256xi1>) -> tensor<8x256xi1>
    %20 = hivm.hir.vsel ins(%19, %6, %7 : tensor<8x256xi1>, tensor<8x256xf32>, tensor<8x256xf32>) outs(%11 : tensor<8x256xf32>) -> tensor<8x256xf32>
    %21 = hivm.hir.vreduce <min> ins(%20 : tensor<8x256xf32>) outs(%12 : tensor<8x1xf32>) reduce_dims = [1] -> tensor<8x1xf32>
    %collapsed = tensor.collapse_shape %21 [[0, 1]] : tensor<8x1xf32> into tensor<8xf32>
    %22 = hivm.hir.vcast ins(%collapsed : tensor<8xf32>) outs(%13 : tensor<8xi64>) -> tensor<8xi64>
    %subview_1 = memref.subview %reinterpret_cast_0[%15] [8] [1] : memref<32xi64, strided<[1]>> to memref<8xi64, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %22 in writable %subview_1 : (tensor<8xi64>, memref<8xi64, strided<[1], offset: ?>>) -> ()
    return
  }
}