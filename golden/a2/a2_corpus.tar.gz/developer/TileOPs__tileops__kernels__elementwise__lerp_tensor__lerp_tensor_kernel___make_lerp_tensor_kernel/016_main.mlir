module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf16> to memref<4096xf16, strided<[1]>>
    %0 = tensor.empty() : tensor<4096xf16>
    %1 = tensor.empty() : tensor<4096xf32>
    %2 = tensor.empty() : tensor<4096xf32>
    %3 = tensor.empty() : tensor<4096xf32>
    %alloc = memref.alloc() : memref<4096xf16>
    memref.copy %reinterpret_cast, %alloc : memref<4096xf16, strided<[1]>> to memref<4096xf16>
    %4 = bufferization.to_tensor %alloc restrict : memref<4096xf16>
    %alloc_3 = memref.alloc() : memref<4096xf16>
    memref.copy %reinterpret_cast_1, %alloc_3 : memref<4096xf16, strided<[1]>> to memref<4096xf16>
    %5 = bufferization.to_tensor %alloc_3 restrict : memref<4096xf16>
    %alloc_4 = memref.alloc() : memref<4096xf16>
    memref.copy %reinterpret_cast_0, %alloc_4 : memref<4096xf16, strided<[1]>> to memref<4096xf16>
    %6 = bufferization.to_tensor %alloc_4 restrict : memref<4096xf16>
    %7 = hivm.hir.vcast ins(%4 : tensor<4096xf16>) outs(%1 : tensor<4096xf32>) -> tensor<4096xf32>
    %8 = hivm.hir.vcast ins(%5 : tensor<4096xf16>) outs(%2 : tensor<4096xf32>) -> tensor<4096xf32>
    %9 = hivm.hir.vcast ins(%6 : tensor<4096xf16>) outs(%3 : tensor<4096xf32>) -> tensor<4096xf32>
    %10 = hivm.hir.vsub ins(%8, %7 : tensor<4096xf32>, tensor<4096xf32>) outs(%8 : tensor<4096xf32>) -> tensor<4096xf32>
    %11 = hivm.hir.vmul ins(%9, %10 : tensor<4096xf32>, tensor<4096xf32>) outs(%10 : tensor<4096xf32>) -> tensor<4096xf32>
    %12 = hivm.hir.vadd ins(%7, %11 : tensor<4096xf32>, tensor<4096xf32>) outs(%11 : tensor<4096xf32>) -> tensor<4096xf32>
    %13 = hivm.hir.vcast ins(%12 : tensor<4096xf32>) outs(%0 : tensor<4096xf16>) -> tensor<4096xf16>
    bufferization.materialize_in_destination %13 in writable %reinterpret_cast_2 : (tensor<4096xf16>, memref<4096xf16, strided<[1]>>) -> ()
    return
  }
}