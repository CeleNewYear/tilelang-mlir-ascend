module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %c1048576_i32 = arith.constant 1048576 : i32
    %c2048_i32 = arith.constant 2048 : i32
    %c98304_i32 = arith.constant 98304 : i32
    %c512_i32 = arith.constant 512 : i32
    %c48_i32 = arith.constant 48 : i32
    %c11_i32 = arith.constant 11 : i32
    %c0_i32 = arith.constant 0 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    scf.for %arg13 = %c0_i32 to %c11_i32 step %c1_i32  : i32 {
      %2 = tensor.empty() : tensor<2048xf32>
      %3 = tensor.empty() : tensor<2048xf32>
      %4 = tensor.empty() : tensor<2048xf32>
      %5 = tensor.empty() : tensor<2048xf32>
      %6 = arith.muli %arg13, %c48_i32 : i32
      %7 = arith.addi %6, %1 : i32
      %8 = arith.cmpi slt, %7, %c512_i32 : i32
      scf.if %8 {
        %9 = arith.muli %arg13, %c98304_i32 : i32
        %10 = arith.muli %1, %c2048_i32 : i32
        %11 = arith.addi %9, %10 : i32
        %12 = arith.index_cast %11 : i32 to index
        %13 = arith.subi %c1048576_i32, %10 : i32
        %14 = arith.subi %13, %9 : i32
        %15 = arith.minsi %14, %c2048_i32 : i32
        %16 = arith.index_cast %15 : i32 to index
        %subview = memref.subview %reinterpret_cast[%12] [%16] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
        %alloc = memref.alloc() : memref<2048xf32>
        %subview_3 = memref.subview %alloc[0] [%16] [1] : memref<2048xf32> to memref<?xf32, strided<[1]>>
        memref.copy %subview, %subview_3 : memref<?xf32, strided<[1], offset: ?>> to memref<?xf32, strided<[1]>>
        %17 = bufferization.to_tensor %subview_3 restrict : memref<?xf32, strided<[1]>>
        %inserted_slice = tensor.insert_slice %17 into %2[0] [%16] [1] : tensor<?xf32> into tensor<2048xf32>
        %subview_4 = memref.subview %reinterpret_cast_1[%12] [%16] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
        %alloc_5 = memref.alloc() : memref<2048xf32>
        %subview_6 = memref.subview %alloc_5[0] [%16] [1] : memref<2048xf32> to memref<?xf32, strided<[1]>>
        memref.copy %subview_4, %subview_6 : memref<?xf32, strided<[1], offset: ?>> to memref<?xf32, strided<[1]>>
        %18 = bufferization.to_tensor %subview_6 restrict : memref<?xf32, strided<[1]>>
        %inserted_slice_7 = tensor.insert_slice %18 into %3[0] [%16] [1] : tensor<?xf32> into tensor<2048xf32>
        %subview_8 = memref.subview %reinterpret_cast_0[%12] [%16] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
        %alloc_9 = memref.alloc() : memref<2048xf32>
        %subview_10 = memref.subview %alloc_9[0] [%16] [1] : memref<2048xf32> to memref<?xf32, strided<[1]>>
        memref.copy %subview_8, %subview_10 : memref<?xf32, strided<[1], offset: ?>> to memref<?xf32, strided<[1]>>
        %19 = bufferization.to_tensor %subview_10 restrict : memref<?xf32, strided<[1]>>
        %inserted_slice_11 = tensor.insert_slice %19 into %4[0] [%16] [1] : tensor<?xf32> into tensor<2048xf32>
        %20 = hivm.hir.vsub ins(%inserted_slice_7, %inserted_slice : tensor<2048xf32>, tensor<2048xf32>) outs(%inserted_slice_7 : tensor<2048xf32>) -> tensor<2048xf32>
        %21 = hivm.hir.vmul ins(%inserted_slice_11, %20 : tensor<2048xf32>, tensor<2048xf32>) outs(%20 : tensor<2048xf32>) -> tensor<2048xf32>
        %22 = hivm.hir.vadd ins(%inserted_slice, %21 : tensor<2048xf32>, tensor<2048xf32>) outs(%5 : tensor<2048xf32>) -> tensor<2048xf32>
        %extracted_slice = tensor.extract_slice %22[0] [%16] [1] : tensor<2048xf32> to tensor<?xf32>
        %subview_12 = memref.subview %reinterpret_cast_2[%12] [%16] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
        bufferization.materialize_in_destination %extracted_slice in writable %subview_12 : (tensor<?xf32>, memref<?xf32, strided<[1], offset: ?>>) -> ()
      }
    }
    return
  }
}