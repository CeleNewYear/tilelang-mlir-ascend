module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %c4097_i32 = arith.constant 4097 : i32
    %c4096_i32 = arith.constant 4096 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4097], strides: [%c1] : memref<?xf16> to memref<4097xf16, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4097], strides: [%c1] : memref<?xf16> to memref<4097xf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4097], strides: [%c1] : memref<?xf16> to memref<4097xf16, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [4097], strides: [%c1] : memref<?xf16> to memref<4097xf16, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<4096xf16>
    %3 = tensor.empty() : tensor<4096xf16>
    %4 = tensor.empty() : tensor<4096xf16>
    %5 = tensor.empty() : tensor<4096xf16>
    %6 = tensor.empty() : tensor<4096xf32>
    %7 = tensor.empty() : tensor<4096xf32>
    %8 = tensor.empty() : tensor<4096xf32>
    %9 = arith.muli %1, %c4096_i32 : i32
    %10 = arith.index_cast %9 : i32 to index
    %11 = arith.subi %c4097_i32, %9 : i32
    %12 = arith.minsi %11, %c4096_i32 : i32
    %13 = arith.index_cast %12 : i32 to index
    %subview = memref.subview %reinterpret_cast[%10] [%13] [1] : memref<4097xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<4096xf16>
    %subview_3 = memref.subview %alloc[0] [%13] [1] : memref<4096xf16> to memref<?xf16, strided<[1]>>
    memref.copy %subview, %subview_3 : memref<?xf16, strided<[1], offset: ?>> to memref<?xf16, strided<[1]>>
    %14 = bufferization.to_tensor %subview_3 restrict : memref<?xf16, strided<[1]>>
    %inserted_slice = tensor.insert_slice %14 into %2[0] [%13] [1] : tensor<?xf16> into tensor<4096xf16>
    %subview_4 = memref.subview %reinterpret_cast_1[%10] [%13] [1] : memref<4097xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    %alloc_5 = memref.alloc() : memref<4096xf16>
    %subview_6 = memref.subview %alloc_5[0] [%13] [1] : memref<4096xf16> to memref<?xf16, strided<[1]>>
    memref.copy %subview_4, %subview_6 : memref<?xf16, strided<[1], offset: ?>> to memref<?xf16, strided<[1]>>
    %15 = bufferization.to_tensor %subview_6 restrict : memref<?xf16, strided<[1]>>
    %inserted_slice_7 = tensor.insert_slice %15 into %3[0] [%13] [1] : tensor<?xf16> into tensor<4096xf16>
    %subview_8 = memref.subview %reinterpret_cast_0[%10] [%13] [1] : memref<4097xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    %alloc_9 = memref.alloc() : memref<4096xf16>
    %subview_10 = memref.subview %alloc_9[0] [%13] [1] : memref<4096xf16> to memref<?xf16, strided<[1]>>
    memref.copy %subview_8, %subview_10 : memref<?xf16, strided<[1], offset: ?>> to memref<?xf16, strided<[1]>>
    %16 = bufferization.to_tensor %subview_10 restrict : memref<?xf16, strided<[1]>>
    %inserted_slice_11 = tensor.insert_slice %16 into %4[0] [%13] [1] : tensor<?xf16> into tensor<4096xf16>
    %17 = hivm.hir.vcast ins(%inserted_slice : tensor<4096xf16>) outs(%6 : tensor<4096xf32>) -> tensor<4096xf32>
    %18 = hivm.hir.vcast ins(%inserted_slice_7 : tensor<4096xf16>) outs(%7 : tensor<4096xf32>) -> tensor<4096xf32>
    %19 = hivm.hir.vcast ins(%inserted_slice_11 : tensor<4096xf16>) outs(%8 : tensor<4096xf32>) -> tensor<4096xf32>
    %20 = hivm.hir.vsub ins(%18, %17 : tensor<4096xf32>, tensor<4096xf32>) outs(%18 : tensor<4096xf32>) -> tensor<4096xf32>
    %21 = hivm.hir.vmul ins(%19, %20 : tensor<4096xf32>, tensor<4096xf32>) outs(%20 : tensor<4096xf32>) -> tensor<4096xf32>
    %22 = hivm.hir.vadd ins(%17, %21 : tensor<4096xf32>, tensor<4096xf32>) outs(%21 : tensor<4096xf32>) -> tensor<4096xf32>
    %23 = hivm.hir.vcast ins(%22 : tensor<4096xf32>) outs(%5 : tensor<4096xf16>) -> tensor<4096xf16>
    %extracted_slice = tensor.extract_slice %23[0] [%13] [1] : tensor<4096xf16> to tensor<?xf16>
    %subview_12 = memref.subview %reinterpret_cast_2[%10] [%13] [1] : memref<4097xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_12 : (tensor<?xf16>, memref<?xf16, strided<[1], offset: ?>>) -> ()
    return
  }
}