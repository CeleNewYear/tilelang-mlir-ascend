module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [32], strides: [%c1] : memref<?xf32> to memref<32xf32, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [32], strides: [%c1] : memref<?xf32> to memref<32xf32, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [32], strides: [%c1] : memref<?xf32> to memref<32xf32, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [32], strides: [%c1] : memref<?xf32> to memref<32xf32, strided<[1]>>
    %0 = tensor.empty() : tensor<2048xf32>
    %1 = tensor.empty() : tensor<2048xf32>
    %2 = tensor.empty() : tensor<2048xf32>
    %3 = tensor.empty() : tensor<2048xf32>
    %alloc = memref.alloc() : memref<32xf32>
    memref.copy %reinterpret_cast, %alloc : memref<32xf32, strided<[1]>> to memref<32xf32>
    %4 = bufferization.to_tensor %alloc restrict : memref<32xf32>
    %inserted_slice = tensor.insert_slice %4 into %0[0] [32] [1] : tensor<32xf32> into tensor<2048xf32>
    %alloc_3 = memref.alloc() : memref<32xf32>
    memref.copy %reinterpret_cast_1, %alloc_3 : memref<32xf32, strided<[1]>> to memref<32xf32>
    %5 = bufferization.to_tensor %alloc_3 restrict : memref<32xf32>
    %inserted_slice_4 = tensor.insert_slice %5 into %1[0] [32] [1] : tensor<32xf32> into tensor<2048xf32>
    %alloc_5 = memref.alloc() : memref<32xf32>
    memref.copy %reinterpret_cast_0, %alloc_5 : memref<32xf32, strided<[1]>> to memref<32xf32>
    %6 = bufferization.to_tensor %alloc_5 restrict : memref<32xf32>
    %inserted_slice_6 = tensor.insert_slice %6 into %2[0] [32] [1] : tensor<32xf32> into tensor<2048xf32>
    %7 = hivm.hir.vsub ins(%inserted_slice_4, %inserted_slice : tensor<2048xf32>, tensor<2048xf32>) outs(%inserted_slice_4 : tensor<2048xf32>) -> tensor<2048xf32>
    %8 = hivm.hir.vmul ins(%inserted_slice_6, %7 : tensor<2048xf32>, tensor<2048xf32>) outs(%7 : tensor<2048xf32>) -> tensor<2048xf32>
    %9 = hivm.hir.vadd ins(%inserted_slice, %8 : tensor<2048xf32>, tensor<2048xf32>) outs(%3 : tensor<2048xf32>) -> tensor<2048xf32>
    %extracted_slice = tensor.extract_slice %9[0] [32] [1] : tensor<2048xf32> to tensor<32xf32>
    bufferization.materialize_in_destination %extracted_slice in writable %reinterpret_cast_2 : (tensor<32xf32>, memref<32xf32, strided<[1]>>) -> ()
    return
  }
}