module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: memref<?xf32>, %arg6: memref<?xf32>, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %c2048_i32 = arith.constant 2048 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %reinterpret_cast_0 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [4096], strides: [%c1] : memref<?xf32> to memref<4096xf32, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<2048xf32>
    %3 = arith.muli %1, %c2048_i32 : i32
    %4 = arith.index_cast %3 : i32 to index
    %subview = memref.subview %reinterpret_cast[%4] [2048] [1] : memref<4096xf32, strided<[1]>> to memref<2048xf32, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<2048xf32>
    memref.copy %subview, %alloc : memref<2048xf32, strided<[1], offset: ?>> to memref<2048xf32>
    %5 = bufferization.to_tensor %alloc restrict : memref<2048xf32>
    %subview_3 = memref.subview %reinterpret_cast_1[%4] [2048] [1] : memref<4096xf32, strided<[1]>> to memref<2048xf32, strided<[1], offset: ?>>
    %alloc_4 = memref.alloc() : memref<2048xf32>
    memref.copy %subview_3, %alloc_4 : memref<2048xf32, strided<[1], offset: ?>> to memref<2048xf32>
    %6 = bufferization.to_tensor %alloc_4 restrict : memref<2048xf32>
    %subview_5 = memref.subview %reinterpret_cast_0[%4] [2048] [1] : memref<4096xf32, strided<[1]>> to memref<2048xf32, strided<[1], offset: ?>>
    %alloc_6 = memref.alloc() : memref<2048xf32>
    memref.copy %subview_5, %alloc_6 : memref<2048xf32, strided<[1], offset: ?>> to memref<2048xf32>
    %7 = bufferization.to_tensor %alloc_6 restrict : memref<2048xf32>
    %8 = hivm.hir.vsub ins(%6, %5 : tensor<2048xf32>, tensor<2048xf32>) outs(%6 : tensor<2048xf32>) -> tensor<2048xf32>
    %9 = hivm.hir.vmul ins(%7, %8 : tensor<2048xf32>, tensor<2048xf32>) outs(%8 : tensor<2048xf32>) -> tensor<2048xf32>
    %10 = hivm.hir.vadd ins(%5, %9 : tensor<2048xf32>, tensor<2048xf32>) outs(%2 : tensor<2048xf32>) -> tensor<2048xf32>
    %subview_7 = memref.subview %reinterpret_cast_2[%4] [2048] [1] : memref<4096xf32, strided<[1]>> to memref<2048xf32, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %10 in writable %subview_7 : (tensor<2048xf32>, memref<2048xf32, strided<[1], offset: ?>>) -> ()
    return
  }
}