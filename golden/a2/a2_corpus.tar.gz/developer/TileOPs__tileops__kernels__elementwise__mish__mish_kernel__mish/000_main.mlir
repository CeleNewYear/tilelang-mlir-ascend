module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %cst = arith.constant 2.000000e+00 : f32
    %cst_0 = arith.constant 1.000000e+00 : f32
    %c2048_i32 = arith.constant 2048 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf16> to memref<1048576xf16, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf16> to memref<1048576xf16, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<2048xf16>
    %3 = tensor.empty() : tensor<2048xf32>
    %4 = tensor.empty() : tensor<2048xf32>
    %5 = tensor.empty() : tensor<2048xf32>
    %6 = tensor.empty() : tensor<2048xf16>
    %7 = arith.muli %1, %c2048_i32 : i32
    %8 = arith.index_cast %7 : i32 to index
    %9 = arith.subi %arg5, %7 : i32
    %10 = arith.minsi %9, %c2048_i32 : i32
    %11 = arith.index_cast %10 : i32 to index
    %subview = memref.subview %reinterpret_cast[%8] [%11] [1] : memref<1048576xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<2048xf16>
    %subview_2 = memref.subview %alloc[0] [%11] [1] : memref<2048xf16> to memref<?xf16, strided<[1]>>
    memref.copy %subview, %subview_2 : memref<?xf16, strided<[1], offset: ?>> to memref<?xf16, strided<[1]>>
    %12 = bufferization.to_tensor %subview_2 restrict : memref<?xf16, strided<[1]>>
    %inserted_slice = tensor.insert_slice %12 into %2[0] [%11] [1] : tensor<?xf16> into tensor<2048xf16>
    %13 = hivm.hir.vcast ins(%inserted_slice : tensor<2048xf16>) outs(%3 : tensor<2048xf32>) -> tensor<2048xf32>
    %14 = hivm.hir.vexp ins(%13 : tensor<2048xf32>) outs(%4 : tensor<2048xf32>) -> tensor<2048xf32>
    %15 = hivm.hir.vadd ins(%14, %cst_0 : tensor<2048xf32>, f32) outs(%5 : tensor<2048xf32>) -> tensor<2048xf32>
    %16 = hivm.hir.vln ins(%15 : tensor<2048xf32>) outs(%14 : tensor<2048xf32>) -> tensor<2048xf32>
    %17 = tensor.empty() : tensor<2048xf32>
    %18 = tensor.empty() : tensor<2048xf32>
    %19 = tensor.empty() : tensor<2048xf32>
    %20 = tensor.empty() : tensor<2048xf32>
    %21 = hivm.hir.vmul ins(%16, %cst : tensor<2048xf32>, f32) outs(%17 : tensor<2048xf32>) -> tensor<2048xf32>
    %22 = hivm.hir.vexp ins(%21 : tensor<2048xf32>) outs(%18 : tensor<2048xf32>) -> tensor<2048xf32>
    %23 = hivm.hir.vsub ins(%22, %cst_0 : tensor<2048xf32>, f32) outs(%19 : tensor<2048xf32>) -> tensor<2048xf32>
    %24 = hivm.hir.vadd ins(%22, %cst_0 : tensor<2048xf32>, f32) outs(%20 : tensor<2048xf32>) -> tensor<2048xf32>
    %25 = hivm.hir.vdiv ins(%23, %24 : tensor<2048xf32>, tensor<2048xf32>) outs(%15 : tensor<2048xf32>) -> tensor<2048xf32>
    %26 = hivm.hir.vmul ins(%13, %25 : tensor<2048xf32>, tensor<2048xf32>) outs(%16 : tensor<2048xf32>) -> tensor<2048xf32>
    %27 = hivm.hir.vcast ins(%26 : tensor<2048xf32>) outs(%6 : tensor<2048xf16>) -> tensor<2048xf16>
    %extracted_slice = tensor.extract_slice %27[0] [%11] [1] : tensor<2048xf16> to tensor<?xf16>
    %subview_3 = memref.subview %reinterpret_cast_1[%8] [%11] [1] : memref<1048576xf16, strided<[1]>> to memref<?xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_3 : (tensor<?xf16>, memref<?xf16, strided<[1], offset: ?>>) -> ()
    return
  }
}