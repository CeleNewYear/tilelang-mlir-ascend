module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @main(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf32>, %arg4: memref<?xf32>, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c1 = arith.constant 1 : index
    %cst = arith.constant 2.000000e+00 : f32
    %cst_0 = arith.constant 1.000000e+00 : f32
    %c2048_i32 = arith.constant 2048 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [1048576], strides: [%c1] : memref<?xf32> to memref<1048576xf32, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<2048xf32>
    %3 = tensor.empty() : tensor<2048xf32>
    %4 = tensor.empty() : tensor<2048xf32>
    %5 = arith.muli %1, %c2048_i32 : i32
    %6 = arith.index_cast %5 : i32 to index
    %7 = arith.subi %arg5, %5 : i32
    %8 = arith.minsi %7, %c2048_i32 : i32
    %9 = arith.index_cast %8 : i32 to index
    %subview = memref.subview %reinterpret_cast[%6] [%9] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<2048xf32>
    %subview_2 = memref.subview %alloc[0] [%9] [1] : memref<2048xf32> to memref<?xf32, strided<[1]>>
    memref.copy %subview, %subview_2 : memref<?xf32, strided<[1], offset: ?>> to memref<?xf32, strided<[1]>>
    %10 = bufferization.to_tensor %subview_2 restrict : memref<?xf32, strided<[1]>>
    %inserted_slice = tensor.insert_slice %10 into %2[0] [%9] [1] : tensor<?xf32> into tensor<2048xf32>
    %11 = hivm.hir.vexp ins(%inserted_slice : tensor<2048xf32>) outs(%3 : tensor<2048xf32>) -> tensor<2048xf32>
    %12 = hivm.hir.vadd ins(%11, %cst_0 : tensor<2048xf32>, f32) outs(%4 : tensor<2048xf32>) -> tensor<2048xf32>
    %13 = hivm.hir.vln ins(%12 : tensor<2048xf32>) outs(%11 : tensor<2048xf32>) -> tensor<2048xf32>
    %14 = tensor.empty() : tensor<2048xf32>
    %15 = tensor.empty() : tensor<2048xf32>
    %16 = tensor.empty() : tensor<2048xf32>
    %17 = tensor.empty() : tensor<2048xf32>
    %18 = hivm.hir.vmul ins(%13, %cst : tensor<2048xf32>, f32) outs(%14 : tensor<2048xf32>) -> tensor<2048xf32>
    %19 = hivm.hir.vexp ins(%18 : tensor<2048xf32>) outs(%15 : tensor<2048xf32>) -> tensor<2048xf32>
    %20 = hivm.hir.vsub ins(%19, %cst_0 : tensor<2048xf32>, f32) outs(%16 : tensor<2048xf32>) -> tensor<2048xf32>
    %21 = hivm.hir.vadd ins(%19, %cst_0 : tensor<2048xf32>, f32) outs(%17 : tensor<2048xf32>) -> tensor<2048xf32>
    %22 = hivm.hir.vdiv ins(%20, %21 : tensor<2048xf32>, tensor<2048xf32>) outs(%12 : tensor<2048xf32>) -> tensor<2048xf32>
    %23 = hivm.hir.vmul ins(%inserted_slice, %22 : tensor<2048xf32>, tensor<2048xf32>) outs(%13 : tensor<2048xf32>) -> tensor<2048xf32>
    %extracted_slice = tensor.extract_slice %23[0] [%9] [1] : tensor<2048xf32> to tensor<?xf32>
    %subview_3 = memref.subview %reinterpret_cast_1[%6] [%9] [1] : memref<1048576xf32, strided<[1]>> to memref<?xf32, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %extracted_slice in writable %subview_3 : (tensor<?xf32>, memref<?xf32, strided<[1], offset: ?>>) -> ()
    return
  }
}