module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @pass1(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c2048 = arith.constant 2048 : index
    %c256 = arith.constant 256 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 1.000000e+00 : f32
    %cst_0 = arith.constant 0.000000e+00 : f32
    %c3_i32 = arith.constant 3 : i32
    %c4_i32 = arith.constant 4 : i32
    %c0_i32 = arith.constant 0 : i32
    %c2_i32 = arith.constant 2 : i32
    %c256_i32 = arith.constant 256 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4, 256], strides: [%c256, %c1] : memref<?xf16> to memref<4x256xf16, strided<[256, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf32> to memref<2x8x256xf32, strided<[2048, 256, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [2, 8], strides: [%c8, %c1] : memref<?xf32> to memref<2x8xf32, strided<[8, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [4, 256], strides: [%c256, %c1] : memref<?xf32> to memref<4x256xf32, strided<[256, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf16> to memref<256xf16, strided<[1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<256xf32>
    %3 = tensor.empty() : tensor<256xf32>
    %4 = tensor.empty() : tensor<256xf32>
    %5 = tensor.empty() : tensor<256xf32>
    %6 = tensor.empty() : tensor<256xf32>
    %7 = tensor.empty() : tensor<256xf32>
    %8 = tensor.empty() : tensor<256xf32>
    %9 = arith.remsi %1, %c2_i32 : i32
    %10 = arith.index_cast %9 : i32 to index
    %11 = arith.divsi %1, %c2_i32 : i32
    %12 = arith.index_cast %11 : i32 to index
    %subview = memref.subview %reinterpret_cast[%10, %12, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<256xf16>
    memref.copy %subview, %alloc : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %13 = bufferization.to_tensor %alloc restrict : memref<256xf16>
    %14 = tensor.empty() : tensor<256xf32>
    %15 = hivm.hir.vcast ins(%13 : tensor<256xf16>) outs(%14 : tensor<256xf32>) -> tensor<256xf32>
    %16 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%2 : tensor<256xf32>) -> tensor<256xf32>
    %17 = scf.for %arg16 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg17 = %16) -> (tensor<256xf32>)  : i32 {
      %27 = tensor.empty() : tensor<256xf32>
      %28 = tensor.empty() : tensor<1x1xf32>
      %29 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%27 : tensor<256xf32>) -> tensor<256xf32>
      %30 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%28 : tensor<1x1xf32>) -> tensor<1x1xf32>
      %31 = arith.divsi %1, %c2_i32 : i32
      %32 = arith.addi %31, %arg16 : i32
      %33 = arith.cmpi sge, %32, %c3_i32 : i32
      %34:2 = scf.if %33 -> (tensor<256xf32>, tensor<1x1xf32>) {
        %44 = arith.remsi %1, %c2_i32 : i32
        %45 = arith.index_cast %44 : i32 to index
        %46 = arith.divsi %1, %c2_i32 : i32
        %47 = arith.addi %46, %arg16 : i32
        %48 = arith.subi %47, %c3_i32 : i32
        %49 = arith.index_cast %48 : i32 to index
        %subview_11 = memref.subview %reinterpret_cast_6[%45, %49, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
        %alloc_12 = memref.alloc() : memref<256xf16>
        memref.copy %subview_11, %alloc_12 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
        %50 = bufferization.to_tensor %alloc_12 restrict : memref<256xf16>
        %51 = tensor.empty() : tensor<256xf32>
        %52 = hivm.hir.vcast ins(%50 : tensor<256xf16>) outs(%51 : tensor<256xf32>) -> tensor<256xf32>
        %subview_13 = memref.subview %reinterpret_cast_3[%45, %49] [1, 1] [1, 1] : memref<2x8xf32, strided<[8, 1]>> to memref<1xf32, strided<[8], offset: ?>>
        %alloc_14 = memref.alloc() : memref<1xf32>
        memref.copy %subview_13, %alloc_14 : memref<1xf32, strided<[8], offset: ?>> to memref<1xf32>
        %53 = bufferization.to_tensor %alloc_14 restrict : memref<1xf32>
        %inserted_slice_15 = tensor.insert_slice %53 into %30[0, 0] [1, 1] [1, 1] : tensor<1xf32> into tensor<1x1xf32>
        scf.yield %52, %inserted_slice_15 : tensor<256xf32>, tensor<1x1xf32>
      } else {
        scf.yield %29, %30 : tensor<256xf32>, tensor<1x1xf32>
      }
      %alloc_8 = memref.alloc() : memref<256xf16>
      memref.copy %reinterpret_cast_5, %alloc_8 : memref<256xf16, strided<[1]>> to memref<256xf16>
      %35 = bufferization.to_tensor %alloc_8 restrict : memref<256xf16>
      %36 = tensor.empty() : tensor<256xf32>
      %37 = hivm.hir.vcast ins(%35 : tensor<256xf16>) outs(%36 : tensor<256xf32>) -> tensor<256xf32>
      %38 = arith.index_cast %arg16 : i32 to index
      %subview_9 = memref.subview %reinterpret_cast_1[%38, 0] [1, 256] [1, 1] : memref<4x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_10 = memref.alloc() : memref<256xf16>
      memref.copy %subview_9, %alloc_10 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %39 = bufferization.to_tensor %alloc_10 restrict : memref<256xf16>
      %40 = tensor.empty() : tensor<1x256xf16>
      %inserted_slice = tensor.insert_slice %39 into %40[0, 0] [1, 256] [1, 1] : tensor<256xf16> into tensor<1x256xf16>
      %41 = tensor.empty() : tensor<1x256xf32>
      %42 = hivm.hir.vcast ins(%inserted_slice : tensor<1x256xf16>) outs(%41 : tensor<1x256xf32>) -> tensor<1x256xf32>
      %43 = scf.for %arg18 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg19 = %arg17) -> (tensor<256xf32>)  : i32 {
        %44 = arith.index_cast %arg18 : i32 to index
        %extracted = tensor.extract %34#0[%44] : tensor<256xf32>
        %extracted_11 = tensor.extract %34#1[%c0, %c0] : tensor<1x1xf32>
        %45 = arith.mulf %extracted, %extracted_11 : f32
        %extracted_12 = tensor.extract %37[%44] : tensor<256xf32>
        %46 = arith.mulf %45, %extracted_12 : f32
        %extracted_13 = tensor.extract %arg19[%44] : tensor<256xf32>
        %extracted_14 = tensor.extract %42[%c0, %44] : tensor<1x256xf32>
        %47 = arith.mulf %extracted_14, %46 : f32
        %48 = arith.addf %extracted_13, %47 : f32
        %inserted = tensor.insert %48 into %arg19[%44] : tensor<256xf32>
        scf.yield %inserted : tensor<256xf32>
      }
      scf.yield %43 : tensor<256xf32>
    }
    %18 = hivm.hir.vsub ins(%cst_0, %17 : f32, tensor<256xf32>) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %19 = hivm.hir.vexp ins(%18 : tensor<256xf32>) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %20 = hivm.hir.vadd ins(%19, %cst : tensor<256xf32>, f32) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %21 = hivm.hir.vdiv ins(%cst, %20 : f32, tensor<256xf32>) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %22 = hivm.hir.vmul ins(%17, %21 : tensor<256xf32>, tensor<256xf32>) outs(%5 : tensor<256xf32>) -> tensor<256xf32>
    %23 = hivm.hir.vsub ins(%cst, %21 : f32, tensor<256xf32>) outs(%6 : tensor<256xf32>) -> tensor<256xf32>
    %24 = hivm.hir.vmul ins(%22, %23 : tensor<256xf32>, tensor<256xf32>) outs(%7 : tensor<256xf32>) -> tensor<256xf32>
    %25 = hivm.hir.vadd ins(%21, %24 : tensor<256xf32>, tensor<256xf32>) outs(%8 : tensor<256xf32>) -> tensor<256xf32>
    %26 = hivm.hir.vmul ins(%15, %25 : tensor<256xf32>, tensor<256xf32>) outs(%4 : tensor<256xf32>) -> tensor<256xf32>
    scf.for %arg16 = %c0_i32 to %c4_i32 step %c1_i32  : i32 {
      %27 = tensor.empty() : tensor<256xf32>
      %28 = tensor.empty() : tensor<1x1xf32>
      %29 = tensor.empty() : tensor<1x256xf32>
      %30 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%27 : tensor<256xf32>) -> tensor<256xf32>
      %31 = hivm.hir.vbrc ins(%cst_0 : f32) outs(%28 : tensor<1x1xf32>) -> tensor<1x1xf32>
      %32 = arith.divsi %1, %c2_i32 : i32
      %33 = arith.addi %32, %arg16 : i32
      %34 = arith.cmpi sge, %33, %c3_i32 : i32
      %35:2 = scf.if %34 -> (tensor<256xf32>, tensor<1x1xf32>) {
        %41 = arith.remsi %1, %c2_i32 : i32
        %42 = arith.index_cast %41 : i32 to index
        %43 = arith.divsi %1, %c2_i32 : i32
        %44 = arith.addi %43, %arg16 : i32
        %45 = arith.subi %44, %c3_i32 : i32
        %46 = arith.index_cast %45 : i32 to index
        %subview_10 = memref.subview %reinterpret_cast_6[%42, %46, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
        %alloc_11 = memref.alloc() : memref<256xf16>
        memref.copy %subview_10, %alloc_11 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
        %47 = bufferization.to_tensor %alloc_11 restrict : memref<256xf16>
        %48 = tensor.empty() : tensor<256xf32>
        %49 = hivm.hir.vcast ins(%47 : tensor<256xf16>) outs(%48 : tensor<256xf32>) -> tensor<256xf32>
        %subview_12 = memref.subview %reinterpret_cast_3[%42, %46] [1, 1] [1, 1] : memref<2x8xf32, strided<[8, 1]>> to memref<1xf32, strided<[8], offset: ?>>
        %alloc_13 = memref.alloc() : memref<1xf32>
        memref.copy %subview_12, %alloc_13 : memref<1xf32, strided<[8], offset: ?>> to memref<1xf32>
        %50 = bufferization.to_tensor %alloc_13 restrict : memref<1xf32>
        %inserted_slice = tensor.insert_slice %50 into %31[0, 0] [1, 1] [1, 1] : tensor<1xf32> into tensor<1x1xf32>
        scf.yield %49, %inserted_slice : tensor<256xf32>, tensor<1x1xf32>
      } else {
        scf.yield %30, %31 : tensor<256xf32>, tensor<1x1xf32>
      }
      %alloc_8 = memref.alloc() : memref<256xf16>
      memref.copy %reinterpret_cast_5, %alloc_8 : memref<256xf16, strided<[1]>> to memref<256xf16>
      %36 = bufferization.to_tensor %alloc_8 restrict : memref<256xf16>
      %37 = tensor.empty() : tensor<256xf32>
      %38 = hivm.hir.vcast ins(%36 : tensor<256xf16>) outs(%37 : tensor<256xf32>) -> tensor<256xf32>
      %39 = scf.for %arg17 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg18 = %29) -> (tensor<1x256xf32>)  : i32 {
        %41 = arith.index_cast %arg17 : i32 to index
        %extracted = tensor.extract %35#0[%41] : tensor<256xf32>
        %extracted_10 = tensor.extract %35#1[%c0, %c0] : tensor<1x1xf32>
        %42 = arith.mulf %extracted, %extracted_10 : f32
        %extracted_11 = tensor.extract %38[%41] : tensor<256xf32>
        %43 = arith.mulf %42, %extracted_11 : f32
        %extracted_12 = tensor.extract %26[%41] : tensor<256xf32>
        %44 = arith.mulf %extracted_12, %43 : f32
        %inserted = tensor.insert %44 into %arg18[%c0, %41] : tensor<1x256xf32>
        scf.yield %inserted : tensor<1x256xf32>
      }
      %40 = arith.index_cast %arg16 : i32 to index
      %subview_9 = memref.subview %reinterpret_cast_4[%40, 0] [1, 256] [1, 1] : memref<4x256xf32, strided<[256, 1]>> to memref<1x256xf32, strided<[256, 1], offset: ?>>
      hivm.hir.store ins(%39 : tensor<1x256xf32>) outs(%subview_9 : memref<1x256xf32, strided<[256, 1], offset: ?>>) atomic = <add>
    }
    %subview_7 = memref.subview %reinterpret_cast_2[%10, %12, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf32, strided<[2048, 256, 1]>> to memref<256xf32, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %26 in writable %subview_7 : (tensor<256xf32>, memref<256xf32, strided<[1], offset: ?>>) -> ()
    return
  }
}