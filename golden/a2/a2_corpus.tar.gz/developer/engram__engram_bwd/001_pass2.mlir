module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @pass2(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: i32, %arg11: i32, %arg12: i32, %arg13: i32, %arg14: i32, %arg15: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f32
    %c8 = arith.constant 8 : index
    %c2048 = arith.constant 2048 : index
    %c256 = arith.constant 256 : index
    %c1 = arith.constant 1 : index
    %cst_0 = arith.constant 1.562500e-02 : f32
    %c3_i32 = arith.constant 3 : i32
    %c5_i32 = arith.constant 5 : i32
    %c2_i32 = arith.constant 2 : i32
    %c4_i32 = arith.constant 4 : i32
    %c0_i32 = arith.constant 0 : i32
    %c256_i32 = arith.constant 256 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_1 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [4, 256], strides: [%c256, %c1] : memref<?xf16> to memref<4x256xf16, strided<[256, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf32> to memref<2x8x256xf32, strided<[2048, 256, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [2, 8], strides: [%c8, %c1] : memref<?xf32> to memref<2x8xf32, strided<[8, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf32> to memref<256xf32, strided<[1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf16> to memref<256xf16, strided<[1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<256xf32>
    %3 = tensor.empty() : tensor<256xf32>
    %4 = tensor.empty() : tensor<1x256xf32>
    %5 = tensor.empty() : tensor<1x1xf32>
    %6 = tensor.empty() : tensor<256xf32>
    %7 = tensor.empty() : tensor<1x256xf32>
    %8 = hivm.hir.vbrc ins(%cst : f32) outs(%2 : tensor<256xf32>) -> tensor<256xf32>
    %9 = scf.for %arg16 = %c0_i32 to %c4_i32 step %c1_i32 iter_args(%arg17 = %8) -> (tensor<256xf32>)  : i32 {
      %31 = tensor.empty() : tensor<256xf32>
      %32 = tensor.empty() : tensor<256xf32>
      %33 = hivm.hir.vbrc ins(%cst : f32) outs(%31 : tensor<256xf32>) -> tensor<256xf32>
      %34 = arith.divsi %1, %c2_i32 : i32
      %35 = arith.subi %34, %arg16 : i32
      %36 = arith.cmpi slt, %35, %c5_i32 : i32
      %37 = scf.if %36 -> (tensor<256xf32>) {
        %44 = arith.remsi %1, %c2_i32 : i32
        %45 = arith.index_cast %44 : i32 to index
        %46 = arith.divsi %1, %c2_i32 : i32
        %47 = arith.addi %46, %c3_i32 : i32
        %48 = arith.subi %47, %arg16 : i32
        %49 = arith.index_cast %48 : i32 to index
        %subview_15 = memref.subview %reinterpret_cast_2[%45, %49, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf32, strided<[2048, 256, 1]>> to memref<256xf32, strided<[1], offset: ?>>
        %alloc_16 = memref.alloc() : memref<256xf32>
        memref.copy %subview_15, %alloc_16 : memref<256xf32, strided<[1], offset: ?>> to memref<256xf32>
        %50 = bufferization.to_tensor %alloc_16 restrict : memref<256xf32>
        scf.yield %50 : tensor<256xf32>
      } else {
        scf.yield %33 : tensor<256xf32>
      }
      %38 = arith.index_cast %arg16 : i32 to index
      %subview_13 = memref.subview %reinterpret_cast_1[%38, 0] [1, 256] [1, 1] : memref<4x256xf16, strided<[256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
      %alloc_14 = memref.alloc() : memref<256xf16>
      memref.copy %subview_13, %alloc_14 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
      %39 = bufferization.to_tensor %alloc_14 restrict : memref<256xf16>
      %40 = tensor.empty() : tensor<256xf32>
      %41 = hivm.hir.vcast ins(%39 : tensor<256xf16>) outs(%40 : tensor<256xf32>) -> tensor<256xf32>
      %42 = hivm.hir.vmul ins(%41, %37 : tensor<256xf32>, tensor<256xf32>) outs(%32 : tensor<256xf32>) -> tensor<256xf32>
      %43 = hivm.hir.vadd ins(%arg17, %42 : tensor<256xf32>, tensor<256xf32>) outs(%arg17 : tensor<256xf32>) -> tensor<256xf32>
      scf.yield %43 : tensor<256xf32>
    }
    %10 = arith.remsi %1, %c2_i32 : i32
    %11 = arith.index_cast %10 : i32 to index
    %12 = arith.divsi %1, %c2_i32 : i32
    %13 = arith.index_cast %12 : i32 to index
    %14 = memref.load %reinterpret_cast_3[%11, %13] : memref<2x8xf32, strided<[8, 1]>>
    %subview = memref.subview %reinterpret_cast_6[%11, %13, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<256xf16>
    memref.copy %subview, %alloc : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %15 = bufferization.to_tensor %alloc restrict : memref<256xf16>
    %16 = tensor.empty() : tensor<256xf32>
    %17 = hivm.hir.vcast ins(%15 : tensor<256xf16>) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    %18 = hivm.hir.vmul ins(%9, %17 : tensor<256xf32>, tensor<256xf32>) outs(%3 : tensor<256xf32>) -> tensor<256xf32>
    %19 = hivm.hir.vmul ins(%18, %14 : tensor<256xf32>, f32) outs(%18 : tensor<256xf32>) -> tensor<256xf32>
    hivm.hir.store ins(%19 : tensor<256xf32>) outs(%reinterpret_cast_4 : memref<256xf32, strided<[1]>>) atomic = <add>
    %alloc_7 = memref.alloc() : memref<256xf16>
    memref.copy %reinterpret_cast_5, %alloc_7 : memref<256xf16, strided<[1]>> to memref<256xf16>
    %20 = bufferization.to_tensor %alloc_7 restrict : memref<256xf16>
    %21 = tensor.empty() : tensor<256xf32>
    %22 = hivm.hir.vcast ins(%20 : tensor<256xf16>) outs(%21 : tensor<256xf32>) -> tensor<256xf32>
    %expanded = tensor.expand_shape %17 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_8 = tensor.expand_shape %22 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_9 = tensor.expand_shape %9 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %23 = hivm.hir.vmul ins(%expanded, %expanded_8 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%7 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %24 = hivm.hir.vmul ins(%23, %expanded_9 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%4 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %25 = hivm.hir.vreduce <sum> ins(%24 : tensor<1x256xf32>) outs(%5 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %26 = scf.for %arg16 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg17 = %6) -> (tensor<256xf32>)  : i32 {
      %31 = arith.index_cast %arg16 : i32 to index
      %extracted = tensor.extract %22[%31] : tensor<256xf32>
      %32 = arith.mulf %14, %extracted : f32
      %extracted_13 = tensor.extract %9[%31] : tensor<256xf32>
      %33 = arith.mulf %32, %extracted_13 : f32
      %34 = arith.mulf %14, %14 : f32
      %35 = arith.mulf %34, %14 : f32
      %extracted_14 = tensor.extract %17[%31] : tensor<256xf32>
      %36 = arith.mulf %35, %extracted_14 : f32
      %extracted_15 = tensor.extract %25[%c0, %c0] : tensor<1x1xf32>
      %37 = arith.mulf %36, %extracted_15 : f32
      %38 = arith.mulf %37, %cst_0 : f32
      %39 = arith.subf %33, %38 : f32
      %inserted = tensor.insert %39 into %arg17[%31] : tensor<256xf32>
      scf.yield %inserted : tensor<256xf32>
    }
    %subview_10 = memref.subview %reinterpret_cast[%11, %13, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc_11 = memref.alloc() : memref<256xf16>
    memref.copy %subview_10, %alloc_11 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %27 = bufferization.to_tensor %alloc_11 restrict : memref<256xf16>
    %28 = tensor.empty() : tensor<256xf32>
    %29 = hivm.hir.vcast ins(%27 : tensor<256xf16>) outs(%28 : tensor<256xf32>) -> tensor<256xf32>
    %30 = hivm.hir.vadd ins(%26, %29 : tensor<256xf32>, tensor<256xf32>) outs(%26 : tensor<256xf32>) -> tensor<256xf32>
    %subview_12 = memref.subview %reinterpret_cast_2[%11, %13, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf32, strided<[2048, 256, 1]>> to memref<256xf32, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %30 in writable %subview_12 : (tensor<256xf32>, memref<256xf32, strided<[1], offset: ?>>) -> ()
    return
  }
}