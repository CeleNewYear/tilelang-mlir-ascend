module attributes {hivm.module_core_type = #hivm.module_core_type<AIV>, memref.memref_as_ptr} {
  func.func @pass3(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16>, %arg4: memref<?xf16>, %arg5: memref<?xf16>, %arg6: memref<?xf16>, %arg7: memref<?xf32>, %arg8: memref<?xf32>, %arg9: memref<?xf32>, %arg10: memref<?xf16>, %arg11: memref<?xf16>, %arg12: memref<?xf16>, %arg13: memref<?xf32>, %arg14: memref<?xf32>, %arg15: i32, %arg16: i32, %arg17: i32, %arg18: i32, %arg19: i32, %arg20: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, mix_mode = "aiv"} {
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c2048 = arith.constant 2048 : index
    %c256 = arith.constant 256 : index
    %c1 = arith.constant 1 : index
    %cst = arith.constant 1.562500e-02 : f32
    %cst_0 = arith.constant 1.000000e+00 : f32
    %cst_1 = arith.constant 6.400000e+01 : f32
    %c0_i32 = arith.constant 0 : i32
    %c2_i32 = arith.constant 2 : i32
    %c256_i32 = arith.constant 256 : i32
    %c1_i32 = arith.constant 1 : i32
    hivm.hir.set_ffts_base_addr %arg0
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_2 = memref.reinterpret_cast %arg5 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_3 = memref.reinterpret_cast %arg9 to offset: [0], sizes: [2, 8], strides: [%c8, %c1] : memref<?xf32> to memref<2x8xf32, strided<[8, 1]>>
    %reinterpret_cast_4 = memref.reinterpret_cast %arg7 to offset: [0], sizes: [2, 8], strides: [%c8, %c1] : memref<?xf32> to memref<2x8xf32, strided<[8, 1]>>
    %reinterpret_cast_5 = memref.reinterpret_cast %arg14 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf32> to memref<2x8x256xf32, strided<[2048, 256, 1]>>
    %reinterpret_cast_6 = memref.reinterpret_cast %arg11 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_7 = memref.reinterpret_cast %arg8 to offset: [0], sizes: [2, 8], strides: [%c8, %c1] : memref<?xf32> to memref<2x8xf32, strided<[8, 1]>>
    %reinterpret_cast_8 = memref.reinterpret_cast %arg4 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_9 = memref.reinterpret_cast %arg6 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf16> to memref<256xf16, strided<[1]>>
    %reinterpret_cast_10 = memref.reinterpret_cast %arg12 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_11 = memref.reinterpret_cast %arg10 to offset: [0], sizes: [2, 8, 256], strides: [%c2048, %c256, %c1] : memref<?xf16> to memref<2x8x256xf16, strided<[2048, 256, 1]>>
    %reinterpret_cast_12 = memref.reinterpret_cast %arg13 to offset: [0], sizes: [256], strides: [%c1] : memref<?xf32> to memref<256xf32, strided<[1]>>
    %0 = hivm.hir.get_block_idx -> i64
    %1 = arith.trunci %0 : i64 to i32
    %2 = tensor.empty() : tensor<1x256xf32>
    %3 = tensor.empty() : tensor<1x256xf32>
    %4 = tensor.empty() : tensor<256xf32>
    %5 = tensor.empty() : tensor<1x1xf32>
    %6 = tensor.empty() : tensor<1x1xf32>
    %7 = tensor.empty() : tensor<256xf32>
    %8 = tensor.empty() : tensor<256xf32>
    %9 = tensor.empty() : tensor<1x256xf32>
    %10 = tensor.empty() : tensor<1x1xf32>
    %11 = tensor.empty() : tensor<256xf32>
    %12 = tensor.empty() : tensor<256xf32>
    %13 = tensor.empty() : tensor<1x256xf32>
    %14 = tensor.empty() : tensor<1x1xf32>
    %15 = tensor.empty() : tensor<256xf32>
    %16 = tensor.empty() : tensor<256xf32>
    %17 = tensor.empty() : tensor<1x256xf32>
    %18 = tensor.empty() : tensor<1x256xf32>
    %19 = tensor.empty() : tensor<256xf32>
    %20 = tensor.empty() : tensor<256xf32>
    %21 = tensor.empty() : tensor<1x256xf32>
    %22 = tensor.empty() : tensor<1x256xf32>
    %23 = tensor.empty() : tensor<256xf32>
    %24 = tensor.empty() : tensor<256xf32>
    %25 = arith.remsi %1, %c2_i32 : i32
    %26 = arith.index_cast %25 : i32 to index
    %27 = arith.divsi %1, %c2_i32 : i32
    %28 = arith.index_cast %27 : i32 to index
    %subview = memref.subview %reinterpret_cast_5[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf32, strided<[2048, 256, 1]>> to memref<256xf32, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<256xf32>
    memref.copy %subview, %alloc : memref<256xf32, strided<[1], offset: ?>> to memref<256xf32>
    %29 = bufferization.to_tensor %alloc restrict : memref<256xf32>
    %inserted_slice = tensor.insert_slice %29 into %2[0, 0] [1, 256] [1, 1] : tensor<256xf32> into tensor<1x256xf32>
    %subview_13 = memref.subview %reinterpret_cast_2[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc_14 = memref.alloc() : memref<256xf16>
    memref.copy %subview_13, %alloc_14 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %30 = bufferization.to_tensor %alloc_14 restrict : memref<256xf16>
    %31 = tensor.empty() : tensor<1x256xf16>
    %inserted_slice_15 = tensor.insert_slice %30 into %31[0, 0] [1, 256] [1, 1] : tensor<256xf16> into tensor<1x256xf16>
    %32 = tensor.empty() : tensor<1x256xf32>
    %33 = hivm.hir.vcast ins(%inserted_slice_15 : tensor<1x256xf16>) outs(%32 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %subview_16 = memref.subview %reinterpret_cast[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc_17 = memref.alloc() : memref<256xf16>
    memref.copy %subview_16, %alloc_17 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %34 = bufferization.to_tensor %alloc_17 restrict : memref<256xf16>
    %35 = tensor.empty() : tensor<256xf32>
    %36 = hivm.hir.vcast ins(%34 : tensor<256xf16>) outs(%35 : tensor<256xf32>) -> tensor<256xf32>
    %subview_18 = memref.subview %reinterpret_cast_8[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    %alloc_19 = memref.alloc() : memref<256xf16>
    memref.copy %subview_18, %alloc_19 : memref<256xf16, strided<[1], offset: ?>> to memref<256xf16>
    %37 = bufferization.to_tensor %alloc_19 restrict : memref<256xf16>
    %38 = tensor.empty() : tensor<256xf32>
    %39 = hivm.hir.vcast ins(%37 : tensor<256xf16>) outs(%38 : tensor<256xf32>) -> tensor<256xf32>
    %40 = memref.load %reinterpret_cast_4[%26, %28] : memref<2x8xf32, strided<[8, 1]>>
    %41 = memref.load %reinterpret_cast_7[%26, %28] : memref<2x8xf32, strided<[8, 1]>>
    %42 = memref.load %reinterpret_cast_3[%26, %28] : memref<2x8xf32, strided<[8, 1]>>
    %43 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %3) -> (tensor<1x256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %inserted_slice[%c0, %78] : tensor<1x256xf32>
      %extracted_31 = tensor.extract %33[%c0, %78] : tensor<1x256xf32>
      %79 = arith.mulf %extracted_30, %extracted_31 : f32
      %inserted_32 = tensor.insert %79 into %arg22[%c0, %78] : tensor<1x256xf32>
      scf.yield %inserted_32 : tensor<1x256xf32>
    }
    %44 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %4) -> (tensor<256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %inserted_slice[%c0, %78] : tensor<1x256xf32>
      %79 = arith.mulf %40, %extracted_30 : f32
      %inserted_31 = tensor.insert %79 into %arg22[%78] : tensor<256xf32>
      scf.yield %inserted_31 : tensor<256xf32>
    }
    %45 = hivm.hir.vreduce <sum> ins(%43 : tensor<1x256xf32>) outs(%5 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %inserted = tensor.insert %cst_1 into %6[%c0, %c0] : tensor<1x1xf32>
    %46 = hivm.hir.vsqrt ins(%inserted : tensor<1x1xf32>) outs(%inserted : tensor<1x1xf32>) -> tensor<1x1xf32>
    %extracted = tensor.extract %45[%c0, %c0] : tensor<1x1xf32>
    %47 = arith.mulf %extracted, %40 : f32
    %48 = arith.subf %cst_0, %40 : f32
    %49 = arith.mulf %47, %48 : f32
    %extracted_20 = tensor.extract %46[%c0, %c0] : tensor<1x1xf32>
    %50 = arith.divf %49, %extracted_20 : f32
    %alloc_21 = memref.alloc() : memref<256xf16>
    memref.copy %reinterpret_cast_9, %alloc_21 : memref<256xf16, strided<[1]>> to memref<256xf16>
    %51 = bufferization.to_tensor %alloc_21 restrict : memref<256xf16>
    %52 = tensor.empty() : tensor<256xf32>
    %53 = hivm.hir.vcast ins(%51 : tensor<256xf16>) outs(%52 : tensor<256xf32>) -> tensor<256xf32>
    %54 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %7) -> (tensor<256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %36[%78] : tensor<256xf32>
      %79 = arith.mulf %extracted_30, %41 : f32
      %extracted_31 = tensor.extract %53[%78] : tensor<256xf32>
      %80 = arith.mulf %79, %extracted_31 : f32
      %inserted_32 = tensor.insert %80 into %arg22[%78] : tensor<256xf32>
      scf.yield %inserted_32 : tensor<256xf32>
    }
    %55 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %8) -> (tensor<256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %39[%78] : tensor<256xf32>
      %79 = arith.mulf %extracted_30, %42 : f32
      %extracted_31 = tensor.extract %53[%78] : tensor<256xf32>
      %80 = arith.mulf %79, %extracted_31 : f32
      %inserted_32 = tensor.insert %80 into %arg22[%78] : tensor<256xf32>
      scf.yield %inserted_32 : tensor<256xf32>
    }
    %expanded = tensor.expand_shape %36 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_22 = tensor.expand_shape %53 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_23 = tensor.expand_shape %55 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %56 = hivm.hir.vmul ins(%expanded, %expanded_22 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%17 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %57 = hivm.hir.vmul ins(%56, %50 : tensor<1x256xf32>, f32) outs(%18 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %58 = hivm.hir.vmul ins(%57, %expanded_23 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%9 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %59 = hivm.hir.vreduce <sum> ins(%58 : tensor<1x256xf32>) outs(%10 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %60 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %11) -> (tensor<256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %53[%78] : tensor<256xf32>
      %79 = arith.mulf %41, %extracted_30 : f32
      %80 = arith.mulf %79, %50 : f32
      %extracted_31 = tensor.extract %55[%78] : tensor<256xf32>
      %81 = arith.mulf %80, %extracted_31 : f32
      %82 = arith.mulf %41, %41 : f32
      %83 = arith.mulf %82, %41 : f32
      %extracted_32 = tensor.extract %36[%78] : tensor<256xf32>
      %84 = arith.mulf %83, %extracted_32 : f32
      %extracted_33 = tensor.extract %59[%c0, %c0] : tensor<1x1xf32>
      %85 = arith.mulf %84, %extracted_33 : f32
      %86 = arith.mulf %85, %cst : f32
      %87 = arith.subf %81, %86 : f32
      %inserted_34 = tensor.insert %87 into %arg22[%78] : tensor<256xf32>
      scf.yield %inserted_34 : tensor<256xf32>
    }
    %61 = hivm.hir.vmul ins(%55, %50 : tensor<256xf32>, f32) outs(%19 : tensor<256xf32>) -> tensor<256xf32>
    %62 = hivm.hir.vmul ins(%61, %36 : tensor<256xf32>, tensor<256xf32>) outs(%20 : tensor<256xf32>) -> tensor<256xf32>
    %63 = hivm.hir.vmul ins(%62, %41 : tensor<256xf32>, f32) outs(%12 : tensor<256xf32>) -> tensor<256xf32>
    hivm.hir.store ins(%63 : tensor<256xf32>) outs(%reinterpret_cast_12 : memref<256xf32, strided<[1]>>) atomic = <add>
    %expanded_24 = tensor.expand_shape %39 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_25 = tensor.expand_shape %53 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %expanded_26 = tensor.expand_shape %54 [[0, 1]] output_shape [1, 256] : tensor<256xf32> into tensor<1x256xf32>
    %64 = hivm.hir.vmul ins(%expanded_24, %expanded_25 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%21 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %65 = hivm.hir.vmul ins(%64, %50 : tensor<1x256xf32>, f32) outs(%22 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %66 = hivm.hir.vmul ins(%65, %expanded_26 : tensor<1x256xf32>, tensor<1x256xf32>) outs(%13 : tensor<1x256xf32>) -> tensor<1x256xf32>
    %67 = hivm.hir.vreduce <sum> ins(%66 : tensor<1x256xf32>) outs(%14 : tensor<1x1xf32>) reduce_dims = [1] -> tensor<1x1xf32>
    %68 = scf.for %arg21 = %c0_i32 to %c256_i32 step %c1_i32 iter_args(%arg22 = %15) -> (tensor<256xf32>)  : i32 {
      %78 = arith.index_cast %arg21 : i32 to index
      %extracted_30 = tensor.extract %53[%78] : tensor<256xf32>
      %79 = arith.mulf %42, %extracted_30 : f32
      %80 = arith.mulf %79, %50 : f32
      %extracted_31 = tensor.extract %54[%78] : tensor<256xf32>
      %81 = arith.mulf %80, %extracted_31 : f32
      %82 = arith.mulf %42, %42 : f32
      %83 = arith.mulf %82, %42 : f32
      %extracted_32 = tensor.extract %39[%78] : tensor<256xf32>
      %84 = arith.mulf %83, %extracted_32 : f32
      %extracted_33 = tensor.extract %67[%c0, %c0] : tensor<1x1xf32>
      %85 = arith.mulf %84, %extracted_33 : f32
      %86 = arith.mulf %85, %cst : f32
      %87 = arith.subf %81, %86 : f32
      %inserted_34 = tensor.insert %87 into %arg22[%78] : tensor<256xf32>
      scf.yield %inserted_34 : tensor<256xf32>
    }
    %69 = hivm.hir.vmul ins(%54, %50 : tensor<256xf32>, f32) outs(%23 : tensor<256xf32>) -> tensor<256xf32>
    %70 = hivm.hir.vmul ins(%69, %39 : tensor<256xf32>, tensor<256xf32>) outs(%24 : tensor<256xf32>) -> tensor<256xf32>
    %71 = hivm.hir.vmul ins(%70, %42 : tensor<256xf32>, f32) outs(%16 : tensor<256xf32>) -> tensor<256xf32>
    hivm.hir.store ins(%71 : tensor<256xf32>) outs(%reinterpret_cast_12 : memref<256xf32, strided<[1]>>) atomic = <add>
    %72 = tensor.empty() : tensor<256xf16>
    %73 = hivm.hir.vcast ins(%60 : tensor<256xf32>) outs(%72 : tensor<256xf16>) -> tensor<256xf16>
    %subview_27 = memref.subview %reinterpret_cast_11[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %73 in writable %subview_27 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    %74 = tensor.empty() : tensor<256xf16>
    %75 = hivm.hir.vcast ins(%68 : tensor<256xf32>) outs(%74 : tensor<256xf16>) -> tensor<256xf16>
    %subview_28 = memref.subview %reinterpret_cast_6[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %75 in writable %subview_28 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    %76 = tensor.empty() : tensor<256xf16>
    %77 = hivm.hir.vcast ins(%44 : tensor<256xf32>) outs(%76 : tensor<256xf16>) -> tensor<256xf16>
    %subview_29 = memref.subview %reinterpret_cast_10[%26, %28, 0] [1, 1, 256] [1, 1, 1] : memref<2x8x256xf16, strided<[2048, 256, 1]>> to memref<256xf16, strided<[1], offset: ?>>
    bufferization.materialize_in_destination %77 in writable %subview_29 : (tensor<256xf16>, memref<256xf16, strided<[1], offset: ?>>) -> ()
    return
  }
}